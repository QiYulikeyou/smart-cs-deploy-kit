/**
 * 质检域纯函数 —— 无状态、可单测、供 Quality 各子组件共用
 */

/** 归一化风险等级：high | mid | low */
export function riskLevel(level) {
  if (!level) return 'low';
  if (['high', '紧急', '高风险'].includes(level)) return 'high';
  if (['mid', '中风险'].includes(level)) return 'mid';
  return 'low';
}

export function riskLabel(level) {
  const map = { high: '高风险', mid: '中风险', low: '低风险' };
  return map[riskLevel(level)] || '低风险';
}

export function riskEmoji(level) {
  const map = { high: '🔴', mid: '🟡', low: '🟢' };
  return map[riskLevel(level)] || '🟢';
}

/** 与 SBadge 的 tone 对齐 */
export function riskTone(level) {
  const map = { high: 'danger', mid: 'warn', low: 'success' };
  return map[riskLevel(level)] || 'success';
}

export function emotionLabel(e) {
  const map = { angry: '😠 愤怒', positive: '😊 积极', neutral: '😐 中性' };
  return map[e] || e || '—';
}

/** sensitive_hits 可能是 JSON 字符串，也可能是数组 */
export function parseHits(hits) {
  let arr = hits;
  if (typeof hits === 'string') {
    if (!hits) return '';
    try {
      arr = JSON.parse(hits);
    } catch {
      return '';
    }
  }
  if (!Array.isArray(arr) || !arr.length) return '';
  return arr.map((h) => h.word + (h.note ? `(${h.note})` : '')).join('、');
}

export function actionHint(a) {
  const lv = riskLevel(a?.risk_level);
  if (lv === 'high') return '立即介入处理';
  if (lv === 'mid') return '安排回访跟进';
  return '记录备查';
}

/**
 * 环比文案
 * mode='pp'  → 百分点（风险率等比率型）
 * mode='pct' → 相对变化百分比（计数型）
 * 小基数导致比例失真时降级为绝对增量
 */
export function makeTrend(cur, prev, mode = 'pct') {
  if (prev === null || prev === undefined || Number.isNaN(prev)) return { text: '—', up: null };
  const diff = cur - prev;
  if (Math.abs(diff) < 0.05) return { text: '→ 持平', up: null };

  if (mode === 'pp') {
    const sign = diff > 0 ? '+' : '';
    return { text: `${sign}${diff.toFixed(1)}pp 较上期`, up: diff > 0 };
  }

  const raw = Math.abs(Math.round((diff / (prev || 1)) * 100));
  if (raw >= 999) {
    const sign = diff > 0 ? '+' : '';
    const arrow = diff > 0 ? '↑' : '↓';
    return { text: `${arrow} ${sign}${Math.abs(diff)} 较上期`, up: diff > 0 };
  }
  if (diff > 0) return { text: `↑ ${raw}% 较上期`, up: true };
  return { text: `↓ ${raw}% 较上期`, up: false };
}

/** 会话来源元信息（图表色板，双主题下保持一致以增强辨识度） */
export const SOURCE_META = {
  local: { label: '本地知识库', color: '#3b82f6', grad: 'linear-gradient(90deg, #3b82f6, #06b6d4)' },
  script: { label: '话术库', color: '#06b6d4', grad: 'linear-gradient(90deg, #06b6d4, #22d3ee)' },
  llm: { label: 'AI生成', color: '#8b5cf6', grad: 'linear-gradient(90deg, #8b5cf6, #a78bfa)' },
  feishu: { label: '飞书同步', color: '#f59e0b', grad: 'linear-gradient(90deg, #f59e0b, #fbbf24)' },
  ima: { label: 'IMA 知识库', color: '#10b981', grad: 'linear-gradient(90deg, #10b981, #34d399)' },
  unknown: { label: '其他', color: '#64748b', grad: 'linear-gradient(90deg, #64748b, #94a3b8)' }
};

export function sourceMeta(key) {
  return SOURCE_META[key] || SOURCE_META.unknown;
}
