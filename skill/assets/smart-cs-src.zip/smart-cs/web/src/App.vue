<script setup>
/**
 * 应用外壳 —— 侧边导航 + 顶栏 + 模块内容区
 *
 * v2 变化：
 *  - 全局样式抽到 styles/tokens.css，本文件只保留外壳局部样式
 *  - 新增明暗主题切换（useTheme）
 *  - 新增全局 Toast 宿主
 *  - 侧边栏支持折叠（窄屏自动收起为图标模式），内容区响应式
 *  - 功能入口与 v1 完全一致：对话工作台 / 知识库 / 话术库 / 智能派单 / 全量质检 / 用户管理
 */
import { ref, onMounted, computed, onUnmounted } from 'vue';
import { getUser, clearAuth, ping, getMe } from './api.js';
import { bgStyle, toggleTheme, isDark } from './composables/useTheme.js';
import SToastHost from './components/ui/SToastHost.vue';
import LoginGate from './components/LoginGate.vue';
import Chat from './components/Chat.vue';
import KnowledgeBuild from './components/KnowledgeBuild.vue';
import Scripts from './components/Scripts.vue';
import Dispatch from './components/Dispatch.vue';
import QualityInspect from './components/QualityInspect.vue';
import UserAdmin from './components/UserAdmin.vue';
import Settings from './components/Settings.vue';
import BgSwitcher from './components/BgSwitcher.vue';

const ROLE_LABELS = { admin: '管理员', manager: '客服主管', agent: '客服' };

const user = ref(getUser());
const backendUp = ref(true);
const active = ref('chat');
const collapsed = ref(false);

/* 导航顺序：客服对话工作台（置顶）→ 知识库 → 场景化话术库 → 工单智能派发 → 全量质检 */
const MODULES = [
  { id: 'chat', label: '客服对话工作台', icon: '💬', desc: '实时会话与智能建议' },
  { id: 'knowledge', label: '知识库', icon: '📚', desc: '工单·FAQ·飞书/IMA' },
  { id: 'scripts', label: '场景化话术库', icon: '🗣', desc: '沉淀话术模板' },
  { id: 'dispatch', label: '工单智能派发', icon: '🚦', desc: '技能画像路由' },
  { id: 'quality-inspect', label: '全量质检', icon: '🛡', desc: '质检·历史' },
  { id: 'settings', label: '部署配置', icon: '⚙️', desc: '复制一套到新客户' }
];

const NAV_FLAT = MODULES.concat([{ id: 'users', label: '用户管理', icon: '👥', desc: '账号与权限' }]);

const current = computed(() => NAV_FLAT.find((n) => n.id === active.value) || MODULES[0]);

function onAuthed(u) {
  user.value = u;
}
function onLogout() {
  clearAuth();
  user.value = null;
  active.value = 'chat';
}
function onThemeToggle() {
  toggleTheme();
}

/* 窄屏自动折叠 */
function syncWidth() {
  if (window.innerWidth < 860) collapsed.value = true;
}
onMounted(async () => {
  syncWidth();
  window.addEventListener('resize', syncWidth);
  backendUp.value = await ping();
  if (user.value) {
    try {
      await getMe();
    } catch {
      onLogout();
    }
  }
});
onUnmounted(() => window.removeEventListener('resize', syncWidth));
</script>

<template>
  <!-- 背景层 + 网格叠加（网格线颜色随主题翻转） -->
  <div class="bg-layer" :style="bgStyle"></div>
  <div class="grid-overlay"></div>

  <!-- 登录网关 -->
  <LoginGate v-if="!user" :backend-up="backendUp" @authed="onAuthed" />

  <!-- 主控制台 -->
  <div v-else class="shell" :class="{ 'is-collapsed': collapsed }">
    <aside class="sidebar">
      <div class="brand">
        <span class="logo-dot"></span>
        <span v-if="!collapsed" class="brand-text">
          <span class="brand-name">智能客服中枢</span>
          <span class="brand-ver">v2.0</span>
        </span>
      </div>

      <nav class="nav">
        <button
          v-for="m in MODULES"
          :key="m.id"
          class="nav-item"
          :class="{ active: active === m.id }"
          :title="collapsed ? m.label : ''"
          @click="active = m.id"
        >
          <span class="nav-icon">{{ m.icon }}</span>
          <span v-if="!collapsed" class="nav-text">
            <span class="nav-label">{{ m.label }}</span>
            <span class="nav-desc">{{ m.desc }}</span>
          </span>
        </button>

        <button
          v-if="user.role === 'admin'"
          class="nav-item"
          :class="{ active: active === 'users' }"
          :title="collapsed ? '用户管理' : ''"
          @click="active = 'users'"
        >
          <span class="nav-icon">👥</span>
          <span v-if="!collapsed" class="nav-text">
            <span class="nav-label">用户管理</span>
            <span class="nav-desc">账号与权限</span>
          </span>
        </button>
      </nav>

      <div class="side-foot">
        <button class="collapse-btn" :title="collapsed ? '展开侧栏' : '收起侧栏'" @click="collapsed = !collapsed">
          {{ collapsed ? '»' : '«' }}
        </button>
        <span v-if="!collapsed" class="side-copy">AI Customer Service</span>
      </div>
    </aside>

    <main class="content">
      <header class="topbar">
        <div class="crumb">
          <span class="crumb-icon">{{ current.icon }}</span>
          <span class="crumb-text">
            <span class="crumb-title">{{ current.label }}</span>
            <span class="crumb-desc">{{ current.desc }}</span>
          </span>
        </div>

        <div class="right">
          <span v-if="!backendUp" class="offline-chip" title="后端服务未连接">⚠ 离线</span>

          <!-- 主题切换 -->
          <button class="icon-btn" :title="isDark ? '切换到浅色主题' : '切换到深色主题'" @click="onThemeToggle">
            {{ isDark ? '☀' : '☾' }}
          </button>

          <BgSwitcher />

          <div class="user-chip">
            <span class="avatar">{{ (user.username || '?')[0].toUpperCase() }}</span>
            <span class="user-meta">
              <span class="uname">{{ user.username }}</span>
              <span class="role">{{ ROLE_LABELS[user.role] || user.role }}</span>
            </span>
          </div>

          <button class="logout" @click="onLogout">登出</button>
        </div>
      </header>

      <div class="view">
        <!-- keep-alive 让各模块切换后保留内部状态（滚动位置、筛选条件等） -->
        <KeepAlive>
          <Chat v-if="active === 'chat'" />
          <KnowledgeBuild v-else-if="active === 'knowledge'" />
          <Scripts v-else-if="active === 'scripts'" />
          <Dispatch v-else-if="active === 'dispatch'" />
          <QualityInspect v-else-if="active === 'quality-inspect'" />
          <Settings v-else-if="active === 'settings'" />
          <UserAdmin v-else-if="active === 'users'" />
        </KeepAlive>
      </div>
    </main>
  </div>

  <!-- 全局轻提示 -->
  <SToastHost />
</template>

<style scoped>
/* ===== 背景层 ===== */
.bg-layer {
  position: fixed;
  inset: 0;
  z-index: var(--z-bg);
  transition: background var(--dur-slow) var(--ease);
}

.grid-overlay {
  position: fixed;
  inset: 0;
  z-index: var(--z-grid);
  pointer-events: none;
  background-image:
    linear-gradient(var(--grid-line) 1px, transparent 1px),
    linear-gradient(90deg, var(--grid-line) 1px, transparent 1px);
  background-size: 44px 44px;
  -webkit-mask-image: radial-gradient(circle at 50% 30%, #000, transparent 80%);
  mask-image: radial-gradient(circle at 50% 30%, #000, transparent 80%);
}

/* ===== 外壳 ===== */
.shell {
  display: flex;
  min-height: 100vh;
}

/* ===== 侧边栏 ===== */
.sidebar {
  width: var(--sidebar-w);
  flex-shrink: 0;
  padding: var(--sp-5) var(--sp-4) var(--sp-4);
  background: var(--surface-1);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  transition: width var(--dur) var(--ease), padding var(--dur) var(--ease);
}

.shell.is-collapsed .sidebar {
  width: 66px;
  padding-left: var(--sp-2);
  padding-right: var(--sp-2);
}

.brand {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  margin-bottom: var(--sp-7);
  padding: 0 var(--sp-2);
  min-height: 28px;
}

.logo-dot {
  width: 12px;
  height: 12px;
  flex-shrink: 0;
  border-radius: 50%;
  background: var(--brand);
  box-shadow: 0 0 14px var(--brand);
  animation: scs-pulse 1.8s infinite;
}

.brand-text {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.brand-name {
  color: var(--text-1);
  font-weight: var(--fw-bold);
  letter-spacing: 0.5px;
  font-size: var(--fs-md);
  white-space: nowrap;
}

.brand-ver {
  color: var(--text-4);
  font-size: var(--fs-2xs);
  letter-spacing: 1px;
}

.nav {
  display: flex;
  flex-direction: column;
  gap: var(--sp-1);
}

.nav-item {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  padding: 11px var(--sp-3);
  border-radius: var(--r-lg);
  background: transparent;
  border: 0;
  color: var(--text-2);
  cursor: pointer;
  font-size: var(--fs-md);
  font-family: inherit;
  text-align: left;
  width: 100%;
  transition: background var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease),
    box-shadow var(--dur-fast) var(--ease);
}

.shell.is-collapsed .nav-item {
  justify-content: center;
  padding-left: 0;
  padding-right: 0;
}

.nav-item:hover {
  background: var(--overlay-2);
  color: var(--text-1);
}

.nav-item.active {
  background: var(--brand-grad);
  color: var(--text-1);
  box-shadow: inset 0 0 0 1px var(--brand-ring);
}

.nav-icon {
  font-size: 18px;
  flex-shrink: 0;
  line-height: 1;
  width: 22px;
  text-align: center;
}

.nav-text {
  display: flex;
  flex-direction: column;
  line-height: 1.3;
  min-width: 0;
}

.nav-label {
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
  white-space: nowrap;
}

.nav-desc {
  font-size: var(--fs-xs);
  color: var(--text-4);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nav-item.active .nav-desc {
  color: var(--brand-soft);
}

.side-foot {
  margin-top: auto;
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  padding-top: var(--sp-3);
}

.collapse-btn {
  width: 26px;
  height: 26px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--r-sm);
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-4);
  cursor: pointer;
  font-size: var(--fs-sm);
  transition: var(--dur-fast) var(--ease);
}
.collapse-btn:hover {
  border-color: var(--brand);
  color: var(--brand);
}

.side-copy {
  color: var(--text-4);
  font-size: var(--fs-2xs);
  letter-spacing: 1px;
  white-space: nowrap;
  overflow: hidden;
}

/* ===== 内容区 ===== */
.content {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--sp-4);
  min-height: var(--topbar-h);
  padding: var(--sp-3) var(--sp-6);
  border-bottom: 1px solid var(--border);
  background: var(--surface-0);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  position: sticky;
  top: 0;
  z-index: var(--z-sticky);
}

.crumb {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  min-width: 0;
}

.crumb-icon {
  font-size: 20px;
  line-height: 1;
  flex-shrink: 0;
}

.crumb-text {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.crumb-title {
  color: var(--text-1);
  font-size: var(--fs-xl);
  font-weight: var(--fw-bold);
  line-height: 1.25;
}

.crumb-desc {
  color: var(--text-4);
  font-size: var(--fs-xs);
  line-height: 1.3;
}

.right {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  flex-shrink: 0;
}

.icon-btn {
  width: 32px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--r-md);
  border: 1px solid var(--border);
  background: var(--overlay-1);
  color: var(--text-3);
  cursor: pointer;
  font-size: var(--fs-md);
  line-height: 1;
  transition: var(--dur-fast) var(--ease);
}
.icon-btn:hover {
  border-color: var(--brand);
  color: var(--brand);
  background: var(--overlay-2);
}

.offline-chip {
  padding: 4px 10px;
  border-radius: var(--r-full);
  background: var(--danger-soft);
  border: 1px solid rgba(248, 113, 113, 0.35);
  color: var(--danger-text);
  font-size: var(--fs-xs);
  font-weight: var(--fw-semibold);
  white-space: nowrap;
}

.user-chip {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  padding: 4px 10px 4px 4px;
  border-radius: var(--r-full);
  background: var(--overlay-1);
  border: 1px solid var(--border);
}

.avatar {
  width: 28px;
  height: 28px;
  flex-shrink: 0;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--brand-strong), var(--brand-deep));
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: var(--fw-bold);
  font-size: var(--fs-sm);
}

.user-meta {
  display: flex;
  flex-direction: column;
  line-height: 1.25;
}

.uname {
  color: var(--text-1);
  font-size: var(--fs-base);
  font-weight: var(--fw-medium);
}

.role {
  color: var(--text-4);
  font-size: var(--fs-2xs);
}

.logout {
  background: var(--overlay-1);
  border: 1px solid var(--border-strong);
  color: var(--text-2);
  padding: 7px 14px;
  border-radius: var(--r-md);
  cursor: pointer;
  font-size: var(--fs-base);
  font-family: inherit;
  transition: var(--dur-fast) var(--ease);
}
.logout:hover {
  border-color: var(--danger);
  color: var(--danger-text);
  background: var(--danger-soft);
}

.view {
  padding: var(--sp-6);
  flex: 1;
  min-width: 0;
}

/* ===== 响应式 ===== */
@media (max-width: 1080px) {
  .view {
    padding: var(--sp-4);
  }
  .topbar {
    padding: var(--sp-3) var(--sp-4);
  }
  .crumb-desc {
    display: none;
  }
}

@media (max-width: 860px) {
  .user-meta {
    display: none;
  }
  .crumb-title {
    font-size: var(--fs-lg);
  }
  .right {
    gap: var(--sp-2);
  }
}
</style>
