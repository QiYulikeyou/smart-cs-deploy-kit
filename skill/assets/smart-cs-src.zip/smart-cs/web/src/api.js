const BASE = import.meta.env.VITE_API_BASE || '';

// ---- 本地 token / 用户信息 ----
export function getToken() {
  return localStorage.getItem('scs_token') || '';
}
export function setAuth(token, user) {
  localStorage.setItem('scs_token', token);
  localStorage.setItem('scs_user', JSON.stringify(user));
}
export function clearAuth() {
  localStorage.removeItem('scs_token');
  localStorage.removeItem('scs_user');
}
export function getUser() {
  try {
    return JSON.parse(localStorage.getItem('scs_user') || 'null');
  } catch {
    return null;
  }
}

// 后端连通性自检（进页面时调用）
export async function ping() {
  try {
    const r = await fetch(BASE + '/api/health', { headers: { 'Content-Type': 'application/json' } });
    return r.ok;
  } catch {
    return false;
  }
}

// 统一请求封装：
// - 网络失败（后端没起 / 端口不对）→ 抛出明确提示
// - 非 2xx（401/400 等）→ 抛出后端返回的 error 文案
// - 2xx → 返回解析后的 JSON
async function api(path, opts = {}) {
  // 注意：仅在存在请求体时才声明 Content-Type: application/json。
  // 无 body 却带该头会触发 Fastify 的 FST_ERR_CTP_EMPTY_JSON_BODY（400 Bad Request），
  // 导致「发布 / 撤下 / 删除」等无 body 的 POST/DELETE 接口报错。
  const headers = {};
  const t = getToken();
  if (t) headers['Authorization'] = 'Bearer ' + t;
  if (opts.body) headers['Content-Type'] = 'application/json';

  let res;
  try {
    res = await fetch(BASE + path, { headers, ...opts });
  } catch (e) {
    throw new Error('无法连接后端服务：请确认「npm start」已在 http://localhost:3000 运行（前端开发服务器需后端同时启动）');
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    // 后端返回了非 JSON（如代理错误页），当无 data 处理
  }

  if (!res.ok) {
    const msg = (data && data.error) || `请求失败（HTTP ${res.status}）`;
    throw new Error(msg);
  }
  return data;
}

// ---- 鉴权相关 ----
export const login = (username, password) =>
  api('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
export const getMe = () => api('/api/auth/me');
export const listUsers = () => api('/api/auth/users');
export const createUser = (u) =>
  api('/api/auth/users', { method: 'POST', body: JSON.stringify(u) });
export const changePassword = (p) =>
  api('/api/auth/change-password', { method: 'POST', body: JSON.stringify(p) });

// ---- 业务接口 ----
export const getTickets = () => api('/api/tickets');
export const searchKnowledge = (q) =>
  api('/api/knowledge/search?q=' + encodeURIComponent(q));
export const listKnowledge = (limit = 50, offset = 0, source = '', exclude = '', status = '') => {
  let url = `/api/knowledge?limit=${limit}&offset=${offset}`;
  if (source) url += `&source=${encodeURIComponent(source)}`;
  if (exclude) url += `&exclude=${encodeURIComponent(exclude)}`;
  if (status) url += `&status=${encodeURIComponent(status)}`;
  return api(url).then(r => {
    // 过滤掉无效条目：[原文链接] 开头的纯链接无正文，不能用于检索或生成话术
    r.rows = (r.rows || []).filter(k => !k.question.startsWith('[原文链接]'));
    return r;
  });
};
export const publishKnowledge = (id) =>
  api('/api/knowledge/' + id + '/publish', { method: 'POST' });
export const unpublishKnowledge = (id) =>
  api('/api/knowledge/' + id + '/unpublish', { method: 'POST' });
export const ingestFiles = (files, baseName = '本地文件', publish = false) =>
  api('/api/knowledge/ingest-files', { method: 'POST', body: JSON.stringify({ files, baseName, publish }) });
export const listKbSources = () => api('/api/knowledge/kb-list');
export const extractFaq = (payload) =>
  api('/api/knowledge/extract-faq', { method: 'POST', body: JSON.stringify(payload) });
export const createKnowledge = (item) =>
  api('/api/knowledge', { method: 'POST', body: JSON.stringify(item) });
export const updateKnowledge = (id, item) =>
  api('/api/knowledge/' + id, { method: 'PUT', body: JSON.stringify(item) });
export const deleteKnowledge = (id) =>
  api('/api/knowledge/' + id, { method: 'DELETE' });
export const reembedKnowledge = () =>
  api('/api/knowledge/reembed', { method: 'POST' });
export const syncKnowledge = (source, keyword) =>
  api('/api/knowledge/sync', { method: 'POST', body: JSON.stringify({ source, keyword }) });
export const getSyncStatus = () => api('/api/sync/status');
export const runSync = (keyword, options = {}) =>
  api('/api/sync/run', { method: 'POST', body: JSON.stringify({ keyword, ...options }) });
export const syncExternalKnowledge = (payload) =>
  api('/api/knowledge/sync', { method: 'POST', body: JSON.stringify(payload) });
export const syncKbByName = (source, kbName) =>
  api('/api/knowledge/sync-kb', { method: 'POST', body: JSON.stringify({ source, kb_name: kbName }) });
export const setSyncConfig = (cfg) =>
  api('/api/admin/sync-config', { method: 'POST', body: JSON.stringify(cfg) });
export const importTickets = (tickets) =>
  api('/api/tickets/import', { method: 'POST', body: JSON.stringify(tickets) });
export const detectQa = (text) =>
  api('/api/qa/detect', { method: 'POST', body: JSON.stringify({ text }) });
export const getAlerts = () => api('/api/qa/alerts');
export const dismissAlert = (id) =>
  api(`/api/qa/alert/${id}`, { method: 'DELETE' });
export const cleanupEmptyAlerts = () =>
  api('/api/qa/alerts/cleanup-empty', { method: 'POST' });
export const getStats = () => api('/api/stats');
export const getConversations = (limit = 20, offset = 0, filters = {}) => {
  const p = new URLSearchParams({ limit, offset });
  if (filters.risk) p.set('risk', filters.risk);
  if (filters.source) p.set('source', filters.source);
  if (filters.scope) p.set('scope', filters.scope);
  if (filters.from) p.set('from', filters.from);
  if (filters.to) p.set('to', filters.to);
  return api('/api/qa/conversations?' + p.toString());
};
export const handoffQa = (payload) =>
  api('/api/qa/handoff', { method: 'POST', body: JSON.stringify(payload) });
export const getRiskTrend = (days = 7, scope = '') => {
  const p = new URLSearchParams({ days });
  if (scope) p.set('scope', scope);
  return api('/api/qa/risk-trend?' + p.toString());
};
export const exportCsv = async (params = {}) => {
  // 导出 CSV 不走标准 api()，返回 Blob 供下载
  const headers = { 'Content-Type': 'application/json' };
  const t = getToken();
  if (t) headers['Authorization'] = 'Bearer ' + t;
  const p = new URLSearchParams({ limit: 2000, ...params });
  const res = await fetch(BASE + '/api/qa/export-csv?' + p.toString(), { headers });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.blob();
};
export const mergeSessions = (cfg = {}) =>
  api('/api/qa/sessions/merge', { method: 'POST', body: JSON.stringify(cfg) });
export const chat = (text, history = [], mode = 'knowledge') =>
  api('/api/qa/chat', { method: 'POST', body: JSON.stringify({ text, history, mode }) });
export const getLLMInfo = () => api('/api/llm/info');
export const applyConfig = (cfg) =>
  api('/api/admin/apply-config', { method: 'POST', body: JSON.stringify(cfg) });

// ---- 部署配置（面向快速复制，一份 config.json 一套客户）----
export const getDeployConfig = () => api('/api/deploy/config');
export const saveDeployConfig = (config) =>
  api('/api/deploy/config', { method: 'PUT', body: JSON.stringify({ config }) });
export const saveDeploySection = (name, patch) =>
  api(`/api/deploy/section/${name}`, { method: 'PUT', body: JSON.stringify(patch) });
export const listDeployTemplates = () => api('/api/deploy/templates');
export const applyDeployTemplate = (name) =>
  api('/api/deploy/apply-template', { method: 'POST', body: JSON.stringify({ name }) });
export const resetDeployConfig = () => api('/api/deploy/reset', { method: 'POST' });
export const applyDeployConfig = () =>
  api('/api/deploy/apply', { method: 'POST', body: '{}' });
// ---- P1 APIs ----
export const createSiteToken = (data) =>
  api('/api/sites', { method: 'POST', body: JSON.stringify(data) });
export const listSites = () => api('/api/sites');
export const deleteSite = (siteId) =>
  api(`/api/sites/${siteId}`, { method: 'DELETE' });
export const createSession = (data) =>
  api('/api/qa/sessions', { method: 'POST', body: JSON.stringify(data) });
export const getSessionHistory = (sessionId, limit = 10) =>
  api(`/api/qa/sessions/${sessionId}/history?limit=${limit}`);
export const submitFeedback = (data) =>
  api('/api/qa/feedback', { method: 'POST', body: JSON.stringify(data) });
export const getFeedback = (days = 7) =>
  api(`/api/qa/feedback?days=${days}`);
export const getWeeklyReport = () => api('/api/qa/weekly-report');

// ---- 知识库质量运营 ----
export const autoExtractKnowledge = (limit = 50) =>
  api('/api/knowledge/auto-extract', { method: 'POST', body: JSON.stringify({ limit }) });
export const recalcQuality = () =>
  api('/api/knowledge/recalc-quality', { method: 'POST' });
export const getReviewQueue = (threshold = 0.35) =>
  api('/api/knowledge/review-queue?threshold=' + encodeURIComponent(threshold));
export const getExtractCandidates = (limit = 50) =>
  api('/api/knowledge/extract-candidates?limit=' + encodeURIComponent(limit));

// ---- 场景化话术库 ----
export const listScripts = (status = '', scene = '') => {
  const p = new URLSearchParams();
  if (status) p.set('status', status);
  if (scene) p.set('scene', scene);
  return api('/api/scripts?' + p.toString());
};
export const generateScript = (knowledge_id) =>
  api('/api/scripts/generate', { method: 'POST', body: JSON.stringify({ knowledge_id }) });
export const publishScript = (id) =>
  api('/api/scripts/' + id + '/publish', { method: 'POST' });
export const unpublishScript = (id) =>
  api('/api/scripts/' + id + '/unpublish', { method: 'POST' });
export const updateScript = (id, body) =>
  api('/api/scripts/' + id, { method: 'PUT', body: JSON.stringify(body) });
export const deleteScript = (id) =>
  api('/api/scripts/' + id, { method: 'DELETE' });

// ---- 工单智能派发 ----
export const listAgents = () => api('/api/dispatch/agents');
export const routeDispatch = (content, category = '', urgency = 1) =>
  api('/api/dispatch/route', { method: 'POST', body: JSON.stringify({ content, category, urgency }) });
export const createAgent = (body) =>
  api('/api/dispatch/agents', { method: 'POST', body: JSON.stringify(body) });
export const updateAgent = (id, body) =>
  api('/api/dispatch/agents/' + id, { method: 'PUT', body: JSON.stringify(body) });
export const deleteAgent = (id) =>
  api('/api/dispatch/agents/' + id, { method: 'DELETE' });
// 确认派发：将工单分配给指定客服组
export const assignDispatch = (body) =>
  api('/api/dispatch/assign', { method: 'POST', body: JSON.stringify(body) });
// 释放工单：回收客服组负载
export const releaseDispatch = (ticket_id) =>
  api('/api/dispatch/release', { method: 'POST', body: JSON.stringify({ ticket_id }) });
