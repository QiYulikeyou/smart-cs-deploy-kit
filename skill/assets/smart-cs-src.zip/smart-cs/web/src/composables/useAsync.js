/**
 * 异步数据统一封装 —— 消除各组件里重复的 loading / error / data 三件套
 *
 * 用法：
 *   const { data, loading, error, run, refresh } = useAsync(() => listKnowledge(), { immediate: true })
 *
 * 约定：
 *   - data   响应式结果（默认 null）
 *   - loading 首次加载或刷新中为 true
 *   - error  错误信息字符串，null 表示无错
 *   - run    手动执行（可传参与原函数一致）
 *   - refresh 重新执行（沿用首次参数语义）
 */
import { ref, shallowRef, onMounted } from 'vue';

export function useAsync(fn, options = {}) {
  const {
    immediate = false,
    initial = null,
    onSuccess = null,
    onError = null,
    resetOnRun = true,
    manual = false // true 时不自动执行，也不在 mounted 执行
  } = options;

  const data = shallowRef(initial);
  const loading = ref(false);
  const error = ref(null);
  const loaded = ref(false);

  let lastArgs = [];

  async function run(...args) {
    if (args.length) lastArgs = args;
    loading.value = true;
    if (resetOnRun) error.value = null;
    try {
      const r = await fn(...args);
      data.value = r;
      loaded.value = true;
      if (onSuccess) onSuccess(r);
      return r;
    } catch (e) {
      error.value = e && e.message ? e.message : String(e);
      if (onError) onError(e);
      throw e;
    } finally {
      loading.value = false;
    }
  }

  function refresh() {
    return run(...lastArgs);
  }

  function reset() {
    data.value = initial;
    error.value = null;
    loaded.value = false;
  }

  if (!manual) {
    if (immediate) {
      run();
    } else {
      onMounted(() => run());
    }
  }

  return { data, loading, error, loaded, run, refresh, reset };
}

/**
 * 提交类操作（POST/PUT/DELETE）封装：只关心 pending 与错误
 * 用法：
 *   const { pending, submit } = useSubmit(publishKnowledge)
 *   await submit(id)
 */
export function useSubmit(fn, options = {}) {
  const { onSuccess = null, onError = null } = options;
  const pending = ref(false);

  async function submit(...args) {
    pending.value = true;
    try {
      const r = await fn(...args);
      if (onSuccess) onSuccess(r);
      return r;
    } catch (e) {
      if (onError) onError(e);
      throw e;
    } finally {
      pending.value = false;
    }
  }

  return { pending, submit };
}
