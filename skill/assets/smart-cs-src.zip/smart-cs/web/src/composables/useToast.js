/**
 * 全局轻提示 —— 替代各组件里零散的 alert() / 内联错误文案
 *
 * 用法：
 *   import { useToast } from '@/composables/useToast'
 *   const { success, error, warn, info } = useToast()
 *   success('已发布')
 *   error(err.message)
 */
import { reactive } from 'vue';

export const toastState = reactive({ items: [] });

let seq = 0;

function push(type, message, duration) {
  const id = ++seq;
  toastState.items.push({ id, type, message, duration });
  if (duration > 0) {
    setTimeout(() => dismiss(id), duration);
  }
  return id;
}

export function dismiss(id) {
  const i = toastState.items.findIndex((t) => t.id === id);
  if (i > -1) toastState.items.splice(i, 1);
}

export function clearToasts() {
  toastState.items.splice(0, toastState.items.length);
}

export function useToast() {
  return {
    toast: (msg, type = 'info', duration = 2600) => push(type, msg, duration),
    success: (msg, duration = 2400) => push('success', msg, duration),
    error: (msg, duration = 4000) => push('error', msg, duration),
    warn: (msg, duration = 3000) => push('warn', msg, duration),
    info: (msg, duration = 2600) => push('info', msg, duration),
    dismiss,
    clear: clearToasts
  };
}

/**
 * 把 Promise 包装成「成功提示 + 失败提示」
 * 常用于：保存、发布、删除这类一次性操作
 */
export async function withToast(promise, okMsg, opts = {}) {
  const { success, error } = useToast();
  try {
    const r = await promise;
    if (okMsg) success(okMsg);
    return r;
  } catch (e) {
    error(opts.errorMsg ? `${opts.errorMsg}：${e.message}` : e.message);
    if (opts.rethrow !== false) throw e;
    return null;
  }
}
