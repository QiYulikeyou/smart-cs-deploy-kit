/**
 * useQuality —— 质检中心数据层
 *
 * 把 Quality.vue 里 4 块互不相关的取数逻辑（指标 / 趋势 / 来源分布 / 预警）
 * 收敛到一个 composable，组件只负责渲染。
 * 保留原有行为：period 变更联动指标与来源分布、60s 轮询、卸载时清理定时器。
 */
import { ref, computed, onMounted, onUnmounted, watch } from 'vue';
import { detectQa, getAlerts, dismissAlert, getStats, getRiskTrend, getConversations } from '../api.js';
import { makeTrend, parseHits, actionHint, sourceMeta } from '../utils/risk.js';

const POLL_MS = 60000;

function pad(n) {
  return String(n).padStart(2, '0');
}
function dayStart(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} 00:00:00`;
}

export function useQuality() {
  // ===== 时间周期 =====
  const period = ref('today'); // today | week

  function periodRange() {
    const now = new Date();
    if (period.value === 'today') {
      const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      return { from: dayStart(now), to: dayStart(end) };
    }
    // 本周：从今天往前 6 天
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    return { from: dayStart(start), to: dayStart(end) };
  }

  // ===== 指标概览 =====
  const stats = ref({
    sessions: 0,
    prevSessions: 0,
    riskRate: '—',
    prevRiskRate: '—',
    unresolved: 0,
    avgRisk: 'low'
  });
  const statsLoading = ref(false);

  function sumSlice(arr, start, end) {
    return arr.slice(start, end).reduce(
      (acc, d) => ({
        total: acc.total + (d.total || 0),
        high: acc.high + (d.high || 0),
        mid: acc.mid + (d.mid || 0),
        low: acc.low + (d.low || 0)
      }),
      { total: 0, high: 0, mid: 0, low: 0 }
    );
  }

  async function refreshStats() {
    statsLoading.value = true;
    try {
      const s = await getStats();
      // 对比周期：今日 vs 昨日（2 天）；本周 vs 上周（14 天）
      const days = period.value === 'today' ? 2 : 14;
      const trend = await getRiskTrend(days);
      const data = trend.data || [];

      let current = { total: 0, high: 0, mid: 0, low: 0 };
      let previous = { total: 0, high: 0, mid: 0, low: 0 };

      if (period.value === 'today') {
        if (data.length >= 2) {
          current = data[data.length - 1];
          previous = data[data.length - 2];
        } else if (data.length === 1) {
          current = data[0];
        }
      } else if (data.length >= 14) {
        current = sumSlice(data, 7, 14);
        previous = sumSlice(data, 0, 7);
      } else if (data.length >= 7) {
        current = sumSlice(data, data.length - 7, data.length);
      }

      stats.value = {
        sessions: current.total,
        prevSessions: previous.total,
        riskRate:
          current.total > 0
            ? (((current.high + current.mid) / current.total) * 100).toFixed(1) + '%'
            : '—',
        prevRiskRate:
          previous.total > 0
            ? (((previous.high + previous.mid) / previous.total) * 100).toFixed(1) + '%'
            : '—',
        unresolved: s.alerts,
        avgRisk: current.high > 0 ? 'high' : current.mid > 0 ? 'mid' : 'low'
      };
    } catch (e) {
      console.warn('[quality:stats] fail', e);
    } finally {
      statsLoading.value = false;
    }
  }

  const safeRate = computed(() => {
    const v = parseFloat(stats.value.riskRate);
    return Number.isNaN(v) ? 0 : v;
  });
  const prevSafeRate = computed(() => {
    const v = parseFloat(stats.value.prevRiskRate);
    return Number.isNaN(v) ? 0 : v;
  });
  const qualityRate = computed(() => (100 - safeRate.value).toFixed(1) + '%');

  const sessionTrend = computed(() => makeTrend(stats.value.sessions, stats.value.prevSessions, 'pct'));
  const riskTrend = computed(() => makeTrend(safeRate.value, prevSafeRate.value, 'pp'));
  const qualityTrend = computed(() => {
    const prev = prevSafeRate.value;
    if (Number.isNaN(prev)) return { text: '—', up: null };
    const diff = -(safeRate.value - prev); // 质量率与风险率反向
    if (Math.abs(diff) < 0.05) return { text: '→ 持平', up: null };
    const sign = diff > 0 ? '+' : '';
    return { text: `${sign}${diff.toFixed(1)}pp 较上期`, up: diff > 0 };
  });

  // ===== 风险趋势 =====
  const trendDays = ref(7);
  const trendData = ref([]);
  const trendLoading = ref(false);

  async function loadTrend() {
    trendLoading.value = true;
    try {
      const r = await getRiskTrend(trendDays.value);
      trendData.value = (r.data || []).map((d) => ({
        date: d.date || '',
        total: d.total || 0,
        high: d.high || 0,
        mid: d.mid || 0,
        low: d.low || 0
      }));
    } catch (e) {
      console.warn('[quality:trend] fail', e);
    } finally {
      trendLoading.value = false;
    }
  }

  // ===== 会话来源分布 =====
  const sourceDist = ref([]);
  const sourceLoading = ref(false);

  async function loadSourceDist() {
    sourceLoading.value = true;
    try {
      const range = periodRange();
      const r = await getConversations(100, 0, { from: range.from, to: range.to });
      const map = {};
      (r.items || []).forEach((item) => {
        const src = item.source || 'unknown';
        map[src] = (map[src] || 0) + 1;
      });
      sourceDist.value = Object.entries(map)
        .map(([k, v]) => ({ source: k, count: v }))
        .sort((a, b) => b.count - a.count);
    } catch (e) {
      console.warn('[quality:source] fail', e);
      sourceDist.value = [];
    } finally {
      sourceLoading.value = false;
    }
  }

  const sourceTotal = computed(() => sourceDist.value.reduce((a, b) => a + b.count, 0));
  const sourceDistDisplay = computed(() => {
    const total = sourceTotal.value || 1;
    return sourceDist.value.map((s) => ({
      ...s,
      ...sourceMeta(s.source),
      pct: Math.round((s.count / total) * 100)
    }));
  });

  // ===== 预警列表 =====
  const alerts = ref([]);
  const alertsLoading = ref(false);
  const alertsFilter = ref('all');
  const searchQuery = ref('');

  async function refreshAlerts() {
    alertsLoading.value = true;
    try {
      const list = await getAlerts();
      alerts.value = list.map((a) => ({
        ...a,
        user_text_short: (a.user_text || '').slice(0, 100),
        hits_text: parseHits(a.sensitive_hits),
        action_hint: actionHint(a)
      }));
    } catch (e) {
      console.warn('[quality:alerts] fail', e);
      alerts.value = [];
    } finally {
      alertsLoading.value = false;
    }
  }

  const filteredAlerts = computed(() => {
    let list = alerts.value;
    if (alertsFilter.value !== 'all') {
      list = list.filter((a) => (a.risk_level || '').toLowerCase() === alertsFilter.value);
    }
    const q = searchQuery.value.trim().toLowerCase();
    if (q) list = list.filter((a) => (a.user_text || '').toLowerCase().includes(q));
    return list;
  });

  const alertCounts = computed(() => ({
    all: alerts.value.length,
    high: alerts.value.filter((a) => a.risk_level === 'high').length,
    mid: alerts.value.filter((a) => a.risk_level === 'mid').length,
    low: alerts.value.filter((a) => a.risk_level === 'low').length
  }));

  async function onDismiss(a) {
    try {
      await dismissAlert(a.id);
      alerts.value = alerts.value.filter((x) => x.id !== a.id);
    } catch (e) {
      console.warn('[quality:dismiss] fail', e);
    }
  }

  // ===== 快速检测 =====
  const detectText = ref('');
  const detectResult = ref(null);
  const detectLoading = ref(false);
  const detectErr = ref('');

  async function onDetect() {
    if (!detectText.value.trim()) {
      detectErr.value = '请输入检测内容';
      return;
    }
    detectLoading.value = true;
    detectErr.value = '';
    detectResult.value = null;
    try {
      detectResult.value = await detectQa(detectText.value);
    } catch (e) {
      detectErr.value = e.message;
    } finally {
      detectLoading.value = false;
    }
  }

  function resetDetect() {
    detectText.value = '';
    detectResult.value = null;
    detectErr.value = '';
  }

  // ===== 生命周期 =====
  let timer = null;

  function refreshAll() {
    refreshStats();
    loadTrend();
    loadSourceDist();
    refreshAlerts();
  }

  watch(period, () => {
    refreshStats();
    loadSourceDist();
  });

  onMounted(() => {
    refreshAll();
    timer = setInterval(refreshAll, POLL_MS);
  });

  onUnmounted(() => {
    if (timer) clearInterval(timer);
    timer = null;
  });

  return {
    // 周期
    period,
    // 指标
    stats,
    statsLoading,
    qualityRate,
    sessionTrend,
    riskTrend,
    qualityTrend,
    // 趋势
    trendDays,
    trendData,
    trendLoading,
    loadTrend,
    // 来源
    sourceDistDisplay,
    sourceTotal,
    sourceLoading,
    // 预警
    alerts,
    alertsLoading,
    alertsFilter,
    searchQuery,
    filteredAlerts,
    alertCounts,
    refreshAlerts,
    onDismiss,
    // 检测
    detectText,
    detectResult,
    detectLoading,
    detectErr,
    onDetect,
    resetDetect,
    // 全局
    refreshAll
  };
}
