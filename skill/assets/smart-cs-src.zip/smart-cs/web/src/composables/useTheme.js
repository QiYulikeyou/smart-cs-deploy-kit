/**
 * 主题 composable —— 明暗双主题 + 背景自定义
 *
 * 与 v1 的关系：完整保留原 theme.js 的背景自定义能力（预设渐变 / 纯色 / 图片），
 * 新增明暗主题切换。两套能力正交：
 *   - 主题（mode）决定面板、文本、边框的配色
 *   - 背景（bg）决定整个应用底图
 * 切换主题时，若用户未自定义过背景，自动套用该主题的配套渐变；
 * 若用户自定义过，则尊重用户选择不动。
 */
import { reactive, watch, computed } from 'vue';

const STORAGE_KEY = 'scs_theme_v2';
const LEGACY_BG_KEY = 'scs_bg'; // v1 遗留键，用于平滑迁移

/* ---------- 预设背景 ---------- */
export const DARK_PRESETS = [
  { id: 'aurora', name: '极光蓝', value: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 45%, #0ea5e9 100%)' },
  { id: 'neon', name: '霓虹紫', value: 'linear-gradient(135deg, #1a0b2e 0%, #4c1d95 50%, #db2777 100%)' },
  { id: 'cyber', name: '赛博绿', value: 'linear-gradient(135deg, #03120b 0%, #064e3b 50%, #10b981 100%)' },
  { id: 'sunset', name: '熔金橙', value: 'linear-gradient(135deg, #1f1300 0%, #7c2d12 50%, #f59e0b 100%)' },
  { id: 'mono', name: '深空灰', value: 'linear-gradient(135deg, #0b0f19 0%, #1f2937 55%, #374151 100%)' },
  { id: 'ice', name: '冰川蓝', value: 'linear-gradient(135deg, #082f49 0%, #0c4a6e 50%, #0891b2 100%)' }
];

export const LIGHT_PRESETS = [
  { id: 'dawn', name: '晨曦白', value: 'linear-gradient(135deg, #f8fafc 0%, #e0f2fe 50%, #bae6fd 100%)' },
  { id: 'marble', name: '云石灰', value: 'linear-gradient(135deg, #f8fafc 0%, #e9eef5 50%, #dbe3ec 100%)' },
  { id: 'mint', name: '薄荷绿', value: 'linear-gradient(135deg, #f0fdfa 0%, #d1fae5 50%, #a7f3d0 100%)' },
  { id: 'sand', name: '暖沙金', value: 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 50%, #fde68a 100%)' },
  { id: 'lilac', name: '淡紫罗', value: 'linear-gradient(135deg, #faf5ff 0%, #f3e8ff 50%, #e9d5ff 100%)' },
  { id: 'sky', name: '晴空蓝', value: 'linear-gradient(135deg, #f0f9ff 0%, #dbeafe 50%, #bfdbfe 100%)' }
];

/** 兼容 v1 引用：BgSwitcher 等处仍在用 PRESET_THEMES */
export const PRESET_THEMES = DARK_PRESETS;

export function presetsFor(mode) {
  return mode === 'light' ? LIGHT_PRESETS : DARK_PRESETS;
}

/* ---------- 状态 ---------- */
function defaultState(mode = 'dark') {
  const list = presetsFor(mode);
  return { mode, bg: { type: 'gradient', value: list[0].value, name: list[0].name }, custom: false };
}

function load() {
  // 优先读 v2 键；否则尝试迁移 v1 的背景设置
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s && (s.mode === 'dark' || s.mode === 'light')) {
        return {
          mode: s.mode,
          bg: s.bg || defaultState(s.mode).bg,
          custom: !!s.custom
        };
      }
    }
    const legacy = localStorage.getItem(LEGACY_BG_KEY);
    if (legacy) {
      const l = JSON.parse(legacy);
      return {
        mode: 'dark',
        bg: { type: l.type || 'gradient', value: l.value || DARK_PRESETS[0].value, name: l.name || '自定义' },
        custom: true // v1 用户若存过，视为自定义，迁移后不被主题切换覆盖
      };
    }
  } catch {}
  return defaultState('dark');
}

export const themeState = reactive(load());

/* ---------- 副作用：写 DOM + 持久化 ---------- */
function applyToDom() {
  const root = document.documentElement;
  root.setAttribute('data-theme', themeState.mode);
}

function persist() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ mode: themeState.mode, bg: { ...themeState.bg }, custom: themeState.custom })
    );
  } catch {}
}

applyToDom();
persist();

watch(themeState, () => {
  applyToDom();
  persist();
}, { deep: true });

/* ---------- 对外 API ---------- */

/** 当前是否为深色模式 */
export const isDark = computed(() => themeState.mode === 'dark');

/** 切换明暗主题 */
export function toggleTheme() {
  const next = themeState.mode === 'dark' ? 'light' : 'dark';
  themeState.mode = next;
  // 未自定义过背景 → 自动套用该主题的默认渐变
  if (!themeState.custom) {
    const p = presetsFor(next)[0];
    themeState.bg = { type: 'gradient', value: p.value, name: p.name };
  }
  return next;
}

export function setTheme(mode) {
  if (mode !== 'dark' && mode !== 'light') return;
  themeState.mode = mode;
  if (!themeState.custom) {
    const p = presetsFor(mode)[0];
    themeState.bg = { type: 'gradient', value: p.value, name: p.name };
  }
}

/** 应用背景到根容器（返回 style 对象，供 :style 绑定） */
export function applyBackground() {
  const bg = themeState.bg;
  if (bg.type === 'image' && bg.value) {
    return {
      backgroundImage: `url(${bg.value})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      backgroundAttachment: 'fixed'
    };
  }
  return { backgroundImage: bg.value, backgroundAttachment: 'fixed' };
}

export const bgStyle = computed(() => applyBackground());

export function setGradient(value, name) {
  themeState.bg = { type: 'gradient', value, name: name || '自定义渐变' };
  themeState.custom = true;
}

export function setImage(url) {
  themeState.bg = { type: 'image', value: url, name: '自定义图片' };
  themeState.custom = true;
}

export function setColor(hex) {
  themeState.bg = {
    type: 'gradient',
    value: `radial-gradient(circle at 30% 20%, ${hex} 0%, ${shade(hex, -28)} 100%)`,
    name: '自定义颜色'
  };
  themeState.custom = true;
}

/** 恢复当前主题的默认背景 */
export function resetBackground() {
  const p = presetsFor(themeState.mode)[0];
  themeState.bg = { type: 'gradient', value: p.value, name: p.name };
  themeState.custom = false;
}

/** hex 颜色加深/变亮 */
function shade(hex, percent) {
  const n = parseInt(String(hex).replace('#', ''), 16);
  let r = (n >> 16) & 255;
  let g = (n >> 8) & 255;
  let b = n & 255;
  r = Math.max(0, Math.min(255, r + Math.round((255 * percent) / 100)));
  g = Math.max(0, Math.min(255, g + Math.round((255 * percent) / 100)));
  b = Math.max(0, Math.min(255, b + Math.round((255 * percent) / 100)));
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}
