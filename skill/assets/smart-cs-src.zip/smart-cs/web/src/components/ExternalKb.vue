<!--
  飞书/IMA 外部知识库同步：拉取后自动以 source_type∈{feishu,ima} 落库，并用统一卡片展示
  四个功能区：一键同步（已配置库）/ 立即同步 / LLM 提炼 FAQ / 定时自动同步
  v2：面板改用 SCard，表单改用 UI 组件库；知识库选择由「对象绑定」改为「id 绑定 + computed」，
      切换来源时自动选中该来源的第一个库（v1 需手动重选，是个隐性 bug）
-->
<script setup>
import { ref, computed, watch, onMounted } from 'vue';
import {
  syncExternalKnowledge,
  getSyncStatus,
  setSyncConfig,
  listKnowledge,
  updateKnowledge,
  deleteKnowledge,
  listKbSources,
  extractFaq,
  publishKnowledge,
  unpublishKnowledge,
  syncKbByName
} from '../api.js';
import KnowledgeCard from './KnowledgeCard.vue';
import SCard from './ui/SCard.vue';
import SButton from './ui/SButton.vue';
import SInput from './ui/SInput.vue';
import SSelect from './ui/SSelect.vue';
import SModal from './ui/SModal.vue';
import SEmpty from './ui/SEmpty.vue';
import SBadge from './ui/SBadge.vue';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const syncing = ref(false);
const syncMsg = ref('');
const syncSrc = ref('feishu');
const syncKeyword = ref('常见问题');
const syncStatus = ref({ lastSync: null, syncStatus: 'idle', configured: false });
const autoSyncCron = ref('0 3 * * *');
const autoSyncKeyword = ref('常见问题');
const autoSyncEnabled = ref(true);
const savingConfig = ref(false);

/* 知识库列表（来自 /api/knowledge/kb-list） */
const kbSources = ref([]);
const selectedKbId = ref('');
const selectedKb = computed(() => kbSources.value.find((k) => k.id === selectedKbId.value) || null);
const kbOptions = computed(() =>
  kbSources.value
    .filter((k) => k.provider === syncSrc.value)
    .map((k) => ({ value: k.id, label: k.name }))
);

/* 切换来源时，自动选中该来源的第一个知识库 */
watch(kbOptions, (opts) => {
  if (!opts.some((o) => o.value === selectedKbId.value)) {
    selectedKbId.value = opts.length ? opts[0].value : '';
  }
});

/* LLM 提炼 FAQ */
const extracting = ref(false);
const extractedItems = ref([]);
const showExtracted = ref(false);

/* 快捷一键同步（仅飞书 + AI Agent IMA） */
const QUICK_SYNC_TARGETS = [
  { source: 'feishu', name: '飞书知识库', label: '📄 飞书' },
  { source: 'ima', name: 'AI Agent在中小企业落地研究', label: '🤖 AI Agent' }
];
const syncingKbs = ref({});
const syncKbMsg = ref('');

const knowledge = ref([]);
const total = ref(0);
const loading = ref(false);
const err = ref('');
const statusFilter = ref('');

const SOURCES = ['feishu', 'ima'];

const SOURCE_OPTIONS = [
  { value: 'feishu', label: '飞书' },
  { value: 'ima', label: 'IMA' }
];

const STATUS_OPTIONS = [
  { value: '', label: '全部状态' },
  { value: 'published', label: '已发布' },
  { value: 'draft', label: '草稿' }
];

const URGENCY_OPTIONS = [
  { value: 1, label: '一般' },
  { value: 2, label: '较急' },
  { value: 3, label: '紧急' }
];

/* 编辑弹窗 */
const editing = ref(null);
const form = ref({ question: '', solution: '', category: '其他', product_module: '', urgency: 1 });
const saving = ref(false);
const pendingDelete = ref(null);

const lastSyncText = computed(() =>
  syncStatus.value.lastSync ? new Date(syncStatus.value.lastSync).toLocaleString('zh-CN') : ''
);

async function loadKnowledge() {
  loading.value = true;
  err.value = '';
  try {
    const r = await listKnowledge(200, 0, SOURCES.join(','), '', statusFilter.value);
    knowledge.value = r.rows || [];
    total.value = r.total || 0;
  } catch (e) {
    err.value = e.message;
  } finally {
    loading.value = false;
  }
}

async function onPublish(item) {
  try {
    await publishKnowledge(item.id);
    success('已发布');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function onUnpublish(item) {
  try {
    await unpublishKnowledge(item.id);
    success('已撤下');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function loadSyncStatus() {
  try {
    syncStatus.value = await getSyncStatus();
  } catch {}
}

async function loadKbSources() {
  try {
    const r = await listKbSources();
    if (r.ok && Array.isArray(r.knowledge_bases)) {
      kbSources.value = r.knowledge_bases;
      const first = r.knowledge_bases.find((k) => k.provider === syncSrc.value);
      if (first) selectedKbId.value = first.id;
    }
  } catch (e) {
    console.warn('[ExternalKb] 加载知识库列表失败:', e.message);
  }
}

function buildPayload(extra = {}) {
  const payload = { source: syncSrc.value, keyword: syncKeyword.value, ...extra };
  // 携带具体知识库 ID（飞书传 space_id，IMA 传 kb_id）
  if (selectedKb.value) {
    payload[syncSrc.value === 'feishu' ? 'space_id' : 'kb_id'] = selectedKb.value.id;
    if (syncSrc.value === 'ima') payload.kb_name = selectedKb.value.name;
  }
  return payload;
}

async function onSync() {
  syncing.value = true;
  syncMsg.value = '';
  try {
    const r = await syncExternalKnowledge(buildPayload());
    if (r.ok) {
      syncMsg.value = `✓ 同步完成：读取 ${r.docs ?? 0} 篇文档，提炼新增 ${r.added} 条 FAQ，跳过 ${r.skipped ?? 0} 条`;
      success(syncMsg.value);
      await loadSyncStatus();
      await loadKnowledge();
    } else {
      syncMsg.value = '⚠ ' + (r.error || '同步失败');
      toastError(syncMsg.value);
    }
  } catch (e) {
    syncMsg.value = '⚠ ' + e.message;
    toastError(syncMsg.value);
  } finally {
    syncing.value = false;
  }
}

/* 一键同步指定库（先删旧条目，再重新提炼入库） */
async function onSyncKb(target) {
  syncingKbs.value[target.name] = true;
  syncKbMsg.value = `正在同步「${target.name}」…`;
  try {
    const r = await syncKbByName(target.source, target.name);
    if (r.ok) {
      syncKbMsg.value = `✓ ${target.label}：删除 ${r.deleted ?? 0} 条旧条目，新增 ${r.added ?? 0} 条 FAQ，跳过 ${r.skipped ?? 0} 条`;
      success(syncKbMsg.value);
      await loadKnowledge();
    } else {
      syncKbMsg.value = '⚠ ' + (r.error || '同步失败');
      toastError(syncKbMsg.value);
    }
  } catch (e) {
    syncKbMsg.value = '⚠ ' + e.message;
    toastError(syncKbMsg.value);
  } finally {
    syncingKbs.value[target.name] = false;
  }
}

/* 调用 LLM 提炼 FAQ */
async function onExtractFaq() {
  extracting.value = true;
  showExtracted.value = true;
  try {
    const r = await extractFaq(buildPayload({ limit: 10 }));
    if (r.ok) {
      extractedItems.value = r.items || [];
      success(`提炼完成：共 ${r.count ?? extractedItems.value.length} 条 FAQ`);
    } else {
      toastError(r.error || '提炼失败');
      extractedItems.value = [];
    }
  } catch (e) {
    toastError(e.message);
  } finally {
    extracting.value = false;
  }
}

async function onSaveAutoSync() {
  savingConfig.value = true;
  try {
    await setSyncConfig({ cron: autoSyncCron.value, keyword: autoSyncKeyword.value });
    syncMsg.value = '✓ 自动同步配置已更新（cron：' + autoSyncCron.value + '）';
    success(syncMsg.value);
  } catch (e) {
    syncMsg.value = '⚠ ' + e.message;
    toastError(syncMsg.value);
  } finally {
    savingConfig.value = false;
  }
}

function openEdit(item) {
  editing.value = item;
  form.value = {
    question: item.question || '',
    solution: item.solution || '',
    category: item.category || '其他',
    product_module: item.product_module || '',
    urgency: item.urgency || 1
  };
}

async function save() {
  if (!form.value.question.trim()) {
    toastError('问题不能为空');
    return;
  }
  saving.value = true;
  try {
    if (editing.value && editing.value.id) {
      await updateKnowledge(editing.value.id, form.value);
      success('已更新');
    }
    editing.value = null;
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  } finally {
    saving.value = false;
  }
}

async function doDelete() {
  const item = pendingDelete.value;
  if (!item) return;
  try {
    await deleteKnowledge(item.id);
    success('已删除');
    pendingDelete.value = null;
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

onMounted(async () => {
  await Promise.all([loadKnowledge(), loadSyncStatus(), loadKbSources()]);
});
</script>

<template>
  <div class="ext">
    <!-- ===== 一键同步 ===== -->
    <SCard icon="🚀" title="一键同步（已配置库）" class="mb">
      <div class="row">
        <SButton
          v-for="t in QUICK_SYNC_TARGETS"
          :key="t.source + '|' + t.name"
          variant="default"
          :class="{ 'is-busy': syncingKbs[t.name] }"
          :loading="syncingKbs[t.name]"
          @click="onSyncKb(t)"
        >
          {{ t.label }}
        </SButton>
        <span v-if="syncKbMsg" class="tip-msg">{{ syncKbMsg }}</span>
      </div>
      <p class="meta muted">自动按 knowledge_base_name 清理旧条目，并重新用 LLM 提炼 FAQ 入库。</p>
    </SCard>

    <!-- ===== 立即同步 ===== -->
    <SCard icon="🔗" title="立即同步" class="mb">
      <div class="row">
        <SSelect v-model="syncSrc" :options="SOURCE_OPTIONS" size="sm" class="w110" />
        <SSelect
          v-model="selectedKbId"
          :options="kbOptions"
          size="sm"
          placeholder="未配置知识库"
          class="w200"
        />
        <SInput v-model="syncKeyword" size="sm" placeholder="检索词，如：常见问题" class="w180" />
        <SButton size="sm" variant="primary" :loading="syncing" @click="onSync">立即同步</SButton>
        <SButton size="sm" variant="ghost" :loading="extracting" @click="onExtractFaq">
          ✨ LLM 提炼 FAQ
        </SButton>
      </div>

      <p v-if="syncMsg" class="tip-msg mt">{{ syncMsg }}</p>

      <div class="meta">
        <span v-if="lastSyncText" class="muted">上次同步：{{ lastSyncText }}</span>
        <span v-if="selectedKb" class="ok-tip">✓ 当前知识库：{{ selectedKb.name }}</span>
        <span v-else-if="kbSources.length === 0" class="warn-tip">
          ⚠ 未检测到可用知识库（请检查飞书/IMA 配置）
        </span>
      </div>
    </SCard>

    <!-- ===== LLM 提炼结果 ===== -->
    <SCard v-if="showExtracted" icon="🤖" title="LLM 自动提炼 FAQ" class="mb">
      <template #actions>
        <SBadge tone="brand" size="sm">{{ extractedItems.length }} 条</SBadge>
        <SButton size="sm" variant="link" @click="showExtracted = false">收起</SButton>
      </template>

      <SEmpty
        v-if="!extractedItems.length"
        icon="🤖"
        title="暂无提炼结果"
        desc="请检查源内容是否丰富，或换个检索词再试"
        compact
      />

      <div v-else class="extracted-list">
        <div v-for="(faq, idx) in extractedItems" :key="idx" class="extracted-item">
          <div class="q">{{ faq.question }}</div>
          <div class="a">{{ faq.solution || '(无答案)' }}</div>
          <div class="imeta">{{ faq.knowledge_base_name || '未知知识库' }} · {{ faq.source }}</div>
        </div>
      </div>
    </SCard>

    <!-- ===== 定时自动同步 ===== -->
    <SCard icon="⏰" title="定时自动同步" class="mb">
      <div class="row">
        <label class="chk-label">
          <input v-model="autoSyncEnabled" type="checkbox" class="cbx" @change="onSaveAutoSync" />
          启用自动同步
        </label>
        <SInput v-model="autoSyncCron" size="sm" placeholder="cron 表达式" class="w140" />
        <SInput v-model="autoSyncKeyword" size="sm" placeholder="自动同步检索词" class="w160" />
        <SButton size="sm" variant="ghost" :loading="savingConfig" @click="onSaveAutoSync">
          保存配置
        </SButton>
      </div>
      <p class="meta muted">
        自动同步按 cron 计划（默认每日 03:00）拉取「{{ autoSyncKeyword || '常见问题' }}」相关条目。
      </p>
    </SCard>

    <!-- ===== 已同步条目 ===== -->
    <SCard icon="📚" title="已同步的知识条目" :subtitle="`source_type ∈ feishu, ima · 共 ${total} 条`">
      <template #actions>
        <SSelect v-model="statusFilter" :options="STATUS_OPTIONS" size="sm" class="w130" @change="loadKnowledge" />
        <SButton size="sm" variant="ghost" @click="loadKnowledge">刷新</SButton>
      </template>

      <SEmpty v-if="err" error :desc="err" @retry="loadKnowledge" />

      <SEmpty
        v-else-if="!loading && knowledge.length === 0"
        icon="🔗"
        title="暂无飞书/IMA 同步的知识条目"
        desc="请先配置来源后点击「立即同步」"
      />

      <SEmpty v-else-if="loading" loading />

      <div v-else class="grid">
        <KnowledgeCard
          v-for="item in knowledge"
          :key="item.id"
          :item="item"
          @edit="openEdit"
          @delete="(i) => (pendingDelete = i)"
          @publish="onPublish"
          @unpublish="onUnpublish"
        />
      </div>
    </SCard>

    <!-- 编辑弹窗 -->
    <SModal :model-value="!!editing" @update:model-value="editing = null" :title="editing?.id ? '编辑知识' : '新增知识'" width="580px">
      <template v-if="editing">
        <div class="field">
          <label>问题（用于向量化检索）</label>
          <SInput v-model="form.question" placeholder="如：客户要退款怎么处理？" />
        </div>
        <div class="field">
          <label>标准话术 / 解决方案</label>
          <SInput v-model="form.solution" type="textarea" :rows="4" placeholder="坐席可直接发送给客户的回复" />
        </div>
        <div class="row2">
          <div class="field">
            <label>分类</label>
            <SInput v-model="form.category" placeholder="售后-退款" />
          </div>
          <div class="field">
            <label>模块</label>
            <SInput v-model="form.product_module" placeholder="订单" />
          </div>
        </div>
        <div class="field">
          <label>优先级</label>
          <SSelect v-model="form.urgency" :options="URGENCY_OPTIONS" />
        </div>
      </template>

      <template #footer>
        <SButton variant="ghost" @click="editing = null">取消</SButton>
        <SButton variant="primary" :loading="saving" @click="save">保存</SButton>
      </template>
    </SModal>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" @update:model-value="pendingDelete = null" title="确认删除" width="420px">
      <p class="confirm-text">
        确认删除「<strong>{{ pendingDelete?.question }}</strong>」？此操作不可撤销。
      </p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" @click="doDelete">删除</SButton>
      </template>
    </SModal>
  </div>
</template>

<style scoped>
.ext {
  color: var(--text-2);
}

.mb {
  margin-bottom: var(--sp-4);
}

.row {
  display: flex;
  gap: var(--sp-2);
  align-items: center;
  flex-wrap: wrap;
}

.mt {
  margin-top: var(--sp-3);
}

.w110 {
  min-width: 110px;
}
.w130 {
  min-width: 130px;
}
.w140 {
  min-width: 140px;
}
.w160 {
  min-width: 160px;
}
.w180 {
  min-width: 180px;
}
.w200 {
  min-width: 200px;
  max-width: 260px;
}

.meta {
  margin: var(--sp-3) 0 0;
  display: flex;
  gap: var(--sp-4);
  align-items: center;
  flex-wrap: wrap;
}

.muted {
  color: var(--text-4);
  font-size: var(--fs-sm);
}

.tip-msg {
  color: var(--success-text);
  font-size: var(--fs-sm);
  margin: 0;
  word-break: break-word;
}

.ok-tip {
  color: var(--success-text);
  font-size: var(--fs-sm);
}

.warn-tip {
  color: var(--warn-text);
  font-size: var(--fs-sm);
}

.chk-label {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
  color: var(--text-3);
  font-size: var(--fs-base);
  cursor: pointer;
}

.cbx {
  accent-color: var(--brand);
  cursor: pointer;
}

.is-busy {
  animation: scs-pulse 1.2s infinite;
}

/* ===== LLM 提炼结果 ===== */
.extracted-list {
  max-height: 400px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: var(--sp-2);
}

.extracted-item {
  padding: var(--sp-3);
  background: var(--overlay-0);
  border-radius: var(--r-md);
  border: 1px solid var(--border);
}

.extracted-item .q {
  color: var(--brand);
  font-weight: var(--fw-semibold);
  font-size: var(--fs-md);
  margin-bottom: var(--sp-2);
  word-break: break-word;
}

.extracted-item .a {
  color: var(--text-3);
  font-size: var(--fs-base);
  line-height: 1.6;
  margin-bottom: var(--sp-2);
  white-space: pre-wrap;
  word-break: break-word;
}

.imeta {
  color: var(--text-4);
  font-size: var(--fs-xs);
}

/* ===== 列表 ===== */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
  gap: var(--sp-3);
}

@media (max-width: 720px) {
  .grid {
    grid-template-columns: 1fr;
  }
}

/* ===== 弹窗表单 ===== */
.field {
  margin-bottom: var(--sp-4);
}

.field label {
  display: block;
  font-size: var(--fs-sm);
  color: var(--text-3);
  margin-bottom: var(--sp-2);
}

.row2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
}

.confirm-text {
  margin: 0;
  line-height: 1.7;
  color: var(--text-2);
}
.confirm-text strong {
  color: var(--text-1);
  word-break: break-word;
}
</style>
