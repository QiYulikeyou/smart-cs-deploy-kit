<script setup>
/**
 * 登录网关 —— 未登录时全屏覆盖
 * v2：接入设计系统 token + SInput/SButton，浅色主题下同样可读
 */
import { ref } from 'vue';
import { login, setAuth, getMe } from '../api.js';
import SInput from './ui/SInput.vue';
import SButton from './ui/SButton.vue';
import { isDark, toggleTheme } from '../composables/useTheme.js';

const props = defineProps({ backendUp: Boolean });
const emit = defineEmits(['authed']);

const form = ref({ username: '', password: '' });
const err = ref('');
const loading = ref(false);

async function onSubmit() {
  err.value = '';
  loading.value = true;
  try {
    const r = await login(form.value.username, form.value.password);
    if (!r || !r.token) {
      err.value = (r && r.error) || '登录失败：未返回 token';
      return;
    }
    setAuth(r.token, r.user);
    // 再用 /me 校准一次最新用户信息（getMe 返回 { user: {...} }，需解包）
    try {
      const me = await getMe();
      const u = me.user || me;
      r.user = u;
      setAuth(r.token, u);
    } catch {}
    emit('authed', r.user);
  } catch (e) {
    err.value = e.message || '登录失败';
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <div class="login-wrap">
    <div class="login-card">
      <button class="theme-float" :title="isDark ? '切换浅色' : '切换深色'" @click="toggleTheme">
        {{ isDark ? '☀' : '☾' }}
      </button>

      <div class="logo">
        <span class="dot"></span>
        <span>智能客服中枢</span>
      </div>

      <h2>欢迎回来</h2>
      <p class="sub">AI Customer Service Console</p>

      <div v-if="!backendUp" class="banner">
        ⚠ 无法连接后端服务，请确认后端已在
        <code>:3200</code>
        运行。
      </div>

      <SInput v-model="form.username" placeholder="用户名" size="md" @enter="onSubmit" />
      <SInput
        v-model="form.password"
        type="password"
        placeholder="密码"
        size="md"
        class="gap"
        @enter="onSubmit"
      />

      <SButton variant="primary" size="lg" block :loading="loading" class="submit" @click="onSubmit">
        {{ loading ? '认证中…' : '登 录' }}
      </SButton>

      <p v-if="err" class="err">{{ err }}</p>
      <p class="hint">默认账号 admin / admin123（首次 seed 创建）</p>
    </div>
  </div>
</template>

<style scoped>
.login-wrap {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--sp-5);
}

.login-card {
  position: relative;
  width: 372px;
  max-width: 100%;
  padding: var(--sp-10) var(--sp-8) var(--sp-8);
  border-radius: var(--r-2xl);
  background: var(--surface-1);
  border: 1px solid var(--border-strong);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: var(--shadow-lg);
  text-align: center;
  animation: scs-pop var(--dur-slow) var(--ease-out);
}

.theme-float {
  position: absolute;
  top: var(--sp-4);
  right: var(--sp-4);
  width: 30px;
  height: 30px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--r-md);
  border: 1px solid var(--border);
  background: var(--overlay-1);
  color: var(--text-3);
  cursor: pointer;
  font-size: var(--fs-sm);
  line-height: 1;
  transition: var(--dur-fast) var(--ease);
}
.theme-float:hover {
  border-color: var(--brand);
  color: var(--brand);
}

.logo {
  font-size: var(--fs-md);
  letter-spacing: 2px;
  color: var(--brand-soft);
  display: flex;
  gap: var(--sp-2);
  align-items: center;
  justify-content: center;
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--brand);
  box-shadow: 0 0 12px var(--brand);
  animation: scs-pulse 1.6s infinite;
}

h2 {
  margin: var(--sp-5) 0 var(--sp-1);
  font-size: var(--fs-2xl);
  font-weight: var(--fw-bold);
  color: var(--text-1);
}

.sub {
  margin: 0 0 var(--sp-7);
  font-size: var(--fs-xs);
  color: var(--text-4);
  letter-spacing: 1px;
}

.gap {
  margin-top: var(--sp-3);
}

.submit {
  margin-top: var(--sp-5);
  letter-spacing: 4px;
}

.err {
  color: var(--danger-text);
  font-size: var(--fs-sm);
  margin: var(--sp-3) 0 0;
  word-break: break-word;
}

.hint {
  color: var(--text-4);
  font-size: var(--fs-xs);
  margin: var(--sp-4) 0 0;
}

.banner {
  background: var(--danger-soft);
  border: 1px solid rgba(248, 113, 113, 0.4);
  color: var(--danger-text);
  padding: var(--sp-3);
  border-radius: var(--r-md);
  font-size: var(--fs-xs);
  margin-bottom: var(--sp-4);
  text-align: left;
  line-height: 1.6;
}

.banner code {
  background: var(--code-bg);
  color: var(--code-text);
  padding: 1px 5px;
  border-radius: var(--r-xs);
  font-size: var(--fs-xs);
}
</style>
