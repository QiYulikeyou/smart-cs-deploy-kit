<script setup>
/**
 * 场景化话术库（v2）
 * 功能保持：话术库列表（状态/场景筛选、查看、编辑、发布、撤下、删除）、从知识条目生成
 * 优化：SCard 容器 + STabs 双视图 + UI 组件库 + SModal 弹窗 + Toast 反馈
 */
import { ref, computed, onMounted } from 'vue';
import {
  listScripts,
  generateScript,
  publishScript,
  unpublishScript,
  deleteScript,
  updateScript,
  listKnowledge
} from '../api.js';
import { SCard, STabs, SButton, SSelect, SInput, SModal, SEmpty, SBadge } from './ui';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const TABS = [
  { id: 'library', label: '话术库', icon: '📖', sub: '已生成的场景话术' },
  { id: 'generate', label: '从知识条目生成', icon: '✨', sub: 'LLM 生成多轮话术' }
];

const tab = ref('library');
const rows = ref([]);
const total = ref(0);
const loading = ref(false);
const err = ref('');
const statusFilter = ref('');
const sceneFilter = ref('');

const STATUS_OPTIONS = [
  { value: '', label: '全部状态' },
  { value: 'draft', label: '草稿' },
  { value: 'published', label: '已发布' }
];

// 生成：从知识条目
const knowList = ref([]);
const knowId = ref('');
const generating = ref(false);

// 弹窗
const viewing = ref(null);
const editing = ref(null);
const editForm = ref({ scene: '', trigger_cond: '', turnsText: '' });
const editMsg = ref('');
const saving = ref(false);
const pendingDelete = ref(null);

const knowOptions = computed(() => [
  { value: '', label: '— 选择知识条目 —' },
  ...knowList.value.map((k) => ({ value: k.id, label: `#${k.id} ${k.question}` }))
]);

async function refresh() {
  loading.value = true;
  err.value = '';
  try {
    const r = await listScripts(statusFilter.value, sceneFilter.value);
    rows.value = r.rows || [];
    total.value = r.total || 0;
  } catch (e) {
    err.value = e.message;
  } finally {
    loading.value = false;
  }
}

async function onGenerate() {
  if (!knowId.value) {
    toastError('请选择一个知识条目');
    return;
  }
  generating.value = true;
  try {
    const r = await generateScript(Number(knowId.value));
    if (r.ok) {
      success('已生成多轮场景话术（草稿态）' + (r.note ? ' · ' + r.note : ''));
      await refresh();
      tab.value = 'library';
    } else {
      toastError(r.error || '生成失败');
    }
  } catch (e) {
    toastError(e.message);
  } finally {
    generating.value = false;
  }
}

function openView(s) {
  viewing.value = s;
}

function openEdit(s) {
  editing.value = s;
  editForm.value = {
    scene: s.scene || '',
    trigger_cond: s.trigger_cond || '',
    turnsText: JSON.stringify(s.turns || [], null, 2)
  };
  editMsg.value = '';
}

async function saveEdit() {
  let turns;
  try {
    turns = JSON.parse(editForm.value.turnsText);
  } catch {
    editMsg.value = '⚠ turns 不是合法 JSON';
    return;
  }
  saving.value = true;
  editMsg.value = '';
  try {
    const r = await updateScript(editing.value.id, {
      scene: editForm.value.scene,
      trigger_cond: editForm.value.trigger_cond,
      turns
    });
    if (r.ok) {
      editing.value = null;
      success('话术已保存');
      await refresh();
    } else {
      editMsg.value = '⚠ ' + (r.error || '保存失败');
    }
  } catch (e) {
    editMsg.value = '⚠ ' + e.message;
  } finally {
    saving.value = false;
  }
}

async function onPublish(s) {
  try {
    await publishScript(s.id);
    success('话术已发布');
    await refresh();
  } catch (e) {
    toastError(e.message);
  }
}

async function onUnpublish(s) {
  try {
    await unpublishScript(s.id);
    success('话术已撤下');
    await refresh();
  } catch (e) {
    toastError(e.message);
  }
}

function askDelete(s) {
  pendingDelete.value = s;
}

async function confirmDelete() {
  const s = pendingDelete.value;
  if (!s) return;
  try {
    await deleteScript(s.id);
    pendingDelete.value = null;
    success('话术已删除');
    await refresh();
  } catch (e) {
    toastError(e.message);
  }
}

async function loadKnowledge() {
  try {
    const r = await listKnowledge(200, 0, '', '', 'published');
    knowList.value = r.rows || [];
  } catch {
    /* 生成页知识列表加载失败不阻塞主流程 */
  }
}

onMounted(async () => {
  await refresh();
  loadKnowledge();
});
</script>

<template>
  <div class="scripts">
    <STabs v-model="tab" :tabs="TABS" />

    <!-- 话术库 -->
    <template v-if="tab === 'library'">
      <SCard icon="📖" title="场景化话术库" :subtitle="`共 ${total} 条 · 草稿需审核发布`" class="mt">
        <template #actions>
          <SButton variant="ghost" size="sm" icon="🔄" :loading="loading" @click="refresh">刷新</SButton>
          <SButton variant="primary" size="sm" icon="✨" @click="tab = 'generate'">生成话术</SButton>
        </template>

        <div class="toolbar">
          <SSelect v-model="statusFilter" :options="STATUS_OPTIONS" size="sm" @change="refresh" />
          <SInput v-model="sceneFilter" size="sm" placeholder="场景筛选" @enter="refresh" />
          <SButton variant="default" size="sm" @click="refresh">筛选</SButton>
        </div>

        <SEmpty
          v-if="!loading && !error && !rows.length"
          icon="💬"
          title="暂无话术"
          desc="切到「从知识条目生成」，基于已沉淀 FAQ 生成第一条场景话术"
          :loading="loading"
          :error="err"
          @retry="refresh"
        />
        <SEmpty v-else-if="loading || err" :loading="loading" :error="err" @retry="refresh" />

        <div v-else class="grid">
          <article v-for="s in rows" :key="s.id" class="sc" :class="{ 'is-pub': s.status === 'published' }">
            <header class="sc__top">
              <h4 class="sc__scene">{{ s.scene || '未命名场景' }}</h4>
              <SBadge :tone="s.status === 'published' ? 'success' : 'neutral'" variant="soft">
                {{ s.status === 'published' ? '已发布' : '草稿' }}
              </SBadge>
            </header>
            <p class="sc__meta">触发：{{ s.trigger_cond || '（未设置）' }} · {{ (s.turns || []).length }} 轮</p>
            <footer class="sc__ops">
              <SButton variant="ghost" size="sm" @click="openView(s)">查看</SButton>
              <SButton variant="ghost" size="sm" @click="openEdit(s)">编辑</SButton>
              <SButton
                v-if="s.status !== 'published'"
                variant="success"
                size="sm"
                @click="onPublish(s)"
              >发布</SButton>
              <SButton v-else variant="warn" size="sm" @click="onUnpublish(s)">撤下</SButton>
              <SButton variant="danger" size="sm" @click="askDelete(s)">删除</SButton>
            </footer>
          </article>
        </div>
      </SCard>
    </template>

    <!-- 生成 -->
    <SCard
      v-else
      icon="✨"
      title="从知识条目生成"
      subtitle="选择一个已沉淀的知识条目（FAQ），由大模型生成一段可复用的多轮客服场景话术"
      class="mt"
    >
      <div class="gen-row">
        <SSelect v-model="knowId" :options="knowOptions" size="md" />
        <SButton variant="primary" icon="✨" :loading="generating" @click="onGenerate">
          {{ generating ? '生成中…' : '生成场景话术' }}
        </SButton>
      </div>
      <p class="gen-hint">生成结果为草稿态，可在话术库中查看、编辑并发布。</p>
    </SCard>

    <!-- 查看 -->
    <SModal :model-value="!!viewing" width="640px" hide-footer @update:model-value="viewing = null">
      <template #title>场景话术 #{{ viewing?.id }}</template>
      <div v-if="viewing">
        <div class="view-head">
          <h4>{{ viewing.scene }}</h4>
          <SBadge :tone="viewing.status === 'published' ? 'success' : 'neutral'" variant="soft">
            {{ viewing.status }}
          </SBadge>
        </div>
        <p class="view-trig">触发条件：{{ viewing.trigger_cond || '（未设置）' }}</p>
        <div class="turns">
          <div v-for="(t, i) in viewing.turns || []" :key="i" class="turn" :class="t.role">
            <span class="turn__who">{{ t.role === 'agent' ? '客服' : '客户' }}</span>
            <span class="turn__txt">{{ t.content }}</span>
          </div>
        </div>
      </div>
    </SModal>

    <!-- 编辑 -->
    <SModal :model-value="!!editing" width="620px" hide-footer @update:model-value="editing = null">
      <template #title>编辑话术 #{{ editing?.id }}</template>
      <div v-if="editing" class="form">
        <SInput v-model="editForm.scene" placeholder="如：退款纠纷处理" />
        <SInput v-model="editForm.trigger_cond" placeholder="如：售后-退款" />
        <SInput v-model="editForm.turnsText" type="textarea" :rows="12" class="mono" />
        <p v-if="editMsg" class="form-msg">{{ editMsg }}</p>
        <div class="form-foot">
          <SButton variant="ghost" @click="editing = null">取消</SButton>
          <SButton variant="primary" :loading="saving" @click="saveEdit">保存</SButton>
        </div>
      </div>
    </SModal>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" title="确认删除" width="420px" @update:model-value="pendingDelete = null">
      <p v-if="pendingDelete">
        确认删除话术「{{ pendingDelete.scene || '#' + pendingDelete.id }}」？删除后不可恢复。
      </p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" @click="confirmDelete">确认删除</SButton>
      </template>
    </SModal>
  </div>
</template>

<style scoped>
.scripts {
  max-width: 1040px;
}
.mt {
  margin-top: var(--sp-4);
}
.toolbar {
  display: flex;
  gap: var(--sp-3);
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: var(--sp-4);
}
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: var(--sp-3);
}
.sc {
  display: flex;
  flex-direction: column;
  gap: var(--sp-2);
  padding: var(--sp-4);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  background: var(--overlay-1);
  transition: border-color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease);
}
.sc:hover {
  border-color: var(--border-strong);
  transform: translateY(-1px);
}
.sc.is-pub {
  border-color: var(--success-border);
}
.sc__top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-3);
}
.sc__scene {
  margin: 0;
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
  color: var(--text-1);
}
.sc__meta {
  margin: 0;
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.sc__ops {
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
  margin-top: auto;
  padding-top: var(--sp-2);
}

/* 生成视图 */
.gen-row {
  display: flex;
  gap: var(--sp-3);
  align-items: center;
  flex-wrap: wrap;
}
.gen-row :deep(.ssel) {
  flex: 1;
  min-width: 240px;
}
.gen-hint {
  margin: var(--sp-3) 0 0;
  font-size: var(--fs-sm);
  color: var(--text-3);
  line-height: 1.6;
}

/* 查看弹窗 */
.view-head {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  margin-bottom: var(--sp-2);
}
.view-head h4 {
  margin: 0;
  font-size: var(--fs-lg);
  color: var(--text-1);
}
.view-trig {
  margin: 0 0 var(--sp-4);
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.turns {
  display: flex;
  flex-direction: column;
  gap: var(--sp-2);
}
.turn {
  max-width: 85%;
  padding: var(--sp-2) var(--sp-3);
  border-radius: var(--r-lg);
  font-size: var(--fs-sm);
  line-height: 1.6;
}
.turn.customer {
  align-self: flex-start;
  background: var(--overlay-3);
}
.turn.agent {
  align-self: flex-end;
  background: var(--violet-soft);
  text-align: right;
}
.turn__who {
  display: block;
  font-size: var(--fs-2xs);
  color: var(--text-3);
  margin-bottom: 2px;
}
.turn__txt {
  color: var(--text-1);
}

/* 编辑表单 */
.form {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.form .mono :deep(textarea) {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
}
.form-msg {
  margin: 0;
  font-size: var(--fs-sm);
  color: var(--danger-text);
}
.form-foot {
  display: flex;
  justify-content: flex-end;
  gap: var(--sp-3);
}

@media (max-width: 640px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>
