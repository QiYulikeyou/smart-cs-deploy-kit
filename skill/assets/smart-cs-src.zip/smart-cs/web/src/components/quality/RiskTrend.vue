<script setup>
/**
 * 风险趋势折线图 —— 高风险 / 中风险 / 低风险三线 + 悬停提示
 * 纯手写 SVG（无图表库依赖），尺寸随容器缩放
 */
import { computed, ref } from 'vue';
import { SCard, SEmpty } from '../ui';

const props = defineProps({
  data: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  days: { type: Number, default: 7 }
});

const emit = defineEmits(['update:days', 'change-days']);

const DAY_OPTIONS = [7, 14, 30];

const W = 620;
const H = 240;
const PAD = { l: 46, r: 14, t: 16, b: 34 };

const hovered = ref(null);

const maxVal = computed(() => {
  if (!props.data.length) return 10;
  return Math.max(...props.data.map((d) => d.high + d.mid + d.low), 10);
});

function xFor(i) {
  const w = W - PAD.l - PAD.r;
  return PAD.l + (i * w) / (props.data.length - 1 || 1);
}
function yFor(val) {
  const h = H - PAD.t - PAD.b;
  return PAD.t + h - (val / maxVal.value) * h;
}
function linePath(field) {
  if (!props.data.length) return '';
  return props.data.map((d, i) => `${i === 0 ? 'M' : 'L'}${xFor(i)},${yFor(d[field])}`).join(' ');
}

/** 悬停提示框位置：靠边时向内收，避免超出画布 */
const tipX = computed(() => {
  if (hovered.value === null) return PAD.l;
  const half = 58;
  return Math.min(Math.max(xFor(hovered.value) - half, PAD.l), W - PAD.r - half * 2);
});
const tipCenterX = computed(() => tipX.value + 58);

function pick(d) {
  emit('update:days', d);
  emit('change-days', d);
}
</script>

<template>
  <SCard icon="📈" title="风险趋势" subtitle="高风险 / 中风险 / 低风险会话走势">
    <template #actions>
      <div class="day-tabs">
        <button
          v-for="d in DAY_OPTIONS"
          :key="d"
          type="button"
          class="day-tab"
          :class="{ 'is-on': days === d }"
          @click="pick(d)"
        >{{ d }}天</button>
      </div>
    </template>

    <SEmpty v-if="loading" loading loading-text="加载趋势数据…" />
    <SEmpty v-else-if="!data.length" icon="📉" title="暂无趋势数据" desc="有会话产生后这里会出现走势曲线" />

    <div v-else class="chart">
      <svg :viewBox="`0 0 ${W} ${H}`" class="chart__svg" preserveAspectRatio="xMidYMid meet" @mouseleave="hovered = null">
        <!-- 网格 -->
        <g>
          <line
            v-for="i in 4"
            :key="'g' + i"
            :x1="PAD.l"
            :y1="PAD.t + ((H - PAD.t - PAD.b) / 4) * i"
            :x2="W - PAD.r"
            :y2="PAD.t + ((H - PAD.t - PAD.b) / 4) * i"
            stroke="var(--chart-grid)"
            stroke-width="1"
          />
        </g>

        <!-- Y 轴刻度 -->
        <text
          v-for="i in 5"
          :key="'y' + i"
          :x="PAD.l - 8"
          :y="PAD.t + ((H - PAD.t - PAD.b) * (5 - i)) / 5 + 4"
          text-anchor="end"
          fill="var(--chart-axis)"
          font-size="10"
        >{{ Math.round((maxVal * (5 - i)) / 4) }}</text>

        <!-- X 轴标签 -->
        <text
          v-for="(d, i) in data"
          :key="'x' + i"
          :x="xFor(i)"
          :y="H - 10"
          text-anchor="middle"
          fill="var(--chart-axis)"
          font-size="9"
        >{{ (d.date || '').slice(5) }}</text>

        <!-- 三条折线 -->
        <path :d="linePath('high')" fill="none" stroke="var(--risk-high)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />
        <path :d="linePath('mid')" fill="none" stroke="var(--risk-mid)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />
        <path :d="linePath('low')" fill="none" stroke="var(--risk-low)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />

        <!-- 数据点 + 悬停热区 -->
        <template v-for="(d, i) in data" :key="'p' + i">
          <circle v-if="d.high > 0" :cx="xFor(i)" :cy="yFor(d.high)" r="3.5" fill="var(--risk-high)" stroke="var(--surface-0)" stroke-width="1.5" />
          <circle v-if="d.mid > 0" :cx="xFor(i)" :cy="yFor(d.mid)" r="3.5" fill="var(--risk-mid)" stroke="var(--surface-0)" stroke-width="1.5" />
          <circle v-if="d.low > 0" :cx="xFor(i)" :cy="yFor(d.low)" r="3.5" fill="var(--risk-low)" stroke="var(--surface-0)" stroke-width="1.5" />
          <rect
            :x="xFor(i) - 14"
            :y="PAD.t"
            width="28"
            :height="H - PAD.t - PAD.b"
            fill="transparent"
            @mouseenter="hovered = i"
            @mousemove="hovered = i"
          />
          <line
            v-if="hovered === i"
            :x1="xFor(i)"
            :y1="PAD.t"
            :x2="xFor(i)"
            :y2="H - PAD.b"
            stroke="var(--chart-grid)"
            stroke-width="1"
            stroke-dasharray="3 3"
          />
        </template>

        <!-- 悬停提示 -->
        <g v-if="hovered !== null && data[hovered]">
          <rect :x="tipX" :y="PAD.t + 6" width="116" height="62" rx="6" fill="var(--surface-elevated)" stroke="var(--border-strong)" />
          <text :x="tipCenterX" :y="PAD.t + 24" text-anchor="middle" fill="var(--text-1)" font-size="10" font-weight="600">
            {{ data[hovered].date }}
          </text>
          <text :x="tipCenterX" :y="PAD.t + 42" text-anchor="middle" fill="var(--risk-high-text)" font-size="10">
            高 {{ data[hovered].high }} / 中 {{ data[hovered].mid }} / 低 {{ data[hovered].low }}
          </text>
          <text :x="tipCenterX" :y="PAD.t + 58" text-anchor="middle" fill="var(--text-3)" font-size="9">
            合计 {{ data[hovered].total }}
          </text>
        </g>
      </svg>

      <div class="legend">
        <span><i class="dot" style="background: var(--risk-high)"></i> 高风险</span>
        <span><i class="dot" style="background: var(--risk-mid)"></i> 中风险</span>
        <span><i class="dot" style="background: var(--risk-low)"></i> 低风险</span>
      </div>
    </div>
  </SCard>
</template>

<style scoped>
.day-tabs {
  display: flex;
  gap: 2px;
  padding: 3px;
  border-radius: var(--r-md);
  background: var(--overlay-2);
  border: 1px solid var(--border);
}
.day-tab {
  padding: 3px 10px;
  border: 0;
  border-radius: var(--r-sm);
  background: transparent;
  color: var(--text-3);
  font-size: var(--fs-xs);
  font-family: inherit;
  cursor: pointer;
  transition: var(--dur-fast) var(--ease);
}
.day-tab:hover {
  color: var(--text-1);
}
.day-tab.is-on {
  background: var(--brand-grad);
  color: var(--brand-text);
  font-weight: var(--fw-medium);
}

.chart {
  width: 100%;
}
.chart__svg {
  display: block;
  width: 100%;
  height: auto;
}
.legend {
  display: flex;
  gap: var(--sp-4);
  justify-content: center;
  margin-top: var(--sp-2);
  font-size: var(--fs-xs);
  color: var(--text-3);
}
.legend span {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-1);
}
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}
</style>
