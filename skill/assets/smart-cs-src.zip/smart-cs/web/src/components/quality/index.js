// 质检看板子组件统一出口（Quality.vue 组合用）
export { default as QualityKpi } from './QualityKpi.vue';
export { default as RiskTrend } from './RiskTrend.vue';
export { default as SourceDist } from './SourceDist.vue';
export { default as QuickDetect } from './QuickDetect.vue';
export { default as AlertList } from './AlertList.vue';
