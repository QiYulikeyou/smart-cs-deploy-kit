<script setup>
/**
 * 待复核预警列表 —— 风险筛选 + 原文搜索 + 标为已读
 */
import { SCard, SButton, SInput, SEmpty } from '../ui';
import { riskTone, riskLabel } from '../../utils/risk.js';

const props = defineProps({
  alerts: { type: Array, default: () => [] },
  counts: { type: Object, default: () => ({ all: 0, high: 0, mid: 0, low: 0 }) },
  filter: { type: String, default: 'all' },
  search: { type: String, default: '' },
  loading: { type: Boolean, default: false }
});

const emit = defineEmits(['update:filter', 'update:search', 'refresh', 'dismiss']);

const FILTERS = [
  { id: 'all', label: '全部', tone: 'neutral', key: 'all' },
  { id: 'high', label: '🔴 高', tone: 'danger', key: 'high' },
  { id: 'mid', label: '🟡 中', tone: 'warn', key: 'mid' },
  { id: 'low', label: '🟢 低', tone: 'success', key: 'low' }
];

function onFilter(id) {
  emit('update:filter', id);
}
</script>

<template>
  <SCard icon="⚠" title="待复核预警" :subtitle="`人工复核高风险 / 中风险会话 · 共 ${counts.all} 条`">
    <template #actions>
      <SInput
        :model-value="search"
        size="sm"
        placeholder="搜索原文…"
        class="search"
        @update:model-value="emit('update:search', $event)"
      />
      <SButton variant="ghost" size="sm" icon="🔄" :loading="loading" title="刷新" @click="emit('refresh')" />
    </template>

    <div class="filters">
      <button
        v-for="f in FILTERS"
        :key="f.id"
        type="button"
        class="fbtn"
        :class="[`fbtn--${f.tone}`, { 'is-on': filter === f.id }]"
        @click="onFilter(f.id)"
      >
        {{ f.label }}({{ counts[f.key] ?? 0 }})
      </button>
    </div>

    <SEmpty v-if="loading" loading loading-text="加载预警列表…" />
    <SEmpty
      v-else-if="!alerts.length"
      icon="✅"
      :title="search || filter !== 'all' ? '没有匹配的预警' : '暂无待复核会话'"
      :desc="search || filter !== 'all' ? '换个筛选条件或清空搜索试试' : '当前所有会话风险均在可控范围'"
    />

    <div v-else class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th style="width: 68px">风险</th>
            <th style="width: 76px">情绪</th>
            <th>客户原文</th>
            <th style="width: 130px">敏感词</th>
            <th style="width: 110px">处理建议</th>
            <th style="width: 92px">时间</th>
            <th style="width: 48px"></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="a in alerts" :key="a.id" :class="`row--${riskTone(a.risk_level)}`">
            <td>
              <span class="chip" :class="`t-${riskTone(a.risk_level)}`">{{ riskLabel(a.risk_level) }}</span>
            </td>
            <td class="muted">{{ a.emotion_trend || '—' }}</td>
            <td class="txt" :title="a.user_text">{{ a.user_text_short || '（无原文）' }}</td>
            <td class="muted hits">{{ a.hits_text || '—' }}</td>
            <td class="muted">{{ a.action_hint }}</td>
            <td class="muted time">{{ (a.created_at || '').slice(5, 16) }}</td>
            <td>
              <button class="done" type="button" title="标为已读" @click="emit('dismiss', a)">✓</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </SCard>
</template>

<style scoped>
.search {
  width: 180px;
}
.filters {
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
  margin-bottom: var(--sp-3);
}
.fbtn {
  padding: 4px var(--sp-3);
  border: 1px solid var(--border);
  border-radius: var(--r-full);
  background: var(--overlay-1);
  color: var(--text-3);
  font-size: var(--fs-xs);
  font-family: inherit;
  cursor: pointer;
  transition: var(--dur-fast) var(--ease);
}
.fbtn:hover {
  color: var(--text-1);
  border-color: var(--border-strong);
}
.fbtn.is-on {
  color: var(--text-1);
  border-color: var(--border-strong);
  background: var(--overlay-4);
  font-weight: var(--fw-medium);
}
.fbtn--danger.is-on {
  color: var(--danger-text);
  background: var(--danger-soft);
  border-color: var(--danger-border);
}
.fbtn--warn.is-on {
  color: var(--warn-text);
  background: var(--warn-soft);
  border-color: var(--warn-border);
}
.fbtn--success.is-on {
  color: var(--success-text);
  background: var(--success-soft);
  border-color: var(--success-border);
}

.table-wrap {
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
}
.table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--fs-sm);
}
.table th {
  padding: var(--sp-2) var(--sp-3);
  text-align: left;
  font-weight: var(--fw-medium);
  color: var(--text-3);
  background: var(--overlay-2);
  white-space: nowrap;
}
.table td {
  padding: var(--sp-2) var(--sp-3);
  color: var(--text-2);
  border-top: 1px solid var(--border-soft);
}
.table tbody tr:hover td {
  background: var(--overlay-1);
}
.row--danger td {
  background: var(--danger-soft);
}
.row--warn td {
  background: var(--warn-soft);
}

.muted {
  color: var(--text-3);
}
.txt {
  max-width: 420px;
  color: var(--text-1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.hits {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 130px;
}
.time {
  font-variant-numeric: tabular-nums;
}
.chip {
  display: inline-block;
  padding: 1px var(--sp-2);
  border-radius: var(--r-sm);
  font-size: var(--fs-xs);
  font-weight: var(--fw-medium);
}
.t-danger {
  color: var(--risk-high-text);
  background: var(--risk-high-soft);
}
.t-warn {
  color: var(--risk-mid-text);
  background: var(--risk-mid-soft);
}
.t-success {
  color: var(--risk-low-text);
  background: var(--risk-low-soft);
}
.done {
  width: 24px;
  height: 24px;
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
  background: transparent;
  color: var(--text-3);
  cursor: pointer;
  line-height: 1;
  transition: var(--dur-fast) var(--ease);
}
.done:hover {
  border-color: var(--success-border);
  background: var(--success-soft);
  color: var(--success-text);
}
</style>
