<script setup>
/**
 * 质检 KPI 卡片行 —— 会话总数 / 风险占比 / 待复核预警 / 质量安全率
 * 环比文案走 SStat 的 hint 行（比右上角的趋势角标更放得下长文案）
 */
import { computed } from 'vue';
import { SStat } from '../ui';
import { riskTone, riskLabel } from '../../utils/risk.js';

const props = defineProps({
  stats: { type: Object, required: true },
  qualityRate: { type: String, default: '—' },
  sessionTrend: { type: Object, required: true },
  riskTrend: { type: Object, required: true },
  qualityTrend: { type: Object, required: true },
  loading: { type: Boolean, default: false }
});

const emit = defineEmits(['handle-alerts']);

const riskLevelText = computed(() => riskLabel(props.stats.avgRisk));
const riskToneName = computed(() => {
  const t = riskTone(props.stats.avgRisk);
  return t === 'danger' ? 'danger' : t === 'warn' ? 'warn' : 'success';
});
</script>

<template>
  <div class="kpi-row">
    <SStat icon="💬" label="会话总数" :value="loading ? '—' : stats.sessions" tone="brand" :loading="loading">
      <template #hint>{{ sessionTrend.text }}</template>
    </SStat>

    <SStat icon="⚠" label="风险占比" :value="stats.riskRate" :tone="riskToneName" :loading="loading">
      <template #hint>{{ riskLevelText }} · {{ riskTrend.text }}</template>
    </SStat>

    <SStat icon="🔔" label="待复核预警" :value="stats.unresolved" tone="warn" :loading="loading">
      <template #hint>
        <button class="kpi-link" type="button" @click="emit('handle-alerts')">立即处理 →</button>
      </template>
    </SStat>

    <SStat icon="✓" label="质量安全率" :value="loading ? '—' : qualityRate" tone="success" :loading="loading">
      <template #hint>{{ qualityTrend.text }}</template>
    </SStat>
  </div>
</template>

<style scoped>
.kpi-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--sp-3);
}
.kpi-link {
  padding: 0;
  border: 0;
  background: none;
  color: var(--brand-text);
  font-size: inherit;
  cursor: pointer;
  font-family: inherit;
}
.kpi-link:hover {
  text-decoration: underline;
}

@media (max-width: 1080px) {
  .kpi-row {
    grid-template-columns: repeat(2, 1fr);
  }
}
@media (max-width: 560px) {
  .kpi-row {
    grid-template-columns: 1fr;
  }
}
</style>
