<script setup>
/**
 * 快速检测 —— 输入客户对话，实时识别风险等级 / 情绪 / 敏感词 / 建议话术
 */
import { SCard, SButton, SInput } from '../ui';
import { riskTone, riskLabel, riskEmoji, emotionLabel } from '../../utils/risk.js';

const props = defineProps({
  modelValue: { type: String, default: '' },
  result: { type: Object, default: null },
  loading: { type: Boolean, default: false },
  error: { type: String, default: '' }
});

const emit = defineEmits(['update:modelValue', 'detect', 'reset']);
</script>

<template>
  <SCard icon="🔍" title="快速检测" subtitle="输入客户对话内容，即时识别风险等级与敏感词">
    <div class="row">
      <SInput
        :model-value="modelValue"
        type="textarea"
        :rows="3"
        placeholder="粘贴客户对话内容，如：我要退款，商品有质量问题…"
        @update:model-value="emit('update:modelValue', $event)"
      />
      <div class="actions">
        <SButton variant="primary" icon="🔍" :loading="loading" @click="emit('detect')">
          {{ loading ? '检测中…' : '开始检测' }}
        </SButton>
        <SButton variant="ghost" @click="emit('reset')">清空</SButton>
      </div>
    </div>

    <p v-if="error" class="err">{{ error }}</p>

    <div v-if="result" class="result" :class="`is-${riskTone(result.risk_level)}`">
      <header class="result__head">
        <span class="result__status" :class="`t-${riskTone(result.risk_level)}`">
          {{ riskEmoji(result.risk_level) }} {{ riskLabel(result.risk_level) }}
        </span>
        <span class="result__emotion">{{ emotionLabel(result.emotion) }}</span>
        <span class="result__time">{{ new Date().toLocaleTimeString('zh-CN') }}</span>
      </header>

      <dl class="grid">
        <div class="cell">
          <dt>风险等级</dt>
          <dd>
            <span class="chip" :class="`t-${riskTone(result.risk_level)}`">{{ riskLabel(result.risk_level) }}</span>
          </dd>
        </div>
        <div class="cell">
          <dt>情绪倾向</dt>
          <dd>{{ emotionLabel(result.emotion) }}</dd>
        </div>
        <div class="cell cell--full">
          <dt>敏感词命中</dt>
          <dd class="tags">
            <span v-if="!(result.sensitive_hits || []).length" class="ok-text">✓ 无敏感词</span>
            <span
              v-for="h in result.sensitive_hits || []"
              :key="h.word"
              class="tag"
              :title="h.note"
            >{{ h.word }}<small v-if="h.note">{{ h.note }}</small></span>
          </dd>
        </div>
        <div v-if="result.suggestion" class="cell cell--full">
          <dt>建议话术</dt>
          <dd class="suggest">{{ result.suggestion }}</dd>
        </div>
        <div v-if="result.needs_review" class="cell cell--full">
          <dt>处理方式</dt>
          <dd class="handling">⚠ 已加入待复核队列，请人工跟进</dd>
        </div>
      </dl>
    </div>
  </SCard>
</template>

<style scoped>
.row {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.actions {
  display: flex;
  gap: var(--sp-2);
}
.err {
  margin: var(--sp-3) 0 0;
  font-size: var(--fs-base);
  color: var(--danger-text);
}

.result {
  margin-top: var(--sp-4);
  padding: var(--sp-4);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  background: var(--overlay-1);
}
.result.is-danger {
  border-color: var(--danger-border);
  background: var(--danger-soft);
}
.result.is-warn {
  border-color: var(--warn-border);
  background: var(--warn-soft);
}
.result.is-success {
  border-color: var(--success-border);
  background: var(--success-soft);
}

.result__head {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  flex-wrap: wrap;
  margin-bottom: var(--sp-3);
}
.result__status {
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
}
.t-danger {
  color: var(--danger-text);
}
.t-warn {
  color: var(--warn-text);
}
.t-success {
  color: var(--success-text);
}
.result__emotion {
  font-size: var(--fs-base);
  color: var(--text-2);
}
.result__time {
  margin-left: auto;
  font-size: var(--fs-xs);
  color: var(--text-4);
}

.grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
  margin: 0;
}
.cell {
  min-width: 0;
}
.cell--full {
  grid-column: 1 / -1;
}
.grid dt {
  font-size: var(--fs-xs);
  color: var(--text-3);
  margin-bottom: var(--sp-1);
}
.grid dd {
  margin: 0;
  font-size: var(--fs-base);
  color: var(--text-1);
}
.chip {
  display: inline-block;
  padding: 1px var(--sp-2);
  border-radius: var(--r-sm);
  font-size: var(--fs-sm);
  background: var(--overlay-3);
}
.tags {
  display: flex;
  flex-wrap: wrap;
  gap: var(--sp-1);
}
.tag {
  padding: 2px var(--sp-2);
  border-radius: var(--r-sm);
  font-size: var(--fs-xs);
  background: var(--danger-soft);
  color: var(--danger-text);
}
.tag small {
  margin-left: var(--sp-1);
  color: var(--text-3);
}
.ok-text {
  color: var(--success-text);
}
.suggest {
  line-height: 1.7;
  color: var(--text-1);
}
.handling {
  color: var(--warn-text);
}

@media (max-width: 640px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>
