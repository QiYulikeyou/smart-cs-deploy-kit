<script setup>
/**
 * 会话来源分布 —— 横向进度条，按来源统计占比
 */
import { SCard, SEmpty } from '../ui';

defineProps({
  items: { type: Array, default: () => [] },
  total: { type: Number, default: 0 },
  loading: { type: Boolean, default: false }
});
</script>

<template>
  <SCard icon="🧭" title="会话来源分布" subtitle="按知识 / 话术来源统计">
    <SEmpty v-if="loading" loading loading-text="统计来源分布…" compact />
    <SEmpty v-else-if="!items.length" icon="🧭" title="暂无数据" desc="所选周期内没有会话记录" compact />

    <template v-else>
      <ul class="list">
        <li v-for="s in items" :key="s.source" class="item">
          <div class="item__info">
            <span class="item__name">
              <i class="item__dot" :style="{ background: s.color }"></i>
              {{ s.label }}
            </span>
            <span class="item__count">
              {{ s.count }} <small>({{ s.pct }}%)</small>
            </span>
          </div>
          <div class="item__bar">
            <div class="item__fill" :style="{ width: Math.max(s.pct, 2) + '%', background: s.grad }"></div>
          </div>
        </li>
      </ul>
      <p class="total">总计 <strong>{{ total }}</strong> 条会话</p>
    </template>
  </SCard>
</template>

<style scoped>
.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.item__info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-3);
  margin-bottom: var(--sp-1);
}
.item__name {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
  font-size: var(--fs-base);
  color: var(--text-2);
}
.item__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.item__count {
  font-size: var(--fs-base);
  font-variant-numeric: tabular-nums;
  color: var(--text-1);
  font-weight: var(--fw-medium);
}
.item__count small {
  color: var(--text-3);
  font-weight: var(--fw-normal);
}
.item__bar {
  height: 6px;
  border-radius: var(--r-full);
  background: var(--overlay-3);
  overflow: hidden;
}
.item__fill {
  height: 100%;
  border-radius: var(--r-full);
  transition: width var(--dur-slow) var(--ease);
}
.total {
  margin: var(--sp-4) 0 0;
  padding-top: var(--sp-3);
  border-top: 1px solid var(--border-soft);
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.total strong {
  color: var(--text-1);
  font-variant-numeric: tabular-nums;
}
</style>
