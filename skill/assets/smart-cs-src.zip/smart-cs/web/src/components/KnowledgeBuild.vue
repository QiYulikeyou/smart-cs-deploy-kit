<script setup>
/**
 * 知识库构建（M1）—— 四大来源：工单回流 / 历史FAQ / 飞书·IMA 同步 / 本地文件
 * v2：改用 STabs 组件，去掉与 QualityInspect 逐字重复的 tabs 样式
 */
import { ref } from 'vue';
import StatStrip from './StatStrip.vue';
import Tickets from './Tickets.vue';
import Knowledge from './Knowledge.vue';
import ExternalKb from './ExternalKb.vue';
import LocalFiles from './LocalFiles.vue';
import STabs from './ui/STabs.vue';

const tab = ref('tickets');

const TABS = [
  { id: 'tickets', label: '工单', icon: '🎫', sub: '知识条目-工单回流' },
  { id: 'faq', label: '历史FAQ', icon: '📚', sub: '知识条目-沉淀知识库' },
  { id: 'external', label: '飞书 / IMA', icon: '🔗', sub: '知识条目-外部知识库' },
  { id: 'local', label: '本地文件', icon: '📁', sub: '知识条目-本地文件' }
];
</script>

<template>
  <div class="kb-build">
    <StatStrip />

    <STabs v-model="tab" :tabs="TABS" />

    <div class="block-body">
      <Tickets v-if="tab === 'tickets'" />
      <Knowledge v-else-if="tab === 'faq'" />
      <ExternalKb v-else-if="tab === 'external'" />
      <LocalFiles v-else-if="tab === 'local'" />
    </div>
  </div>
</template>

<style scoped>
.kb-build {
  color: var(--text-2);
}

.block-body {
  animation: scs-fade-in var(--dur-slow) var(--ease-out);
}
</style>
