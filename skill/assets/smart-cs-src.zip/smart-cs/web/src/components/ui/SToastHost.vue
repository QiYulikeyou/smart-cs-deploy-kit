<script setup>
/**
 * SToastHost —— 全局提示宿主，挂载一次（放在 App 根）
 * 读取 useToast 的共享状态
 */
import { toastState, dismiss } from '../../composables/useToast.js';

const ICONS = {
  success: '✓',
  error: '✕',
  warn: '!',
  info: 'i'
};
</script>

<template>
  <Teleport to="body">
    <div class="stoast-host">
      <TransitionGroup name="stoast">
        <div
          v-for="t in toastState.items"
          :key="t.id"
          class="stoast"
          :class="`stoast--${t.type}`"
          @click="dismiss(t.id)"
        >
          <span class="stoast__icon">{{ ICONS[t.type] || 'i' }}</span>
          <span class="stoast__msg">{{ t.message }}</span>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<style scoped>
.stoast-host {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%);
  z-index: var(--z-toast);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--sp-2);
  pointer-events: none;
}

.stoast {
  pointer-events: auto;
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  max-width: min(560px, 90vw);
  padding: 10px var(--sp-4);
  border-radius: var(--r-lg);
  border: 1px solid var(--border-strong);
  background: var(--surface-2);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  box-shadow: var(--shadow-lg);
  color: var(--text-1);
  font-size: var(--fs-base);
  cursor: pointer;
  animation: scs-fade-in var(--dur) var(--ease-out);
}

.stoast__icon {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: var(--fs-xs);
  font-weight: var(--fw-bold);
  color: #fff;
}

.stoast__msg {
  word-break: break-word;
  line-height: 1.5;
}

.stoast--success {
  border-color: rgba(52, 211, 153, 0.45);
}
.stoast--success .stoast__icon {
  background: var(--success);
}

.stoast--error {
  border-color: rgba(248, 113, 113, 0.5);
}
.stoast--error .stoast__icon {
  background: var(--danger);
}

.stoast--warn {
  border-color: rgba(251, 191, 36, 0.5);
}
.stoast--warn .stoast__icon {
  background: var(--warn);
  color: #422006;
}

.stoast--info {
  border-color: var(--brand-ring);
}
.stoast--info .stoast__icon {
  background: var(--brand-strong);
}

/* 动画 */
.stoast-enter-active,
.stoast-leave-active {
  transition: all var(--dur) var(--ease-out);
}
.stoast-enter-from {
  opacity: 0;
  transform: translateY(-12px) scale(0.96);
}
.stoast-leave-to {
  opacity: 0;
  transform: translateY(-8px) scale(0.96);
}
.stoast-move {
  transition: transform var(--dur) var(--ease);
}
</style>
