<script setup>
/**
 * SEmpty —— 空状态 / 加载中 / 加载失败 三合一占位
 * 统一各组件里五花八门的「暂无数据」「加载中…」文案
 */
defineProps({
  icon: { type: String, default: '📭' },
  title: { type: String, default: '暂无数据' },
  desc: { type: String, default: '' },
  loading: { type: Boolean, default: false },
  error: { type: String, default: '' },
  compact: { type: Boolean, default: false },
  loadingText: { type: String, default: '加载中…' }
});

const emit = defineEmits(['retry']);
</script>

<template>
  <div class="sempty" :class="{ 'is-compact': compact }">
    <template v-if="loading">
      <span class="sempty__spinner"></span>
      <p class="sempty__text">{{ loadingText }}</p>
    </template>

    <template v-else-if="error">
      <span class="sempty__icon sempty__icon--error">⚠️</span>
      <p class="sempty__text sempty__text--error">{{ error }}</p>
      <slot name="error-action">
        <button class="sempty__retry" type="button" @click="emit('retry')">重试</button>
      </slot>
    </template>

    <template v-else>
      <span class="sempty__icon">{{ icon }}</span>
      <p class="sempty__text">{{ title }}</p>
      <p v-if="desc" class="sempty__desc">{{ desc }}</p>
      <slot />
    </template>
  </div>
</template>

<style scoped>
.sempty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--sp-2);
  padding: var(--sp-10) var(--sp-5);
  text-align: center;
  color: var(--text-4);
}

.sempty.is-compact {
  padding: var(--sp-6) var(--sp-4);
}

.sempty__icon {
  font-size: 30px;
  line-height: 1;
  opacity: 0.85;
}

.sempty__icon--error {
  filter: grayscale(0.3);
}

.sempty__text {
  margin: 0;
  font-size: var(--fs-md);
  color: var(--text-3);
}

.sempty__text--error {
  color: var(--danger-text);
  max-width: 420px;
  word-break: break-word;
}

.sempty__desc {
  margin: 0;
  font-size: var(--fs-sm);
  color: var(--text-4);
  max-width: 420px;
}

.sempty__spinner {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  border: 2.5px solid var(--overlay-5);
  border-top-color: var(--brand);
  animation: scs-spin 0.7s linear infinite;
}

.sempty__retry {
  margin-top: var(--sp-2);
  padding: 5px 14px;
  border-radius: var(--r-md);
  border: 1px solid var(--border-strong);
  background: var(--overlay-2);
  color: var(--text-2);
  cursor: pointer;
  font-size: var(--fs-sm);
  font-family: inherit;
  transition: var(--dur-fast) var(--ease);
}
.sempty__retry:hover {
  border-color: var(--brand);
  color: var(--text-1);
}
</style>
