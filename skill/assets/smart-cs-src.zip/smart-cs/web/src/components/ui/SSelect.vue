<script setup>
/**
 * SSelect —— 下拉选择
 * options: [{ value, label, disabled }] 或 [{ id, name }]（可用 valueKey/labelKey 指定）
 */
import { computed } from 'vue';

const props = defineProps({
  modelValue: { type: [String, Number], default: '' },
  options: { type: Array, default: () => [] },
  placeholder: { type: String, default: '请选择' },
  disabled: { type: Boolean, default: false },
  size: { type: String, default: 'md' }, // sm | md
  valueKey: { type: String, default: 'value' },
  labelKey: { type: String, default: 'label' },
  block: { type: Boolean, default: false }
});

const emit = defineEmits(['update:modelValue', 'change']);

const normalized = computed(() =>
  props.options.map((o) => {
    if (o && typeof o === 'object') {
      return {
        value: o[props.valueKey] ?? o.value ?? o.id,
        label: o[props.labelKey] ?? o.label ?? o.name ?? String(o),
        disabled: !!o.disabled
      };
    }
    return { value: o, label: String(o), disabled: false };
  })
);

function onChange(e) {
  const v = e.target.value;
  emit('update:modelValue', v);
  emit('change', v);
}
</script>

<template>
  <div class="ssel" :class="[`ssel--${size}`, { 'is-block': block, 'is-disabled': disabled }]">
    <select
      class="ssel__el"
      :value="modelValue"
      :disabled="disabled"
      @change="onChange"
    >
      <option v-if="placeholder" value="" disabled>{{ placeholder }}</option>
      <option v-for="o in normalized" :key="o.value" :value="o.value" :disabled="o.disabled">
        {{ o.label }}
      </option>
    </select>
    <span class="ssel__arrow" aria-hidden="true">▾</span>
  </div>
</template>

<style scoped>
.ssel {
  position: relative;
  display: inline-flex;
  align-items: center;
}

.ssel.is-block {
  display: flex;
  width: 100%;
}

.ssel__el {
  appearance: none;
  -webkit-appearance: none;
  width: 100%;
  background: var(--overlay-1);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-md);
  color: var(--text-1);
  font-family: inherit;
  cursor: pointer;
  transition: border-color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease);
  padding-right: 28px;
}

.ssel--sm .ssel__el {
  padding: 5px 26px 5px 10px;
  font-size: var(--fs-sm);
}
.ssel--md .ssel__el {
  padding: 8px 28px 8px 12px;
  font-size: var(--fs-base);
}

.ssel__el:hover:not(:disabled) {
  border-color: var(--brand-ring);
}

.ssel__el:focus {
  outline: none;
  border-color: var(--brand);
  box-shadow: 0 0 0 3px var(--brand-glow);
}

.ssel__el:disabled {
  background: var(--disabled-bg);
  color: var(--disabled-text);
  cursor: not-allowed;
}

.ssel__el option {
  background: var(--surface-solid);
  color: var(--text-1);
}

.ssel__arrow {
  position: absolute;
  right: 10px;
  pointer-events: none;
  color: var(--text-4);
  font-size: 11px;
}

.ssel.is-disabled .ssel__arrow {
  color: var(--disabled-text);
}
</style>
