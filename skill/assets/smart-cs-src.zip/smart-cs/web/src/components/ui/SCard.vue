<script setup>
/**
 * SCard —— 统一卡片容器
 * 结构：标题区（标题 + 副标题 + 右侧操作插槽） / 内容区 / 底部插槽
 * padded=false 时内容区无内边距（用于表格等需要贴边的场景）
 */
defineProps({
  title: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  icon: { type: String, default: '' },
  padded: { type: Boolean, default: true },
  hoverable: { type: Boolean, default: false },
  flush: { type: Boolean, default: false } // 无圆角无边框（用于嵌套布局）
});
</script>

<template>
  <section class="scard" :class="{ 'is-hoverable': hoverable, 'is-flush': flush }">
    <header v-if="title || $slots.actions || $slots.title" class="scard__head">
      <div class="scard__title-wrap">
        <span v-if="icon" class="scard__icon">{{ icon }}</span>
        <div class="scard__title-text">
          <slot name="title">
            <h3 class="scard__title">{{ title }}</h3>
          </slot>
          <p v-if="subtitle" class="scard__subtitle">{{ subtitle }}</p>
        </div>
      </div>
      <div v-if="$slots.actions" class="scard__actions">
        <slot name="actions" />
      </div>
    </header>

    <div class="scard__body" :class="{ 'no-pad': !padded }">
      <slot />
    </div>

    <footer v-if="$slots.footer" class="scard__footer">
      <slot name="footer" />
    </footer>
  </section>
</template>

<style scoped>
.scard {
  background: var(--surface-1);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid var(--border);
  border-radius: var(--radius-card);
  box-shadow: var(--shadow-md);
  overflow: hidden;
  transition: border-color var(--dur) var(--ease), box-shadow var(--dur) var(--ease),
    transform var(--dur) var(--ease);
}

.scard.is-hoverable:hover {
  border-color: var(--brand-ring);
  box-shadow: var(--shadow-lg);
  transform: translateY(-2px);
}

.scard.is-flush {
  border-radius: 0;
  border: 0;
  box-shadow: none;
  background: transparent;
}

.scard__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-4);
  padding: var(--sp-4) var(--sp-5);
  border-bottom: 1px solid var(--border);
  background: var(--overlay-0);
  flex-wrap: wrap;
}

.scard__title-wrap {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  min-width: 0;
}

.scard__icon {
  font-size: 17px;
  line-height: 1;
  flex-shrink: 0;
}

.scard__title-text {
  min-width: 0;
}

.scard__title {
  margin: 0;
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
  color: var(--text-1);
  line-height: 1.4;
}

.scard__subtitle {
  margin: 2px 0 0;
  font-size: var(--fs-xs);
  color: var(--text-4);
  line-height: 1.4;
}

.scard__actions {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  flex-wrap: wrap;
}

.scard__body {
  padding: var(--sp-5);
  animation: scs-fade-in var(--dur-slow) var(--ease-out);
}

.scard__body.no-pad {
  padding: 0;
}

.scard__footer {
  padding: var(--sp-3) var(--sp-5);
  border-top: 1px solid var(--border);
  background: var(--overlay-0);
}
</style>
