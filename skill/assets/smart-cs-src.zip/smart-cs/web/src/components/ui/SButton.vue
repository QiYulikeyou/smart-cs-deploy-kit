<script setup>
/**
 * SButton —— 统一按钮
 * variant: primary | default | ghost | danger | success | warn | link
 * size:    sm | md | lg
 */
import { computed } from 'vue';

const props = defineProps({
  variant: { type: String, default: 'default' },
  size: { type: String, default: 'md' },
  type: { type: String, default: 'button' },
  disabled: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  block: { type: Boolean, default: false },
  icon: { type: String, default: '' },
  title: { type: String, default: '' }
});

const emit = defineEmits(['click']);

const isDisabled = computed(() => props.disabled || props.loading);

function onClick(e) {
  if (isDisabled.value) {
    e.preventDefault();
    return;
  }
  emit('click', e);
}
</script>

<template>
  <button
    :type="type"
    class="sbtn"
    :class="[`sbtn--${variant}`, `sbtn--${size}`, { 'is-block': block, 'is-loading': loading }]"
    :disabled="isDisabled"
    :title="title"
    @click="onClick"
  >
    <span v-if="loading" class="sbtn__spinner" aria-hidden="true"></span>
    <span v-else-if="icon" class="sbtn__icon">{{ icon }}</span>
    <span class="sbtn__text"><slot /></span>
  </button>
</template>

<style scoped>
.sbtn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--sp-2);
  border-radius: var(--r-md);
  border: 1px solid transparent;
  cursor: pointer;
  font-family: inherit;
  font-weight: var(--fw-medium);
  line-height: 1;
  white-space: nowrap;
  transition: background var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease),
    color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease),
    box-shadow var(--dur-fast) var(--ease);
  -webkit-user-select: none;
  user-select: none;
}

.sbtn:active:not(:disabled) {
  transform: translateY(1px);
}

.sbtn:disabled {
  cursor: not-allowed;
  background: var(--disabled-bg);
  border-color: transparent;
  color: var(--disabled-text);
}

/* ===== 尺寸 ===== */
.sbtn--sm {
  padding: 5px 10px;
  font-size: var(--fs-sm);
}
.sbtn--md {
  padding: 8px 14px;
  font-size: var(--fs-base);
}
.sbtn--lg {
  padding: 11px 20px;
  font-size: var(--fs-md);
}

/* ===== 变体 ===== */
.sbtn--primary {
  background: linear-gradient(135deg, var(--brand-strong), var(--brand-deep));
  color: #fff;
  box-shadow: 0 2px 10px var(--brand-glow);
}
.sbtn--primary:hover:not(:disabled) {
  filter: brightness(1.1);
  box-shadow: 0 4px 16px var(--brand-glow);
}

.sbtn--default {
  background: var(--overlay-2);
  border-color: var(--border-strong);
  color: var(--text-2);
}
.sbtn--default:hover:not(:disabled) {
  background: var(--overlay-4);
  color: var(--text-1);
}

.sbtn--ghost {
  background: transparent;
  border-color: var(--border);
  color: var(--text-3);
}
.sbtn--ghost:hover:not(:disabled) {
  background: var(--overlay-2);
  border-color: var(--border-strong);
  color: var(--text-1);
}

.sbtn--danger {
  background: var(--danger-soft);
  border-color: rgba(248, 113, 113, 0.4);
  color: var(--danger-text);
}
.sbtn--danger:hover:not(:disabled) {
  background: var(--danger);
  border-color: var(--danger);
  color: #fff;
}

.sbtn--success {
  background: var(--success-soft);
  border-color: rgba(52, 211, 153, 0.4);
  color: var(--success-text);
}
.sbtn--success:hover:not(:disabled) {
  background: var(--success);
  border-color: var(--success);
  color: #fff;
}

.sbtn--warn {
  background: var(--warn-soft);
  border-color: rgba(251, 191, 36, 0.4);
  color: var(--warn-text);
}
.sbtn--warn:hover:not(:disabled) {
  background: var(--warn);
  border-color: var(--warn);
  color: #fff;
}

.sbtn--link {
  background: transparent;
  border-color: transparent;
  color: var(--brand);
  padding-left: 4px;
  padding-right: 4px;
}
.sbtn--link:hover:not(:disabled) {
  color: var(--brand-soft);
  text-decoration: underline;
}

/* ===== 其他 ===== */
.is-block {
  display: flex;
  width: 100%;
}

.is-loading {
  cursor: wait;
  opacity: 0.75;
}

.sbtn__spinner {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid currentColor;
  border-top-color: transparent;
  animation: scs-spin 0.6s linear infinite;
  flex-shrink: 0;
}

.sbtn__icon {
  font-size: 1.05em;
  line-height: 1;
}

.sbtn__text:empty {
  display: none;
}
</style>
