<script setup>
/**
 * STabs —— 统一标签页
 * 取代 KnowledgeBuild / QualityInspect 里逐字复制的 .block-tabs / .btab 样式
 *
 * tabs: [{ id, label, sub, icon, badge }]
 * 支持 v-model，或直接 :model-value + @update:modelValue
 */
defineProps({
  modelValue: { type: String, default: '' },
  tabs: { type: Array, required: true }
});

const emit = defineEmits(['update:modelValue', 'change']);

function select(id) {
  emit('update:modelValue', id);
  emit('change', id);
}
</script>

<template>
  <div class="stabs" role="tablist">
    <button
      v-for="t in tabs"
      :key="t.id"
      class="stab"
      :class="{ 'is-on': modelValue === t.id }"
      type="button"
      role="tab"
      :aria-selected="modelValue === t.id"
      @click="select(t.id)"
    >
      <span class="stab__label">
        <span v-if="t.icon" class="stab__icon">{{ t.icon }}</span>
        {{ t.label }}
        <span v-if="t.badge" class="stab__badge">{{ t.badge }}</span>
      </span>
      <span v-if="t.sub" class="stab__sub">{{ t.sub }}</span>
    </button>
  </div>
</template>

<style scoped>
.stabs {
  display: flex;
  gap: var(--sp-2);
  margin-bottom: var(--sp-5);
  flex-wrap: wrap;
}

.stab {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  min-width: 150px;
  padding: 10px var(--sp-4);
  border-radius: var(--r-lg);
  border: 1px solid var(--border-strong);
  background: var(--overlay-1);
  color: var(--text-2);
  cursor: pointer;
  font-family: inherit;
  text-align: left;
  transition: background var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease),
    color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease);
}

.stab:hover {
  border-color: var(--brand);
  color: var(--text-1);
  background: var(--overlay-2);
}

.stab.is-on {
  background: var(--brand-grad);
  border-color: var(--brand);
  color: var(--text-1);
  box-shadow: inset 0 0 0 1px var(--brand-ring);
}

.stab__label {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
  line-height: 1.3;
}

.stab__icon {
  font-size: 15px;
  line-height: 1;
}

.stab__badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 16px;
  height: 16px;
  padding: 0 5px;
  border-radius: var(--r-full);
  background: var(--danger);
  color: #fff;
  font-size: var(--fs-2xs);
  font-weight: var(--fw-bold);
  line-height: 1;
}

.stab__sub {
  font-size: var(--fs-xs);
  color: var(--text-4);
  line-height: 1.3;
}

.stab.is-on .stab__sub {
  color: var(--brand-soft);
}
</style>
