<script setup>
/**
 * SInput —— 输入框 / 文本域
 * 支持前置图标、后置插槽、清除按钮、字符计数
 */
import { computed, ref } from 'vue';

const props = defineProps({
  modelValue: { type: [String, Number], default: '' },
  type: { type: String, default: 'text' }, // text | textarea | password | number | search | date | email | url
  placeholder: { type: String, default: '' },
  disabled: { type: Boolean, default: false },
  readonly: { type: Boolean, default: false },
  rows: { type: Number, default: 3 },
  maxlength: { type: Number, default: 0 },
  size: { type: String, default: 'md' }, // sm | md
  clearable: { type: Boolean, default: false },
  block: { type: Boolean, default: true }
});

const emit = defineEmits(['update:modelValue', 'enter', 'clear']);

const focused = ref(false);

const isTextarea = computed(() => props.type === 'textarea');

const currentLength = computed(() => String(props.modelValue ?? '').length);
const showCount = computed(() => props.maxlength > 0 && isTextarea.value);

function onInput(e) {
  emit('update:modelValue', e.target.value);
}

function onKeydown(e) {
  // textarea 下 Ctrl/Cmd + Enter 提交；单行下直接 Enter 提交
  if (e.key !== 'Enter') return;
  if (isTextarea.value && !(e.ctrlKey || e.metaKey)) return;
  emit('enter', e);
}

function onClear() {
  emit('update:modelValue', '');
  emit('clear');
}

const showClear = computed(
  () => props.clearable && !props.disabled && !props.readonly && String(props.modelValue ?? '').length > 0
);
</script>

<template>
  <div class="sinp" :class="[`sinp--${size}`, { 'is-block': block, 'is-textarea': isTextarea, 'is-focused': focused, 'is-disabled': disabled }]">
    <span v-if="$slots.prefix" class="sinp__prefix"><slot name="prefix" /></span>

    <textarea
      v-if="isTextarea"
      class="sinp__el"
      :value="modelValue"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :rows="rows"
      :maxlength="maxlength || undefined"
      @input="onInput"
      @keydown="onKeydown"
      @focus="focused = true"
      @blur="focused = false"
    ></textarea>

    <input
      v-else
      class="sinp__el"
      :type="type"
      :value="modelValue"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :maxlength="maxlength || undefined"
      @input="onInput"
      @keydown="onKeydown"
      @focus="focused = true"
      @blur="focused = false"
    />

    <button v-if="showClear" class="sinp__clear" type="button" title="清空" @click="onClear">×</button>
    <span v-if="$slots.suffix" class="sinp__suffix"><slot name="suffix" /></span>
    <span v-if="showCount" class="sinp__count">{{ currentLength }}/{{ maxlength }}</span>
  </div>
</template>

<style scoped>
.sinp {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
  background: var(--overlay-1);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-md);
  color: var(--text-2);
  transition: border-color var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease),
    box-shadow var(--dur-fast) var(--ease);
}

.sinp.is-block {
  display: flex;
  width: 100%;
}

.sinp.is-textarea {
  align-items: flex-start;
  padding-top: 6px;
  padding-bottom: 6px;
}

.sinp.is-focused {
  border-color: var(--brand);
  background: var(--overlay-2);
  box-shadow: 0 0 0 3px var(--brand-glow);
}

.sinp.is-disabled {
  background: var(--disabled-bg);
  color: var(--disabled-text);
  cursor: not-allowed;
}

.sinp--sm .sinp__el {
  padding: 5px 10px;
  font-size: var(--fs-sm);
}
.sinp--md .sinp__el {
  padding: 8px 12px;
  font-size: var(--fs-base);
}

.sinp__el {
  flex: 1;
  min-width: 0;
  background: transparent;
  border: 0;
  outline: none;
  color: var(--text-1);
  font-family: inherit;
  font-size: inherit;
  line-height: 1.5;
}

.sinp__el::placeholder {
  color: var(--text-4);
}

.sinp__el:disabled {
  cursor: not-allowed;
  color: var(--disabled-text);
}

.sinp__el[type='number']::-webkit-outer-spin-button,
.sinp__el[type='number']::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

textarea.sinp__el {
  resize: vertical;
  min-height: 60px;
}

.sinp__prefix,
.sinp__suffix {
  display: inline-flex;
  align-items: center;
  color: var(--text-4);
  font-size: var(--fs-sm);
  flex-shrink: 0;
}
.sinp__prefix {
  padding-left: 10px;
}
.sinp__suffix {
  padding-right: 10px;
}

.sinp__clear {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  margin-right: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 0;
  border-radius: 50%;
  background: var(--overlay-4);
  color: var(--text-3);
  cursor: pointer;
  font-size: 14px;
  line-height: 1;
  transition: var(--dur-fast) var(--ease);
}
.sinp__clear:hover {
  background: var(--danger);
  color: #fff;
}

.sinp__count {
  flex-shrink: 0;
  padding-right: 10px;
  font-size: var(--fs-xs);
  color: var(--text-4);
  align-self: flex-end;
}
</style>
