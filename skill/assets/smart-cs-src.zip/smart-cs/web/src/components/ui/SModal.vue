<script setup>
/**
 * SModal —— 弹窗
 * 支持 ESC 关闭、点击遮罩关闭、宽度尺寸、底部操作区
 */
import { watch, onBeforeUnmount } from 'vue';

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: '' },
  width: { type: String, default: '520px' },
  closeOnMask: { type: Boolean, default: true },
  showClose: { type: Boolean, default: true },
  hideFooter: { type: Boolean, default: false }
});

const emit = defineEmits(['update:modelValue', 'close']);

function close() {
  emit('update:modelValue', false);
  emit('close');
}

function onMask() {
  if (props.closeOnMask) close();
}

function onKey(e) {
  if (e.key === 'Escape') close();
}

watch(
  () => props.modelValue,
  (v) => {
    if (v) {
      document.addEventListener('keydown', onKey);
      document.body.style.overflow = 'hidden';
    } else {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    }
  }
);

onBeforeUnmount(() => {
  document.removeEventListener('keydown', onKey);
  document.body.style.overflow = '';
});
</script>

<template>
  <Teleport to="body">
    <Transition name="smodal">
      <div v-if="modelValue" class="smodal-mask" @click.self="onMask">
        <div class="smodal" :style="{ width }" role="dialog" aria-modal="true">
          <header class="smodal__head">
            <h3 class="smodal__title">
              <slot name="title">{{ title }}</slot>
            </h3>
            <button v-if="showClose" class="smodal__close" type="button" title="关闭（Esc）" @click="close">×</button>
          </header>

          <div class="smodal__body">
            <slot />
          </div>

          <footer v-if="!hideFooter && $slots.footer" class="smodal__foot">
            <slot name="footer" />
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.smodal-mask {
  position: fixed;
  inset: 0;
  z-index: var(--z-modal);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--sp-5);
  background: rgba(2, 6, 23, 0.62);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
}

.smodal {
  max-width: 100%;
  max-height: 88vh;
  display: flex;
  flex-direction: column;
  background: var(--surface-elevated);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-2xl);
  box-shadow: var(--shadow-lg);
  overflow: hidden;
}

.smodal__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-4);
  padding: var(--sp-4) var(--sp-5);
  border-bottom: 1px solid var(--border);
  background: var(--overlay-0);
}

.smodal__title {
  margin: 0;
  font-size: var(--fs-lg);
  font-weight: var(--fw-semibold);
  color: var(--text-1);
}

.smodal__close {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 0;
  border-radius: var(--r-md);
  background: transparent;
  color: var(--text-3);
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  transition: var(--dur-fast) var(--ease);
}
.smodal__close:hover {
  background: var(--danger-soft);
  color: var(--danger-text);
}

.smodal__body {
  padding: var(--sp-5);
  overflow-y: auto;
  flex: 1;
  color: var(--text-2);
}

.smodal__foot {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--sp-3);
  padding: var(--sp-4) var(--sp-5);
  border-top: 1px solid var(--border);
  background: var(--overlay-0);
}

/* 动画 */
.smodal-enter-active,
.smodal-leave-active {
  transition: opacity var(--dur) var(--ease);
}
.smodal-enter-active .smodal,
.smodal-leave-active .smodal {
  transition: transform var(--dur) var(--ease-out), opacity var(--dur) var(--ease);
}
.smodal-enter-from,
.smodal-leave-to {
  opacity: 0;
}
.smodal-enter-from .smodal,
.smodal-leave-to .smodal {
  opacity: 0;
  transform: translateY(-12px) scale(0.97);
}
</style>
