<script setup>
/**
 * SStat —— 统计数字卡片
 * tone 决定强调色；trend 为环比变化（>0 显示红色上升，<0 显示绿色下降，0 不显示）
 */
import { computed } from 'vue';

const props = defineProps({
  label: { type: String, required: true },
  value: { type: [String, Number], default: '—' },
  icon: { type: String, default: '' },
  tone: { type: String, default: 'brand' }, // brand | violet | danger | warn | success | info
  loading: { type: Boolean, default: false },
  trend: { type: Number, default: null },
  compact: { type: Boolean, default: false },
  sub: { type: String, default: '' }
});

const trendText = computed(() => {
  if (props.trend === null || props.trend === 0) return '';
  return `${props.trend > 0 ? '↑' : '↓'}${Math.abs(props.trend)}`;
});

const trendDir = computed(() => {
  if (props.trend === null || props.trend === 0) return '';
  return props.trend > 0 ? 'up' : 'down';
});
</script>

<template>
  <div class="sstat" :class="[`sstat--${tone}`, { 'is-compact': compact }]">
    <span class="sstat__glow" aria-hidden="true"></span>
    <span v-if="icon" class="sstat__icon">{{ icon }}</span>
    <div class="sstat__value">
      <span v-if="loading" class="sstat__skeleton"></span>
      <template v-else>{{ value }}</template>
    </div>
    <div class="sstat__label">{{ label }}</div>
    <div v-if="sub || $slots.hint" class="sstat__sub">
      <slot name="hint">{{ sub }}</slot>
    </div>
    <span v-if="trendText" class="sstat__trend" :class="trendDir">{{ trendText }}</span>
  </div>
</template>

<style scoped>
.sstat {
  position: relative;
  overflow: hidden;
  padding: var(--sp-4) var(--sp-4);
  border-radius: var(--r-xl);
  border: 1px solid var(--border);
  background: var(--overlay-1);
  transition: border-color var(--dur) var(--ease), transform var(--dur) var(--ease);
}

.sstat:hover {
  border-color: var(--stat-color);
  transform: translateY(-2px);
}

.sstat.is-compact {
  padding: var(--sp-3) var(--sp-3);
  display: flex;
  align-items: center;
  gap: var(--sp-2);
}

.sstat__glow {
  position: absolute;
  top: -30px;
  right: -30px;
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: var(--stat-color);
  opacity: 0.16;
  filter: blur(10px);
  pointer-events: none;
}

.sstat__icon {
  font-size: 17px;
  line-height: 1;
  position: relative;
}

.sstat__value {
  position: relative;
  margin: var(--sp-2) 0 2px;
  font-size: var(--fs-2xl);
  font-weight: var(--fw-bold);
  color: var(--text-1);
  line-height: 1.15;
  font-variant-numeric: tabular-nums;
}

.sstat.is-compact .sstat__value {
  margin: 0;
  font-size: var(--fs-lg);
}

.sstat__label {
  position: relative;
  font-size: var(--fs-xs);
  color: var(--text-3);
  line-height: 1.3;
}

.sstat__sub {
  position: relative;
  margin-top: var(--sp-1);
  font-size: var(--fs-2xs);
  color: var(--text-4);
  line-height: 1.4;
}

.sstat__trend {
  position: absolute;
  top: var(--sp-2);
  right: var(--sp-2);
  padding: 1px 5px;
  border-radius: var(--r-xs);
  font-size: var(--fs-2xs);
  font-weight: var(--fw-semibold);
  z-index: 1;
}

.sstat__trend.up {
  color: var(--danger-text);
  background: var(--danger-soft);
}
.sstat__trend.down {
  color: var(--success-text);
  background: var(--success-soft);
}

.sstat__skeleton {
  display: inline-block;
  width: 42px;
  height: 22px;
  border-radius: var(--r-sm);
  background: linear-gradient(
    90deg,
    var(--overlay-2) 25%,
    var(--overlay-4) 37%,
    var(--overlay-2) 63%
  );
  background-size: 400% 100%;
  animation: scs-shimmer 1.3s ease-in-out infinite;
}

/* ===== 强调色 ===== */
.sstat--brand {
  --stat-color: var(--brand);
}
.sstat--violet {
  --stat-color: var(--violet);
}
.sstat--danger {
  --stat-color: var(--danger);
}
.sstat--warn {
  --stat-color: var(--warn);
}
.sstat--success {
  --stat-color: var(--success);
}
.sstat--info {
  --stat-color: var(--info);
}
</style>
