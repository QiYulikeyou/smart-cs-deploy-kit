<script setup>
/**
 * SBadge —— 状态徽章
 * tone:  brand | success | warn | danger | info | violet | neutral
 *       另外支持 risk-high / risk-mid / risk-low 三个质检语义别名
 * 变体： solid（实心） | soft（浅底，默认）
 */
import { computed } from 'vue';

const props = defineProps({
  tone: { type: String, default: 'neutral' },
  variant: { type: String, default: 'soft' },
  size: { type: String, default: 'md' }, // sm | md
  dot: { type: Boolean, default: false },
  round: { type: Boolean, default: false }
});

const TONE_ALIAS = {
  'risk-high': 'danger',
  'risk-mid': 'warn',
  'risk-low': 'success',
  high: 'danger',
  mid: 'warn',
  low: 'success'
};

const realTone = computed(() => TONE_ALIAS[props.tone] || props.tone);
</script>

<template>
  <span
    class="sbadge"
    :class="[`sbadge--${realTone}`, `sbadge--${variant}`, `sbadge--${size}`, { 'is-round': round }]"
  >
    <span v-if="dot" class="sbadge__dot"></span>
    <slot />
  </span>
</template>

<style scoped>
.sbadge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-weight: var(--fw-semibold);
  line-height: 1;
  white-space: nowrap;
  border: 1px solid transparent;
  transition: var(--dur-fast) var(--ease);
}

.sbadge--sm {
  padding: 2px 7px;
  font-size: var(--fs-2xs);
  border-radius: var(--r-xs);
}
.sbadge--md {
  padding: 4px 9px;
  font-size: var(--fs-xs);
  border-radius: var(--r-sm);
}

.is-round {
  border-radius: var(--r-full);
  padding-left: 11px;
  padding-right: 11px;
}

.sbadge__dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  flex-shrink: 0;
}

/* ===== soft 变体（浅底 + 彩色字） ===== */
.sbadge--soft.sbadge--brand {
  background: var(--brand-glow);
  color: var(--brand-soft);
  border-color: var(--brand-ring);
}
.sbadge--soft.sbadge--success {
  background: var(--success-soft);
  color: var(--success-text);
  border-color: rgba(52, 211, 153, 0.3);
}
.sbadge--soft.sbadge--warn {
  background: var(--warn-soft);
  color: var(--warn-text);
  border-color: rgba(251, 191, 36, 0.3);
}
.sbadge--soft.sbadge--danger {
  background: var(--danger-soft);
  color: var(--danger-text);
  border-color: rgba(248, 113, 113, 0.3);
}
.sbadge--soft.sbadge--info {
  background: var(--info-soft);
  color: var(--info);
  border-color: rgba(96, 165, 250, 0.3);
}
.sbadge--soft.sbadge--violet {
  background: var(--violet-soft);
  color: var(--violet-text);
  border-color: rgba(167, 139, 250, 0.3);
}
.sbadge--soft.sbadge--neutral {
  background: var(--overlay-2);
  color: var(--text-3);
  border-color: var(--border);
}

/* ===== solid 变体（实心） ===== */
.sbadge--solid {
  color: #fff;
  border-color: transparent;
}
.sbadge--solid.sbadge--brand {
  background: linear-gradient(135deg, var(--brand-strong), var(--brand-deep));
}
.sbadge--solid.sbadge--success {
  background: var(--success);
}
.sbadge--solid.sbadge--warn {
  background: var(--warn);
  color: #422006;
}
.sbadge--solid.sbadge--danger {
  background: var(--danger);
}
.sbadge--solid.sbadge--info {
  background: var(--info);
}
.sbadge--solid.sbadge--violet {
  background: var(--violet);
}
.sbadge--solid.sbadge--neutral {
  background: var(--overlay-6);
  color: var(--text-2);
}
</style>
