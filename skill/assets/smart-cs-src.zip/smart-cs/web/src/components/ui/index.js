/**
 * UI 组件库统一出口
 *
 * 用法：import { SButton, SCard, STabs } from '@/components/ui'
 * （需在 vite.config.js 配置 '@' 别名，见 resolve.alias）
 */
export { default as SButton } from './SButton.vue';
export { default as SInput } from './SInput.vue';
export { default as SSelect } from './SSelect.vue';
export { default as SBadge } from './SBadge.vue';
export { default as SCard } from './SCard.vue';
export { default as STabs } from './STabs.vue';
export { default as SEmpty } from './SEmpty.vue';
export { default as SModal } from './SModal.vue';
export { default as SStat } from './SStat.vue';
export { default as SToastHost } from './SToastHost.vue';
