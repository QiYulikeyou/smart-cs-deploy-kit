<script setup>
/**
 * 统计概览条 —— 四大计数 + 风险趋势摘要
 * v2：改用 SStat 组件 + useAsync 统一取数，去掉手写的 loading/error 分支
 * 行为与 v1 一致：15 秒轮询一次
 */
import { computed, onMounted, onUnmounted } from 'vue';
import { getStats, getRiskTrend } from '../api.js';
import { useAsync } from '../composables/useAsync.js';
import SStat from './ui/SStat.vue';

/* 主计数：轮询刷新 */
const { data: stats, loading, run: refreshStats } = useAsync(
  async () => {
    const s = await getStats();
    return {
      tickets: s.tickets || 0,
      knowledge: s.knowledge || 0,
      urgent: s.urgent || 0,
      alerts: s.alerts || 0
    };
  },
  { initial: { tickets: 0, knowledge: 0, urgent: 0, alerts: 0 } }
);

/* 风险趋势：只取最近一天与前一日的对比 */
const { data: trend, run: refreshTrend } = useAsync(async () => {
  try {
    const r = await getRiskTrend(7);
    return r?.data || [];
  } catch {
    return []; // 趋势属锦上添花，失败不打断主流程
  }
});

const cards = computed(() => [
  { key: 'tickets', label: '工单总数', icon: '🎫', tone: 'brand' },
  { key: 'knowledge', label: '知识条目', icon: '📚', tone: 'violet' },
  { key: 'urgent', label: '紧急工单', icon: '🔥', tone: 'danger' },
  { key: 'alerts', label: '待复核预警', icon: '⚠️', tone: 'warn' }
]);

const summaryCards = computed(() => {
  const arr = trend.value || [];
  if (!arr.length) return [];
  const last = arr[arr.length - 1];
  const prev = arr.length > 1 ? arr[arr.length - 2] : last;
  return [
    { label: '今日总计', value: last.total, change: last.total - prev.total, tone: 'info' },
    { label: '高风险', value: last.high, change: last.high - prev.high, tone: 'danger' },
    { label: '中风险', value: last.mid, change: last.mid - prev.mid, tone: 'warn' },
    { label: '低风险', value: last.low, change: last.low - prev.low, tone: 'success' }
  ];
});

let timer = null;
onMounted(() => {
  refreshStats();
  refreshTrend();
  timer = setInterval(() => {
    refreshStats();
    refreshTrend();
  }, 15000);
});
onUnmounted(() => {
  if (timer) clearInterval(timer);
});
</script>

<template>
  <div class="strip">
    <div class="grid">
      <SStat
        v-for="c in cards"
        :key="c.key"
        :label="c.label"
        :icon="c.icon"
        :tone="c.tone"
        :value="stats[c.key]"
        :loading="loading && !stats[c.key]"
      />
    </div>

    <div v-if="summaryCards.length" class="sub-grid">
      <SStat
        v-for="(s, i) in summaryCards"
        :key="i"
        compact
        :label="s.label"
        :value="s.value"
        :tone="s.tone"
        :trend="s.change"
      />
    </div>
  </div>
</template>

<style scoped>
.strip {
  margin-bottom: var(--sp-5);
}

.grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--sp-3);
}

.sub-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--sp-2);
  margin-top: var(--sp-2);
}

@media (max-width: 1080px) {
  .grid,
  .sub-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 560px) {
  .grid {
    grid-template-columns: repeat(2, 1fr);
  }
  .sub-grid {
    grid-template-columns: 1fr;
  }
}
</style>
