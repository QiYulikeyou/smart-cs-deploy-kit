<script setup>
/**
 * 历史对话（v2）
 *
 * 变更要点：
 * 1. 「仅坐席对话」复选框 → 三态分段：全部 / 仅坐席 / 仅网站访客
 *    （原默认勾选 agentOnly=true，导致官网挂件来访一条都看不到，已修正为默认「全部」）
 * 2. 列表新增「来源」列，明确区分「官网访客」与「坐席」
 * 3. 表格化 + 行展开详情，取代原来的纯流式卡片
 * 4. 全量接入 UI 组件库与设计 token，支持明暗双主题
 */
import { ref, computed, onMounted } from 'vue';
import { getConversations, exportCsv, createKnowledge } from '../api.js';
import { SCard, SButton, SSelect, SInput, SEmpty, SBadge, SModal } from './ui';
import { useToast } from '../composables/useToast.js';
import { riskTone, riskLabel, sourceMeta } from '../utils/risk.js';

const { success, error: toastError } = useToast();

const PAGE_SIZE = 15;

const items = ref([]);
const total = ref(0);
const loading = ref(true);
const error = ref('');
const page = ref(0);

const riskFilter = ref('');
const sourceFilter = ref('');
const dateFrom = ref('');
const dateTo = ref('');
const exporting = ref(false);

// 三态：all | agent | visitor
const scope = ref('all');
const SCOPES = [
  { id: 'all', label: '全部', hint: '官网访客 + 坐席' },
  { id: 'agent', label: '仅坐席', hint: '工作台内部对话' },
  { id: 'visitor', label: '仅网站访客', hint: '官网挂件匿名提问' }
];

const RISK_OPTIONS = [
  { value: '', label: '全部风险' },
  { value: 'low', label: '低风险' },
  { value: 'mid', label: '中风险' },
  { value: 'high', label: '高风险' }
];

const SOURCE_OPTIONS = [
  { value: '', label: '全部命中来源' },
  { value: 'local', label: '本地知识库' },
  { value: 'script', label: '话术库' },
  { value: 'feishu', label: '飞书同步' },
  { value: 'llm', label: 'LLM 生成' }
];

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / PAGE_SIZE)));
const pageLabel = computed(() => `第 ${page.value + 1} / ${totalPages.value} 页 · 共 ${total.value} 条`);
const expanded = ref(new Set());

function toggleRow(id) {
  const next = new Set(expanded.value);
  if (next.has(id)) next.delete(id);
  else next.add(id);
  expanded.value = next;
}

function buildFilters(extra = {}) {
  const f = { ...extra };
  if (riskFilter.value) f.risk = riskFilter.value;
  if (sourceFilter.value) f.source = sourceFilter.value;
  if (scope.value !== 'all') f.scope = scope.value;
  if (dateFrom.value) f.from = dateFrom.value;
  if (dateTo.value) f.to = dateTo.value;
  return f;
}

async function refresh() {
  loading.value = true;
  error.value = '';
  expanded.value = new Set();
  try {
    const res = await getConversations(PAGE_SIZE, page.value * PAGE_SIZE, buildFilters());
    items.value = res.items || [];
    total.value = res.total || 0;
  } catch (e) {
    error.value = e.message || '加载失败';
    items.value = [];
    total.value = 0;
  } finally {
    loading.value = false;
  }
}

function changePage(delta) {
  const next = page.value + delta;
  if (next < 0 || next >= totalPages.value) return;
  page.value = next;
  refresh();
}

function applyFilter() {
  page.value = 0;
  refresh();
}

function setScope(id) {
  if (scope.value === id) return;
  scope.value = id;
  applyFilter();
}

function resetFilter() {
  riskFilter.value = '';
  sourceFilter.value = '';
  dateFrom.value = '';
  dateTo.value = '';
  applyFilter();
}

async function onExport() {
  exporting.value = true;
  try {
    const params = buildFilters();
    const blob = await exportCsv(params);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `对话记录_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    success('对话记录已导出');
  } catch (e) {
    toastError('导出失败：' + e.message);
  } finally {
    exporting.value = false;
  }
}

/** 渠道：官网访客 vs 坐席 */
function channelOf(it) {
  return it.is_agent ? 'agent' : 'visitor';
}
function channelLabel(it) {
  return it.is_agent ? '坐席' : '官网访客';
}
function actorLabel(it) {
  if (it.is_agent) return it.user_role ? `坐席 · ${it.user_role}` : '坐席';
  return '匿名访客';
}
function hitLabel(s) {
  if (!s) return '—';
  return sourceMeta(s).label;
}
function fmtTime(t) {
  if (!t) return '—';
  return new Date(t.replace(' ', 'T') + 'Z').toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}
function fmtFull(t) {
  if (!t) return '—';
  return new Date(t.replace(' ', 'T') + 'Z').toLocaleString('zh-CN');
}

// ===== 访客问题 → 知识库（编辑后发布） =====
// 后端 POST /api/knowledge 默认 source_type=faq、status=published 并自动算 embedding，
// 入库即进入下游语义检索，无需额外发布动作。
const convertOpen = ref(false);
const savingKb = ref(false);
const convertedIds = ref(new Set());
const URGENCY_OPTIONS = [
  { value: 1, label: '低' },
  { value: 2, label: '中' },
  { value: 3, label: '高' }
];
const kbForm = ref({ id: null, question: '', solution: '', category: '其他', product_module: '', urgency: 1 });

function openConvert(it) {
  kbForm.value = {
    id: it.id,
    question: (it.user_text || '').trim(),
    solution: (it.bot_reply || '').trim(),
    category: '其他',
    product_module: '',
    urgency: 1
  };
  convertOpen.value = true;
}

async function submitConvert() {
  const q = kbForm.value.question.trim();
  if (!q) {
    toastError('问题不能为空');
    return;
  }
  savingKb.value = true;
  try {
    const r = await createKnowledge({
      question: q,
      solution: kbForm.value.solution,
      category: kbForm.value.category.trim() || '其他',
      product_module: kbForm.value.product_module.trim(),
      urgency: kbForm.value.urgency
    });
    convertedIds.value.add(kbForm.value.id);
    convertedIds.value = new Set(convertedIds.value); // 触发响应式
    success(`已发布为知识库条目 #${r.id}，后续对话可自动检索命中`);
    convertOpen.value = false;
  } catch (e) {
    toastError('发布失败：' + (e.message || '未知错误'));
  } finally {
    savingKb.value = false;
  }
}

onMounted(refresh);
</script>

<template>
  <SCard
    icon="🕘"
    title="历史对话"
    subtitle="记录每一次客户咨询与机器人应答 · 点击任意行展开完整内容与引用"
  >
    <template #actions>
      <SButton variant="ghost" size="sm" icon="🔄" :loading="loading" @click="refresh">刷新</SButton>
      <SButton variant="primary" size="sm" icon="📥" :loading="exporting" @click="onExport">导出 CSV</SButton>
    </template>

    <!-- 渠道三态切换 -->
    <div class="seg" role="tablist">
      <button
        v-for="s in SCOPES"
        :key="s.id"
        type="button"
        role="tab"
        class="seg__btn"
        :class="{ 'is-on': scope === s.id }"
        :aria-selected="scope === s.id"
        @click="setScope(s.id)"
      >
        <span class="seg__label">{{ s.label }}</span>
        <span class="seg__hint">{{ s.hint }}</span>
      </button>
    </div>

    <!-- 筛选条 -->
    <div class="filters">
      <SSelect v-model="riskFilter" :options="RISK_OPTIONS" size="sm" @change="applyFilter" />
      <SSelect v-model="sourceFilter" :options="SOURCE_OPTIONS" size="sm" @change="applyFilter" />
      <SInput v-model="dateFrom" type="date" size="sm" class="date" @update:model-value="applyFilter" />
      <span class="tilde">至</span>
      <SInput v-model="dateTo" type="date" size="sm" class="date" @update:model-value="applyFilter" />
      <SButton variant="ghost" size="sm" @click="resetFilter">重置</SButton>
    </div>

    <SEmpty
      v-if="loading || error"
      :loading="loading"
      :error="error"
      loading-text="加载对话记录…"
      @retry="refresh"
    />
    <SEmpty
      v-else-if="!items.length"
      icon="🕘"
      title="暂无对话记录"
      desc="换个渠道或放宽筛选条件试试；官网挂件来访记在「仅网站访客」下"
    />

    <template v-else>
      <div class="table-wrap">
        <table class="tbl">
          <thead>
            <tr>
              <th style="width: 96px">时间</th>
              <th style="width: 104px">来源</th>
              <th>客户提问</th>
              <th>AI 应答</th>
              <th style="width: 88px">风险</th>
              <th style="width: 44px"></th>
            </tr>
          </thead>
          <tbody>
            <template v-for="it in items" :key="it.id">
              <tr class="row" @click="toggleRow(it.id)">
                <td class="c-time">{{ fmtTime(it.created_at) }}</td>
                <td>
                  <SBadge :tone="channelOf(it) === 'visitor' ? 'brand' : 'violet'" variant="soft">
                    {{ channelLabel(it) }}
                  </SBadge>
                </td>
                <td class="c-text">{{ it.user_text || '（无原文）' }}</td>
                <td class="c-text muted">{{ it.bot_reply || '（无回复）' }}</td>
                <td>
                  <SBadge :tone="riskTone(it.risk_level)" variant="soft">{{ riskLabel(it.risk_level) }}</SBadge>
                </td>
                <td class="c-arrow">
                  <span class="arrow" :class="{ 'is-open': expanded.has(it.id) }">›</span>
                </td>
              </tr>

              <tr v-if="expanded.has(it.id)" class="detail">
                <td colspan="6">
                  <div class="detail__inner">
                    <div class="kv">
                      <span class="k">渠道</span><span class="v">{{ actorLabel(it) }}</span>
                      <span class="k">命中来源</span><span class="v">{{ hitLabel(it.source) }}</span>
                      <span class="k">知识库</span><span class="v">{{ it.kb_source || '—' }}</span>
                      <span class="k">完整时间</span><span class="v">{{ fmtFull(it.created_at) }}</span>
                      <span class="k">会话 ID</span><span class="v mono">{{ it.session_id || '—' }}</span>
                      <span class="k">记录号</span><span class="v mono">#{{ it.id }}</span>
                    </div>
                    <div class="bubble">
                      <div class="q"><span class="tag">客户</span>{{ it.user_text || '（无原文）' }}</div>
                      <div class="a"><span class="tag tag--bot">机器人</span>{{ it.bot_reply || '（无回复）' }}</div>
                    </div>
                    <div class="conv-actions">
                      <SButton
                        v-if="!convertedIds.has(it.id)"
                        variant="primary" size="sm" icon="📚"
                        @click.stop="openConvert(it)"
                      >转为知识库</SButton>
                      <SBadge v-else tone="success" variant="soft">✓ 已转为知识库</SBadge>
                      <span class="conv-actions__hint">把这条访客问答整理为标准答案，发布后后续对话可自动检索命中</span>
                    </div>
                    <div v-if="it.cited && it.cited.length" class="cited">
                      <span class="k">引用知识</span>
                      <span v-for="(c, i) in it.cited" :key="i" class="cite">
                        {{ c.title }}<em v-if="c.score != null">（{{ (c.score * 100).toFixed(0) }}%）</em>
                      </span>
                    </div>
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="pager">
        <SButton variant="ghost" size="sm" :disabled="page === 0" @click="changePage(-1)">上一页</SButton>
        <span class="pager__label">{{ pageLabel }}</span>
        <SButton variant="ghost" size="sm" :disabled="page + 1 >= totalPages" @click="changePage(1)">下一页</SButton>
      </div>
    </template>

    <!-- 访客问题 → 知识库：编辑并发布 -->
    <SModal v-model="convertOpen" title="转为知识库条目" width="600px">
      <div class="kb-form">
        <label class="fld">
          <span class="fld__label">客户问题 <em>（将作为检索问题）</em></span>
          <SInput v-model="kbForm.question" type="textarea" :rows="3" placeholder="编辑后作为后续语义检索的问题" />
        </label>
        <label class="fld">
          <span class="fld__label">标准回答 <em>（知识库答案）</em></span>
          <SInput v-model="kbForm.solution" type="textarea" :rows="5" placeholder="建议补充/润色机器人回答，作为对外标准答案" />
        </label>
        <div class="fld-row">
          <label class="fld">
            <span class="fld__label">分类</span>
            <SInput v-model="kbForm.category" placeholder="如：售后 / 账号 / 物流" />
          </label>
          <label class="fld">
            <span class="fld__label">所属模块</span>
            <SInput v-model="kbForm.product_module" placeholder="可选" />
          </label>
          <label class="fld fld--urgency">
            <span class="fld__label">紧急度</span>
            <SSelect v-model="kbForm.urgency" :options="URGENCY_OPTIONS" size="sm" />
          </label>
        </div>
        <p class="kb-tip">保存后<strong>立即发布</strong>（status=published），后续访客对话会自动语义检索命中该条目。</p>
      </div>
      <template #footer>
        <SButton variant="ghost" size="sm" :disabled="savingKb" @click="convertOpen = false">取消</SButton>
        <SButton variant="primary" size="sm" icon="📚" :loading="savingKb" @click="submitConvert">保存并发布</SButton>
      </template>
    </SModal>
  </SCard>
</template>

<style scoped>
/* 三态分段控件 */
.seg {
  display: inline-flex;
  gap: 2px;
  padding: 3px;
  margin-bottom: var(--sp-3);
  border-radius: var(--r-md);
  background: var(--overlay-2);
  border: 1px solid var(--border);
}
.seg__btn {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 1px;
  padding: 5px 14px;
  border: 0;
  border-radius: var(--r-sm);
  background: transparent;
  color: var(--text-3);
  font-family: inherit;
  cursor: pointer;
  transition: var(--dur-fast) var(--ease);
}
.seg__btn:hover {
  color: var(--text-1);
}
.seg__btn.is-on {
  background: var(--brand-grad);
  color: var(--brand-text);
  box-shadow: 0 1px 6px var(--brand-glow);
}
.seg__label {
  font-size: var(--fs-base);
  font-weight: var(--fw-medium);
  line-height: 1.2;
}
.seg__hint {
  font-size: var(--fs-2xs);
  opacity: 0.75;
  line-height: 1.2;
}

/* 筛选条 */
.filters {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  flex-wrap: wrap;
  margin-bottom: var(--sp-4);
}
.filters .date {
  width: 142px;
}
.tilde {
  font-size: var(--fs-sm);
  color: var(--text-3);
}

/* 表格 */
.table-wrap {
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
}
.tbl {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--fs-base);
}
.tbl th {
  padding: var(--sp-2) var(--sp-3);
  text-align: left;
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
  color: var(--text-3);
  background: var(--overlay-2);
  white-space: nowrap;
}
.tbl td {
  padding: var(--sp-2) var(--sp-3);
  border-top: 1px solid var(--border-soft);
  color: var(--text-2);
  vertical-align: top;
}
.row {
  cursor: pointer;
  transition: background var(--dur-fast) var(--ease);
}
.row:hover td {
  background: var(--overlay-1);
}
.c-time {
  font-size: var(--fs-sm);
  color: var(--text-3);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.c-text {
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.c-text.muted {
  color: var(--text-3);
}
.c-arrow {
  text-align: center;
}
.arrow {
  display: inline-block;
  color: var(--text-3);
  font-size: 16px;
  line-height: 1;
  transition: transform var(--dur-fast) var(--ease);
}
.arrow.is-open {
  transform: rotate(90deg);
  color: var(--brand-text);
}

/* 展开详情 */
.detail td {
  padding: 0;
  background: var(--overlay-1);
}
.detail__inner {
  padding: var(--sp-3) var(--sp-4);
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
  animation: scs-fade-in var(--dur) var(--ease-out);
}
.kv {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--sp-2) var(--sp-4);
}
.kv .k {
  display: block;
  font-size: var(--fs-2xs);
  color: var(--text-4);
}
.kv .v {
  display: block;
  font-size: var(--fs-sm);
  color: var(--text-1);
}
.mono {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
  word-break: break-all;
}
.bubble {
  display: flex;
  flex-direction: column;
  gap: var(--sp-2);
}
.bubble .q,
.bubble .a {
  padding: var(--sp-2) var(--sp-3);
  border-radius: var(--r-lg);
  font-size: var(--fs-base);
  line-height: 1.7;
  white-space: pre-wrap;
  word-break: break-word;
}
.bubble .q {
  background: var(--overlay-3);
  color: var(--text-1);
}
.bubble .a {
  background: var(--brand-grad);
  color: var(--text-1);
}
.tag {
  display: inline-block;
  margin-right: var(--sp-2);
  padding: 0 var(--sp-2);
  border-radius: var(--r-sm);
  font-size: var(--fs-2xs);
  color: var(--text-3);
  background: var(--overlay-4);
  vertical-align: 1px;
}
.tag--bot {
  color: var(--brand-text);
  background: var(--overlay-5);
}
.cited {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  flex-wrap: wrap;
  font-size: var(--fs-sm);
}
.cited .k {
  font-size: var(--fs-2xs);
  color: var(--text-4);
}
.cite {
  padding: 1px var(--sp-2);
  border-radius: var(--r-sm);
  background: var(--info-soft);
  color: var(--info);
  font-size: var(--fs-xs);
}
.cite em {
  font-style: normal;
  opacity: 0.75;
}

/* 分页 */
.pager {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--sp-3);
  margin-top: var(--sp-3);
}
.pager__label {
  font-size: var(--fs-sm);
  color: var(--text-3);
  font-variant-numeric: tabular-nums;
}

@media (max-width: 900px) {
  .kv {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .seg {
    display: flex;
    width: 100%;
  }
  .seg__btn {
    flex: 1;
    align-items: center;
  }
}

/* 转为知识库：展开详情内操作条 */
.conv-actions {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  flex-wrap: wrap;
}
.conv-actions__hint {
  font-size: var(--fs-2xs);
  color: var(--text-4);
  line-height: 1.4;
}

/* 转为知识库：编辑弹窗表单 */
.kb-form {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.fld {
  display: flex;
  flex-direction: column;
  gap: var(--sp-1);
  flex: 1;
}
.fld__label {
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
  color: var(--text-2);
}
.fld__label em {
  font-style: normal;
  font-weight: var(--fw-normal);
  color: var(--text-4);
  font-size: var(--fs-2xs);
}
.fld-row {
  display: flex;
  gap: var(--sp-3);
  align-items: flex-end;
}
.fld--urgency {
  flex: 0 0 110px;
}
.kb-tip {
  margin: 0;
  font-size: var(--fs-2xs);
  color: var(--text-4);
  line-height: 1.5;
}
.kb-tip strong {
  color: var(--success);
}
</style>
