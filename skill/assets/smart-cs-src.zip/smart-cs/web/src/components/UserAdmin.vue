<script setup>
/**
 * 用户与权限（v2）
 * 功能保持：RBAC 用户列表、创建用户、重置密码
 * 优化：SCard 容器 + UI 组件库 + SModal 重置密码弹窗（取代 prompt/alert）+ Toast 反馈
 */
import { ref, computed, onMounted } from 'vue';
import { listUsers, createUser, changePassword } from '../api.js';
import { SCard, SButton, SInput, SSelect, SModal, SEmpty, SBadge } from './ui';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const ROLE_LABELS = { admin: '管理员', manager: '客服主管', agent: '客服' };
const ROLE_TONE = { admin: 'danger', manager: 'violet', agent: 'success' };
const ROLE_OPTIONS = [
  { value: 'agent', label: '客服' },
  { value: 'manager', label: '客服主管' },
  { value: 'admin', label: '管理员' }
];

const users = ref([]);
const loading = ref(true);
const loadErr = ref('');
const creating = ref(false);
const blank = () => ({ username: '', password: '', role: 'agent', display_name: '' });
const newUser = ref(blank());

// 重置密码弹窗
const pwdTarget = ref(null);
const pwdValue = ref('');
const pwdSaving = ref(false);

const roleCount = computed(() => {
  const c = { admin: 0, manager: 0, agent: 0 };
  users.value.forEach((u) => {
    if (c[u.role] !== undefined) c[u.role] += 1;
  });
  return c;
});

async function load() {
  loading.value = true;
  loadErr.value = '';
  try {
    users.value = await listUsers();
  } catch (e) {
    loadErr.value = '加载失败：' + e.message;
  } finally {
    loading.value = false;
  }
}

async function onCreate() {
  if (!newUser.value.username.trim() || !newUser.value.password) {
    toastError('用户名与密码必填');
    return;
  }
  creating.value = true;
  try {
    const r = await createUser({ ...newUser.value });
    if (r.ok) {
      newUser.value = blank();
      success('用户已创建');
      await load();
    } else {
      toastError(r.error || '创建失败');
    }
  } catch (e) {
    toastError('创建失败：' + (e.message || JSON.stringify(e)));
  } finally {
    creating.value = false;
  }
}

function openResetPwd(u) {
  pwdTarget.value = u;
  pwdValue.value = '';
}

async function confirmResetPwd() {
  if (!pwdValue.value) {
    toastError('请输入新密码');
    return;
  }
  pwdSaving.value = true;
  try {
    const r = await changePassword({
      target_username: pwdTarget.value.username,
      new_password: pwdValue.value
    });
    if (r.ok) {
      pwdTarget.value = null;
      success('密码已更新');
    } else {
      toastError(r.error || '重置失败');
    }
  } catch (e) {
    toastError('重置失败：' + e.message);
  } finally {
    pwdSaving.value = false;
  }
}

onMounted(load);
</script>

<template>
  <div class="users">
    <SCard
      icon="👤"
      title="用户与权限"
      :subtitle="`基于 RBAC 的角色管理 · 共 ${users.length} 个账号（管理员 ${roleCount.admin} / 主管 ${roleCount.manager} / 客服 ${roleCount.agent}）`"
    >
      <template #actions>
        <SButton variant="ghost" size="sm" icon="🔄" :loading="loading" @click="load">刷新</SButton>
      </template>

      <!-- 新建用户 -->
      <div class="create">
        <SInput v-model="newUser.username" placeholder="用户名" class="f-1" />
        <SInput v-model="newUser.password" type="password" placeholder="密码" class="f-1" />
        <SSelect v-model="newUser.role" :options="ROLE_OPTIONS" size="md" class="f-role" />
        <SInput v-model="newUser.display_name" placeholder="显示名（可选）" class="f-1" />
        <SButton variant="primary" icon="＋" :loading="creating" @click="onCreate">创建用户</SButton>
      </div>

      <!-- 列表 -->
      <SEmpty v-if="loading || loadErr" :loading="loading" :error="loadErr" @retry="load" />
      <SEmpty v-else-if="!users.length" icon="👤" title="暂无用户" desc="在上方表单创建第一个账号" />

      <div v-else class="tbl-wrap">
        <table class="tbl">
          <thead>
            <tr>
              <th>用户名</th>
              <th>角色</th>
              <th>显示名</th>
              <th class="ta-r">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td class="un">{{ u.username }}</td>
              <td>
                <SBadge :tone="ROLE_TONE[u.role] || 'neutral'" variant="soft">
                  {{ ROLE_LABELS[u.role] || u.role }}
                </SBadge>
              </td>
              <td>{{ u.display_name || '—' }}</td>
              <td class="ta-r">
                <SButton variant="ghost" size="sm" @click="openResetPwd(u)">重置密码</SButton>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </SCard>

    <!-- 重置密码 -->
    <SModal :model-value="!!pwdTarget" width="420px" @update:model-value="pwdTarget = null">
      <template #title>重置密码 · {{ pwdTarget?.username }}</template>
      <div v-if="pwdTarget" class="pwd">
        <SInput v-model="pwdValue" type="password" placeholder="输入新密码" @enter="confirmResetPwd" />
      </div>
      <template #footer>
        <SButton variant="ghost" @click="pwdTarget = null">取消</SButton>
        <SButton variant="primary" :loading="pwdSaving" :disabled="!pwdValue" @click="confirmResetPwd">
          确认重置
        </SButton>
      </template>
    </SModal>
  </div>
</template>

<style scoped>
.users {
  max-width: 900px;
}
.create {
  display: flex;
  gap: var(--sp-3);
  flex-wrap: wrap;
  align-items: center;
  margin-bottom: var(--sp-4);
}
.f-1 {
  flex: 1;
  min-width: 150px;
}
.f-role {
  width: 132px;
  flex-shrink: 0;
}
.tbl-wrap {
  overflow-x: auto;
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
}
.tbl {
  width: 100%;
  border-collapse: collapse;
}
.tbl th {
  padding: var(--sp-3);
  text-align: left;
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
  color: var(--text-3);
  background: var(--overlay-2);
  white-space: nowrap;
}
.tbl td {
  padding: var(--sp-3);
  font-size: var(--fs-base);
  color: var(--text-2);
  border-top: 1px solid var(--border);
}
.tbl tbody tr:hover td {
  background: var(--overlay-1);
}
.un {
  color: var(--brand-soft);
  font-weight: var(--fw-semibold);
}
.ta-r {
  text-align: right;
}
.pwd :deep(input) {
  width: 100%;
}

@media (max-width: 640px) {
  .f-role {
    width: 100%;
  }
}
</style>
