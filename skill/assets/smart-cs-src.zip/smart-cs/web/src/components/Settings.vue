<script setup>
/**
 * 部署配置（面向快速复制）
 *
 * 一个页面管完复制到新客户需要改的全部内容：
 *   企业档案 / 挂件外观与预置问题 / 模型引擎 / 知识库接入
 * 并提供「导出 JSON / 导入 JSON / 套用模板」，把一套成熟配置复制到下一家。
 *
 * 改动模型与知识库后要点「应用生效」重载引擎，无需重启服务。
 */
import { ref, reactive, computed, onMounted } from 'vue';
import {
  getDeployConfig,
  saveDeployConfig,
  saveDeploySection,
  applyDeployTemplate,
  resetDeployConfig,
  applyDeployConfig,
  listDeployTemplates
} from '../api.js';
import { SCard, STabs, SButton, SInput, SSelect, SEmpty, SBadge } from './ui';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const TABS = [
  { id: 'tenant', label: '企业档案', icon: '🏢', sub: '访客端权威背景知识' },
  { id: 'widget', label: '挂件外观', icon: '💬', sub: '标题文案与预置问题' },
  { id: 'llm', label: '模型引擎', icon: '🧠', sub: 'Provider 与模型' },
  { id: 'knowledge', label: '知识库接入', icon: '📚', sub: '本地 / IMA / 飞书' }
];

const tab = ref('tenant');
const loading = ref(true);
const loadErr = ref('');
const templates = ref([]);
const savingKey = ref('');
const applying = ref(false);
const form = reactive({ tenant: {}, widget: {}, llm: {}, knowledge: {} });

/** 多行列表字段在表单里用换行编辑，提交时再转数组 */
const listDraft = reactive({ business: '', advantages: '', presetQuestions: '' });

const PROVIDER_OPTIONS = [
  { value: 'offline', label: 'offline · 离线启发式（零依赖）' },
  { value: 'ollama', label: 'ollama · 本地模型' },
  { value: 'api', label: 'api · OpenAI 兼容接口' }
];

const KB_OPTIONS = [
  { value: 'local', label: 'local · 本地 SQLite 知识库' },
  { value: 'ima', label: 'ima · 腾讯 IMA 知识库' },
  { value: 'feishu', label: 'feishu · 飞书知识库' }
];

const masked = computed(() => ({
  apiKey: form.llm.api_key ? form.llm.api_key.slice(0, 6) + '••••••' : '',
  imaKey: form.knowledge.ima_api_key ? form.knowledge.ima_api_key.slice(0, 6) + '••••••' : '',
  feishuSecret: form.knowledge.feishu_app_secret
    ? form.knowledge.feishu_app_secret.slice(0, 6) + '••••••'
    : ''
}));

const hasEngineChange = computed(() => tab.value === 'llm' || tab.value === 'knowledge');

function fill(cfg) {
  Object.assign(form.tenant, cfg.tenant || {});
  Object.assign(form.widget, cfg.widget || {});
  Object.assign(form.llm, cfg.llm || {});
  Object.assign(form.knowledge, cfg.knowledge || {});
  listDraft.business = (form.tenant.business || []).join('\n');
  listDraft.advantages = (form.tenant.advantages || []).join('\n');
  listDraft.presetQuestions = (form.widget.presetQuestions || []).join('\n');
}

async function load() {
  loading.value = true;
  loadErr.value = '';
  try {
    const r = await getDeployConfig();
    fill(r.config || {});
    templates.value = r.templates || [];
  } catch (e) {
    loadErr.value = e.message;
  } finally {
    loading.value = false;
  }
}

function toLines(s) {
  return String(s || '')
    .split('\n')
    .map((x) => x.trim())
    .filter(Boolean);
}

async function saveCurrentTab() {
  const key = tab.value;
  savingKey.value = key;
  try {
    let patch;
    if (key === 'tenant') {
      patch = {
        ...form.tenant,
        business: toLines(listDraft.business),
        advantages: toLines(listDraft.advantages)
      };
    } else if (key === 'widget') {
      patch = { ...form.widget, presetQuestions: toLines(listDraft.presetQuestions) };
    } else {
      patch = { ...form[key] };
    }
    const r = await saveDeploySection(key, patch);
    fill(r.config || {});
    success(hasEngineChange.value ? '已保存，点「应用生效」重载引擎' : '已保存');
  } catch (e) {
    toastError('保存失败：' + e.message);
  } finally {
    savingKey.value = '';
  }
}

async function onApply() {
  applying.value = true;
  try {
    const r = await applyDeployConfig();
    const info = r.llm || {};
    success(
      `引擎已重载：model=${info.model || '—'} · llm=${info.mode || '—'} · embedding=${info.embed_mode || '—'} · kb=${r.effective?.kb_source || '—'}`
    );
  } catch (e) {
    toastError('应用失败：' + e.message);
  } finally {
    applying.value = false;
  }
}

async function onTemplate(name) {
  if (!confirm(`套用模板「${name}」会覆盖当前全部配置，确认继续？`)) return;
  try {
    const r = await applyDeployTemplate(name);
    fill(r.config || {});
    success('模板已套用，请检查密钥并点「应用生效」');
  } catch (e) {
    toastError('套用失败：' + e.message);
  }
}

function onExport() {
  const blob = new Blob([JSON.stringify({ tenant: form.tenant, widget: form.widget, llm: { ...form.llm, api_key: '' }, knowledge: { ...form.knowledge, ima_api_key: '', feishu_app_secret: '' } }, null, 2)], {
    type: 'application/json'
  });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `deploy-${form.tenant.brand || 'template'}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  success('已导出（密钥已剔除，需在新环境重新填写）');
}

const importOpen = ref(false);
const importText = ref('');

async function doImport() {
  try {
    const parsed = JSON.parse(importText.value);
    const r = await saveDeployConfig(parsed);
    fill(r.config || {});
    importOpen.value = false;
    importText.value = '';
    success('配置已导入');
  } catch (e) {
    toastError('导入失败：' + e.message);
  }
}

onMounted(async () => {
  await load();
  try {
    const t = await listDeployTemplates();
    templates.value = t.templates || templates.value;
  } catch {
    /* 模板列表失败不阻塞主流程 */
  }
});
</script>

<template>
  <div class="settings">
    <STabs v-model="tab" :tabs="TABS" />

    <SEmpty v-if="loading || loadErr" :loading="loading" :error="loadErr" @retry="load" class="mt" />

    <template v-else>
      <!-- ========== 企业档案 ========== -->
      <SCard
        v-if="tab === 'tenant'"
        icon="🏢"
        title="企业档案"
        subtitle="访客端对话时注入的权威背景知识，知识库未命中时 AI 也会依据它作答"
        class="mt"
      >
        <template #actions>
          <SButton variant="ghost" size="sm" @click="onExport">导出 JSON</SButton>
          <SButton variant="ghost" size="sm" @click="importOpen = true">导入 JSON</SButton>
          <SButton variant="primary" size="sm" :loading="savingKey === 'tenant'" @click="saveCurrentTab">保存</SButton>
        </template>

        <div class="grid2">
          <label class="fld"><span>公司全称</span><SInput v-model="form.tenant.name" placeholder="杭州某某科技有限公司" /></label>
          <label class="fld"><span>品牌名</span><SInput v-model="form.tenant.brand" placeholder="对外简称" /></label>
          <label class="fld"><span>英文名</span><SInput v-model="form.tenant.english" placeholder="可选" /></label>
          <label class="fld"><span>成立时间</span><SInput v-model="form.tenant.founded" placeholder="如 2026 年" /></label>
          <label class="fld"><span>官网</span><SInput v-model="form.tenant.website" placeholder="https://" /></label>
          <label class="fld"><span>更新日期</span><SInput v-model="form.tenant.updated" placeholder="2026-08-28" /></label>
          <label class="fld"><span>联系电话</span><SInput v-model="form.tenant.phone" /></label>
          <label class="fld"><span>联系邮箱</span><SInput v-model="form.tenant.email" /></label>
        </div>

        <label class="fld mt"><span>企业定位（一句话）</span>
          <SInput v-model="form.tenant.positioning" type="textarea" :rows="2" />
        </label>

        <div class="grid2 mt">
          <label class="fld"><span>业务范围（一行一条）</span>
            <SInput v-model="listDraft.business" type="textarea" :rows="5" placeholder="AI 客服系统&#10;数据智能分析" />
          </label>
          <label class="fld"><span>核心优势（一行一条）</span>
            <SInput v-model="listDraft.advantages" type="textarea" :rows="5" placeholder="交付快&#10;成本低" />
          </label>
        </div>

        <label class="fld mt"><span>服务范围边界</span>
          <SInput v-model="form.tenant.scopeNote" type="textarea" :rows="3"
            placeholder="超出业务范围时 AI 该如何回应；留空则自动生成「转人工联系」话术" />
        </label>
      </SCard>

      <!-- ========== 挂件外观 ========== -->
      <SCard
        v-else-if="tab === 'widget'"
        icon="💬"
        title="挂件外观与预置问题"
        subtitle="官网悬浮挂件的文案、配色与快捷提问；保存后访客刷新页面即刻生效"
        class="mt"
      >
        <template #actions>
          <SButton variant="primary" size="sm" :loading="savingKey === 'widget'" @click="saveCurrentTab">保存</SButton>
        </template>

        <div class="grid2">
          <label class="fld"><span>挂件标题</span><SInput v-model="form.widget.title" /></label>
          <label class="fld"><span>底部署名</span><SInput v-model="form.widget.powered" /></label>
        </div>

        <label class="fld mt"><span>欢迎语</span>
          <SInput v-model="form.widget.greeting" type="textarea" :rows="3" />
        </label>

        <div class="grid2 mt">
          <label class="fld"><span>输入框占位文案</span><SInput v-model="form.widget.placeholder" /></label>
          <label class="fld"><span>站点标识（预留）</span><SInput v-model="form.widget.siteToken" /></label>
        </div>

        <div class="grid2 mt">
          <label class="fld"><span>主题色 · 起</span>
            <div class="color">
              <input v-model="form.widget.accentFrom" type="color" />
              <SInput v-model="form.widget.accentFrom" class="mono" />
            </div>
          </label>
          <label class="fld"><span>主题色 · 止</span>
            <div class="color">
              <input v-model="form.widget.accentTo" type="color" />
              <SInput v-model="form.widget.accentTo" class="mono" />
            </div>
          </label>
        </div>

        <label class="fld mt"><span>预置问题（一行一条，最多 8 条）</span>
          <SInput v-model="listDraft.presetQuestions" type="textarea" :rows="5" placeholder="你们主要做哪些业务？&#10;怎么联系你们？" />
        </label>
        <p class="hint">预置问题只在访客还没开口前显示，点一下直接发送。</p>
      </SCard>

      <!-- ========== 模型引擎 ========== -->
      <SCard
        v-else-if="tab === 'llm'"
        icon="🧠"
        title="模型引擎"
        :subtitle="`当前：${masked.apiKey || '未配置密钥'}`"
        class="mt"
      >
        <template #actions>
          <SButton variant="warn" size="sm" :loading="applying" @click="onApply">应用生效</SButton>
          <SButton variant="primary" size="sm" :loading="savingKey === 'llm'" @click="saveCurrentTab">保存</SButton>
        </template>

        <div class="grid2">
          <label class="fld"><span>Provider</span>
            <SSelect v-model="form.llm.provider" :options="PROVIDER_OPTIONS" />
          </label>
          <label class="fld"><span>API 基址</span>
            <SInput v-model="form.llm.base" placeholder="https://api.example.com/v1" />
          </label>
          <label class="fld"><span>对话模型</span><SInput v-model="form.llm.model" /></label>
          <label class="fld"><span>向量模型</span><SInput v-model="form.llm.embed_model" /></label>
        </div>

        <label class="fld mt"><span>API Key</span>
          <SInput v-model="form.llm.api_key" type="password" placeholder="留空表示沿用环境变量" />
        </label>
        <p class="hint">引擎配置了但连不上时会自动回退 offline，服务不会中断。</p>
      </SCard>

      <!-- ========== 知识库接入 ========== -->
      <SCard v-else icon="📚" title="知识库接入" class="mt">
        <template #actions>
          <SButton variant="warn" size="sm" :loading="applying" @click="onApply">应用生效</SButton>
          <SButton variant="primary" size="sm" :loading="savingKey === 'knowledge'" @click="saveCurrentTab">保存</SButton>
        </template>

        <label class="fld"><span>知识库来源</span>
          <SSelect v-model="form.knowledge.kb_source" :options="KB_OPTIONS" />
        </label>

        <div class="grid2 mt">
          <label class="fld"><span>IMA Client ID</span><SInput v-model="form.knowledge.ima_client_id" /></label>
          <label class="fld"><span>IMA API Key</span>
            <SInput v-model="form.knowledge.ima_api_key" type="password" />
          </label>
        </div>
        <label class="fld mt"><span>IMA 知识库 ID</span><SInput v-model="form.knowledge.ima_kb_id" /></label>

        <div class="grid2 mt">
          <label class="fld"><span>飞书 App ID</span><SInput v-model="form.knowledge.feishu_app_id" /></label>
          <label class="fld"><span>飞书 App Secret</span>
            <SInput v-model="form.knowledge.feishu_app_secret" type="password" />
          </label>
        </div>
        <label class="fld mt"><span>飞书知识空间 ID（多个逗号分隔）</span>
          <SInput v-model="form.knowledge.feishu_space_ids" />
        </label>

        <div class="grid2 mt">
          <label class="fld"><span>同步 cron</span><SInput v-model="form.knowledge.feishu_sync.cron" /></label>
          <label class="fld"><span>同步关键词</span><SInput v-model="form.knowledge.feishu_sync.keyword" /></label>
        </div>
      </SCard>

      <!-- 模板区 -->
      <SCard icon="📦" title="复制这套配置" subtitle="导出后在新环境导入，即可复用到下一个客户" class="mt" :padded="true">
        <template #actions>
          <SBadge tone="neutral" variant="soft">{{ templates.length }} 个内置模板</SBadge>
        </template>
        <p class="hint">导出的 JSON 会自动剔除所有密钥，导入新环境后只需补填模型与知识库凭据。</p>
        <div class="tpl-row">
          <SButton v-for="t in templates" :key="t" variant="default" size="sm" @click="onTemplate(t)">
            套用 {{ t }}
          </SButton>
          <SButton variant="ghost" size="sm" @click="onExport">导出当前配置</SButton>
          <SButton variant="ghost" size="sm" @click="importOpen = true">导入配置</SButton>
        </div>
      </SCard>
    </template>

    <!-- 导入弹窗 -->
    <div v-if="importOpen" class="mask" @click.self="importOpen = false">
      <div class="dlg">
        <h3>导入部署配置</h3>
        <textarea v-model="importText" rows="14" placeholder="粘贴 deploy JSON…"></textarea>
        <div class="dlg-foot">
          <SButton variant="ghost" @click="importOpen = false">取消</SButton>
          <SButton variant="primary" :disabled="!importText.trim()" @click="doImport">导入</SButton>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.settings {
  max-width: 960px;
}
.mt {
  margin-top: var(--sp-4);
}
.grid2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
}
.fld {
  display: block;
  min-width: 0;
}
.fld > span {
  display: block;
  margin-bottom: var(--sp-1);
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.hint {
  margin: var(--sp-2) 0 0;
  font-size: var(--fs-sm);
  color: var(--text-3);
  line-height: 1.6;
}
.color {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
}
.color input[type='color'] {
  flex-shrink: 0;
  width: 38px;
  height: 34px;
  padding: 2px;
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  background: transparent;
  cursor: pointer;
}
.mono :deep(input) {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
}
.tpl-row {
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
  margin-top: var(--sp-3);
}

.mask {
  position: fixed;
  inset: 0;
  z-index: var(--z-modal);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--sp-5);
  background: rgba(2, 6, 23, 0.62);
}
.dlg {
  width: 620px;
  max-width: 100%;
  padding: var(--sp-5);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-2xl);
  background: var(--surface-elevated);
  box-shadow: var(--shadow-lg);
}
.dlg h3 {
  margin: 0 0 var(--sp-3);
  font-size: var(--fs-lg);
  color: var(--text-1);
}
.dlg textarea {
  width: 100%;
  padding: var(--sp-3);
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  background: var(--surface-0);
  color: var(--text-1);
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
  line-height: 1.6;
  resize: vertical;
}
.dlg-foot {
  display: flex;
  justify-content: flex-end;
  gap: var(--sp-3);
  margin-top: var(--sp-4);
}

@media (max-width: 720px) {
  .grid2 {
    grid-template-columns: 1fr;
  }
}
</style>
