<!--
  统一知识条目卡片
  Props: item (knowledge_item), compact=false
  Events: edit(item) / delete(item) / publish(item) / unpublish(item)
  用途：工单回流、飞书/IMA同步、历史FAQ 三个 tab 共用同一套卡片渲染。

  v2 变化：接入设计系统 token（来源色改用 CSS 变量 class），
  操作按钮改用 SButton，状态/质量分改用 SBadge。对外 Props/Events 完全不变。
-->
<script setup>
import { ref, computed } from 'vue';
import SButton from './ui/SButton.vue';
import SBadge from './ui/SBadge.vue';

const props = defineProps({
  item: { type: Object, required: true },
  compact: { type: Boolean, default: false }
});
const emit = defineEmits(['edit', 'delete', 'publish', 'unpublish']);

const expanded = ref(false);

const SRC_LABEL = {
  manual: '人工',
  ticket: '工单',
  faq: '历史FAQ',
  feishu: '飞书',
  ima: 'IMA',
  conversation: '对话',
  file: '本地文件'
};

const URGENCY_LABEL = ['', '一般', '较急', '紧急'];

/* 质量分分级：>=0.6 优良 / >=0.35 待优化 / 其余 待复审 */
function qualityGrade(score) {
  if (score == null) return { tone: 'neutral', t: '—' };
  if (score >= 0.6) return { tone: 'success', t: '优良' };
  if (score >= 0.35) return { tone: 'warn', t: '待优化' };
  return { tone: 'danger', t: '待复审' };
}

const grade = computed(() => qualityGrade(props.item.quality_score));
const isPublished = computed(() => props.item.status === 'published');
const canExpand = computed(() => props.item.solution && props.item.solution.length > 120);

/* 转义 HTML 防 XSS，换行转 <br>（与 v1 行为一致） */
function highlightText(text) {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\n/g, '<br>');
}

function onEdit() {
  emit('edit', props.item);
}
function onDelete() {
  emit('delete', props.item);
}
function onPublish() {
  emit('publish', props.item);
}
function onUnpublish() {
  emit('unpublish', props.item);
}
</script>

<template>
  <article class="kc" :class="{ compact }">
    <div class="kc-head">
      <div class="kc-main">
        <h4 class="title">{{ item.question }}</h4>
        <div class="meta-row">
          <span class="src-badge" :class="`src-${item.source_type}`">
            {{ SRC_LABEL[item.source_type] || '人工' }}
          </span>

          <SBadge :tone="isPublished ? 'success' : 'neutral'" size="sm">
            {{ isPublished ? '已发布' : '草稿' }}
          </SBadge>

          <SBadge v-if="item.category" tone="violet" size="sm">{{ item.category }}</SBadge>
          <SBadge v-if="item.product_module" tone="neutral" size="sm">{{ item.product_module }}</SBadge>
          <SBadge :tone="['success', 'info', 'warn'][(item.urgency || 1) - 1] || 'success'" size="sm">
            {{ URGENCY_LABEL[item.urgency] || '一般' }}
          </SBadge>
        </div>
      </div>

      <div class="quality">
        <span class="qs-pill" :class="`qs-${grade.tone}`">
          {{ item.quality_score != null ? item.quality_score.toFixed(2) : '—' }}
        </span>
        <span class="qs-label">{{ grade.t }}</span>
        <span v-if="item.feedback_pos || item.feedback_neg" class="fb">
          👍{{ item.feedback_pos || 0 }} 👎{{ item.feedback_neg || 0 }}
        </span>
        <span class="hits">命中 {{ item.hit_count || 0 }}</span>
      </div>
    </div>

    <div class="kc-body">
      <p class="solution" :class="{ 'is-clamped': canExpand && !expanded }" v-html="highlightText(item.solution)"></p>
      <button v-if="canExpand" class="expand-btn" @click="expanded = !expanded">
        {{ expanded ? '收起' : '展开全部' }}
      </button>
    </div>

    <div v-if="item.extracted_from" class="extra-row">
      <span class="muted">由对话 {{ item.extracted_from }} 提炼生成</span>
      <span v-if="item.last_hit_at" class="muted">
        最后命中 {{ new Date(item.last_hit_at).toLocaleDateString('zh-CN') }}
      </span>
    </div>

    <div class="kc-actions">
      <SButton size="sm" variant="ghost" @click="onEdit">编辑</SButton>
      <SButton v-if="!isPublished" size="sm" variant="success" @click="onPublish">发布</SButton>
      <SButton v-else size="sm" variant="ghost" @click="onUnpublish">撤下</SButton>
      <SButton size="sm" variant="danger" @click="onDelete">删除</SButton>
    </div>
  </article>
</template>

<style scoped>
.kc {
  background: var(--overlay-1);
  border: 1px solid var(--border);
  border-radius: var(--r-xl);
  padding: var(--sp-4) var(--sp-4);
  transition: border-color var(--dur) var(--ease), box-shadow var(--dur) var(--ease);
}

.kc:hover {
  border-color: var(--brand-ring);
  box-shadow: var(--shadow-md);
}

.kc.compact {
  padding: var(--sp-3);
}

.kc-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: var(--sp-3);
  margin-bottom: var(--sp-2);
}

.kc-main {
  flex: 1;
  min-width: 0;
}

.title {
  margin: 0 0 var(--sp-2);
  font-size: var(--fs-md);
  font-weight: var(--fw-bold);
  color: var(--text-1);
  line-height: 1.4;
  word-break: break-word;
}

.meta-row {
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
  align-items: center;
}

/* ===== 来源徽章：颜色走 CSS 变量，随主题自适应 ===== */
.src-badge {
  border: 1px solid var(--src-color);
  color: var(--src-color);
  border-radius: var(--r-sm);
  padding: 1px 8px;
  font-size: var(--fs-xs);
  white-space: nowrap;
  background: transparent;
  line-height: 1.5;
}

.src-manual {
  --src-color: var(--brand);
}
.src-ticket {
  --src-color: var(--violet);
}
.src-faq {
  --src-color: var(--warn);
}
.src-feishu {
  --src-color: var(--info);
}
.src-ima {
  --src-color: var(--success);
}
.src-conversation {
  --src-color: var(--success);
}
.src-file {
  --src-color: var(--orange);
}

/* ===== 质量分 ===== */
.quality {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 3px;
  flex-shrink: 0;
  min-width: 80px;
}

.qs-pill {
  border: 1px solid var(--qs-color);
  color: var(--qs-color);
  border-radius: var(--r-sm);
  padding: 1px 8px;
  font-size: var(--fs-base);
  font-weight: var(--fw-bold);
  font-variant-numeric: tabular-nums;
  line-height: 1.5;
}

.qs-success {
  --qs-color: var(--success);
}
.qs-warn {
  --qs-color: var(--warn);
}
.qs-danger {
  --qs-color: var(--danger);
}
.qs-neutral {
  --qs-color: var(--text-4);
}

.qs-label {
  font-size: var(--fs-xs);
  color: var(--qs-color, var(--text-4));
}

.fb,
.hits {
  font-size: var(--fs-xs);
  color: var(--text-4);
}

/* ===== 正文 ===== */
.kc-body {
  margin: var(--sp-2) 0;
}

.solution {
  color: var(--text-2);
  font-size: var(--fs-base);
  line-height: 1.7;
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
}

.solution.is-clamped {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.expand-btn {
  background: none;
  border: none;
  color: var(--brand);
  cursor: pointer;
  font-size: var(--fs-sm);
  font-family: inherit;
  padding: var(--sp-1) 0;
  margin-top: var(--sp-1);
}
.expand-btn:hover {
  text-decoration: underline;
}

.extra-row {
  display: flex;
  gap: var(--sp-4);
  margin: var(--sp-2) 0;
  flex-wrap: wrap;
}

.muted {
  color: var(--text-4);
  font-size: var(--fs-xs);
}

.kc-actions {
  display: flex;
  gap: var(--sp-2);
  margin-top: var(--sp-3);
  padding-top: var(--sp-3);
  border-top: 1px solid var(--border);
}

/* 紧凑模式：正文默认隐藏，hover 浮层展示 */
.kc.compact .kc-body {
  display: none;
}
.kc.compact {
  position: relative;
}
.kc.compact:hover .kc-body {
  display: block;
  position: absolute;
  z-index: var(--z-dropdown);
  width: 100%;
  left: 0;
  padding: var(--sp-3);
  background: var(--surface-elevated);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-lg);
}
</style>
