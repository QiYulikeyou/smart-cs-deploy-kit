<script setup>
/**
 * 背景设置面板 —— 预设渐变 / 自定义颜色 / 背景图片
 * v2：预设列表跟随当前明暗主题（深色主题给深色预设，浅色主题给浅色预设）
 */
import { ref, computed, onMounted, onUnmounted } from 'vue';
import {
  themeState,
  presetsFor,
  setGradient,
  setColor,
  setImage,
  resetBackground
} from '../composables/useTheme.js';

const open = ref(false);
const customColor = ref('#0ea5e9');
const imgUrl = ref('');
const rootEl = ref(null);

const presets = computed(() => presetsFor(themeState.mode));

function pickPreset(t) {
  setGradient(t.value, t.name);
}
function applyColor() {
  if (/^#[0-9a-fA-F]{6}$/.test(customColor.value)) setColor(customColor.value);
}
function applyUrl() {
  if (imgUrl.value.trim()) setImage(imgUrl.value.trim());
}
function onFile(e) {
  const f = e.target.files?.[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => setImage(reader.result);
  reader.readAsDataURL(f);
}
function onReset() {
  resetBackground();
}

/* 点击外部关闭 */
function onDocClick(e) {
  if (!open.value) return;
  if (rootEl.value && !rootEl.value.contains(e.target)) open.value = false;
}
onMounted(() => document.addEventListener('click', onDocClick));
onUnmounted(() => document.removeEventListener('click', onDocClick));
</script>

<template>
  <div ref="rootEl" class="bgs">
    <button class="trigger" :class="{ 'is-open': open }" title="更换背景" @click="open = !open">🎨</button>

    <Transition name="pop">
      <div v-if="open" class="panel">
        <div class="ph">
          <span>背景设置</span>
          <button class="x" title="关闭" @click="open = false">✕</button>
        </div>

        <div class="sec">
          预设主题
          <span class="sec-tag">{{ themeState.mode === 'dark' ? '深色' : '浅色' }}</span>
        </div>
        <div class="presets">
          <button
            v-for="t in presets"
            :key="t.id"
            class="preset"
            :class="{ active: themeState.bg.name === t.name }"
            :style="{ backgroundImage: t.value }"
            :title="t.name"
            @click="pickPreset(t)"
          ></button>
        </div>

        <div class="sec">自定义颜色</div>
        <div class="row">
          <input v-model="customColor" type="color" class="color-pick" />
          <input v-model="customColor" class="txt" placeholder="#0ea5e9" />
          <button class="mini" @click="applyColor">应用</button>
        </div>

        <div class="sec">背景图片</div>
        <div class="row">
          <input v-model="imgUrl" class="txt" placeholder="粘贴图片 URL" />
          <button class="mini" @click="applyUrl">应用</button>
        </div>
        <label class="upload">
          从本地上传
          <input type="file" accept="image/*" hidden @change="onFile" />
        </label>

        <div class="foot">
          <span class="cur" :title="themeState.bg.name">{{ themeState.bg.name || '自定义' }}</span>
          <button class="reset" @click="onReset">恢复默认</button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
.bgs {
  position: relative;
}

.trigger {
  width: 32px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--r-md);
  border: 1px solid var(--border);
  background: var(--overlay-1);
  color: var(--text-2);
  cursor: pointer;
  font-size: var(--fs-md);
  line-height: 1;
  transition: var(--dur-fast) var(--ease);
}
.trigger:hover,
.trigger.is-open {
  border-color: var(--brand);
  background: var(--overlay-2);
}

.panel {
  position: absolute;
  top: calc(100% + 10px);
  right: 0;
  width: 272px;
  padding: var(--sp-4);
  border-radius: var(--r-xl);
  border: 1px solid var(--border-strong);
  background: var(--surface-elevated);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  box-shadow: var(--shadow-lg);
  z-index: var(--z-dropdown);
}

.ph {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: var(--fs-md);
  font-weight: var(--fw-bold);
  color: var(--text-1);
  margin-bottom: var(--sp-2);
}

.x {
  background: none;
  border: 0;
  color: var(--text-4);
  cursor: pointer;
  font-size: var(--fs-md);
  padding: 0 2px;
  line-height: 1;
}
.x:hover {
  color: var(--danger-text);
}

.sec {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  font-size: var(--fs-xs);
  color: var(--text-4);
  margin: var(--sp-4) 0 var(--sp-2);
  letter-spacing: 0.5px;
}

.sec-tag {
  padding: 1px 6px;
  border-radius: var(--r-xs);
  background: var(--brand-glow);
  color: var(--brand-soft);
  font-size: var(--fs-2xs);
  letter-spacing: 0;
}

.presets {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--sp-2);
}

.preset {
  height: 40px;
  border-radius: var(--r-md);
  border: 2px solid transparent;
  cursor: pointer;
  background-size: cover;
  transition: transform var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease);
}
.preset:hover {
  transform: scale(1.05);
}
.preset.active {
  border-color: var(--brand);
  box-shadow: 0 0 0 2px var(--brand-glow);
}

.row {
  display: flex;
  gap: var(--sp-2);
  align-items: center;
}

.color-pick {
  width: 38px;
  height: 32px;
  flex-shrink: 0;
  border: 1px solid var(--border-strong);
  border-radius: var(--r-sm);
  background: none;
  cursor: pointer;
  padding: 2px;
}

.txt {
  flex: 1;
  min-width: 0;
  padding: 7px 9px;
  border-radius: var(--r-sm);
  border: 1px solid var(--border-strong);
  background: var(--overlay-1);
  color: var(--text-1);
  font-size: var(--fs-sm);
  font-family: inherit;
  outline: none;
}
.txt:focus {
  border-color: var(--brand);
}

.mini {
  flex-shrink: 0;
  padding: 7px 12px;
  border: 0;
  border-radius: var(--r-sm);
  background: linear-gradient(135deg, var(--brand-strong), var(--brand-deep));
  color: #fff;
  font-size: var(--fs-sm);
  font-family: inherit;
  font-weight: var(--fw-semibold);
  cursor: pointer;
}
.mini:hover {
  filter: brightness(1.1);
}

.upload {
  display: block;
  margin-top: var(--sp-2);
  text-align: center;
  padding: 9px;
  border: 1px dashed var(--border-strong);
  border-radius: var(--r-md);
  cursor: pointer;
  font-size: var(--fs-sm);
  color: var(--text-2);
  transition: var(--dur-fast) var(--ease);
}
.upload:hover {
  border-color: var(--brand);
  color: var(--brand);
}

.foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-2);
  margin-top: var(--sp-4);
  padding-top: var(--sp-3);
  border-top: 1px solid var(--border);
}

.cur {
  font-size: var(--fs-xs);
  color: var(--text-4);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.reset {
  flex-shrink: 0;
  padding: 4px 10px;
  border-radius: var(--r-sm);
  border: 1px solid var(--border-strong);
  background: transparent;
  color: var(--text-3);
  font-size: var(--fs-xs);
  font-family: inherit;
  cursor: pointer;
  transition: var(--dur-fast) var(--ease);
}
.reset:hover {
  border-color: var(--brand);
  color: var(--brand);
}

/* 弹出动画 */
.pop-enter-active,
.pop-leave-active {
  transition: opacity var(--dur) var(--ease), transform var(--dur) var(--ease-out);
}
.pop-enter-from,
.pop-leave-to {
  opacity: 0;
  transform: translateY(-6px) scale(0.98);
}
</style>
