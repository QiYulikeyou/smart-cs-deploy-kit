<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { getStats, getRiskTrend } from '../api.js';

const stats = ref({ tickets: 0, knowledge: 0, alerts: 0, urgent: 0 });
const trendDays = ref(7);
const trendData = ref([]);
const trendLoading = ref(false);
const loading = ref(true);
const updatedAt = ref('');
let timer = null;

async function refresh() {
  try {
    const s = await getStats();
    stats.value = {
      tickets: s.tickets || 0,
      knowledge: s.knowledge || 0,
      urgent: s.urgent || 0,
      alerts: s.alerts || 0
    };
    updatedAt.value = new Date().toLocaleTimeString('zh-CN');
  } catch (e) {
    if (loading.value) stats.value = { error: e.message };
  } finally {
    loading.value = false;
  }
}

async function loadTrend() {
  trendLoading.value = true;
  try {
    const r = await getRiskTrend(trendDays.value);
    trendData.value = r.data || [];
  } catch (e) {
    console.warn('风险趋势加载失败', e);
  } finally {
    trendLoading.value = false;
  }
}

function changeDays(d) {
  trendDays.value = d;
  loadTrend();
}

onMounted(() => {
  refresh();
  loadTrend();
  timer = setInterval(refresh, 15000);
});
onUnmounted(() => {
  if (timer) clearInterval(timer);
});

const cards = [
  { key: 'tickets', label: '工单总数', icon: '🎫', color: '#22d3ee' },
  { key: 'knowledge', label: '知识条目', icon: '📚', color: '#a78bfa' },
  { key: 'urgent', label: '紧急工单', icon: '🔥', color: '#fb7185' },
  { key: 'alerts', label: '待复核预警', icon: '⚠️', color: '#fbbf24' }
];

// 优化的 SVG 图表配置
const CHART_CONFIG = {
  height: 200,
  width: 700,
  padding: { top: 30, right: 30, bottom: 40, left: 50 },
  colors: {
    high: '#f87171',
    mid: '#fbbf24',
    low: '#4ade80',
    grid: 'rgba(255,255,255,0.08)',
    text: '#94a3b8',
    axis: 'rgba(255,255,255,0.2)'
  }
};

const chartSvg = computed(() => {
  if (!trendData.value.length || trendLoading.value) return null;
  
  const data = trendData.value;
  const maxVal = Math.max(...data.map(d => d.total), 1);
  const { height: H, width: W, padding: P } = CHART_CONFIG;
  const plotW = W - P.left - P.right;
  const plotH = H - P.top - P.bottom;
  
  // 缩放函数
  const scaleX = (i) => P.left + (i / Math.max(data.length - 1, 1)) * plotW;
  const scaleY = (v) => P.top + plotH - (v / maxVal) * plotH;
  
  // 生成路径
  const makePath = (key) => {
    return data.map((d, i) => 
      `${i === 0 ? 'M' : 'L'}${scaleX(i).toFixed(1)},${scaleY(d[key]).toFixed(1)}`
    ).join(' ');
  };
  
  // 生成面积路径
  const makeAreaPath = (key) => {
    const linePath = makePath(key);
    const lastX = scaleX(data.length - 1);
    const firstX = scaleX(0);
    const bottomY = scaleY(0);
    return `${linePath} L${lastX},${bottomY} L${firstX},${bottomY} Z`;
  };
  
  // 网格线
  const gridLines = [0, 0.25, 0.5, 0.75, 1].map(f => {
    const y = scaleY(maxVal * f);
    const label = Math.round(maxVal * f);
    return `
      <line x1="${P.left}" y1="${y}" x2="${W - P.right}" y2="${y}" 
            stroke="${CHART_CONFIG.colors.grid}" stroke-width="1"/>
      <text x="${P.left - 8}" y="${y + 4}" text-anchor="end"
            fill="${CHART_CONFIG.colors.text}" font-size="9">${label}</text>
    `;
  }).join('');
  
  // X轴标签
  const labelCount = Math.min(data.length, 7);
  const step = Math.max(Math.floor(data.length / labelCount), 1);
  const xLabels = data.map((d, i) => 
    i % step === 0 || i === data.length - 1 
      ? `<text x="${scaleX(i)}" y="${H - 10}" text-anchor="middle" 
               fill="${CHART_CONFIG.colors.text}" font-size="9">${d.date.slice(5)}</text>`
      : ''
  ).filter(Boolean).join('');
  
  // 数据点（仅显示有数据的）
  const dataPoints = data.map((d, i) => {
    const hasHigh = d.high > 0;
    const hasMid = d.mid > 0;
    const hasLow = d.low > 0;
    return `
      ${hasHigh ? `<circle cx="${scaleX(i)}" cy="${scaleY(d.high)}" r="4" 
                   fill="${CHART_CONFIG.colors.high}" stroke="#1e293b" stroke-width="2"/>` : ''}
      ${hasMid ? `<circle cx="${scaleX(i)}" cy="${scaleY(d.mid)}" r="3" 
                  fill="${CHART_CONFIG.colors.mid}" stroke="#1e293b" stroke-width="1.5"/>` : ''}
      ${hasLow ? `<circle cx="${scaleX(i)}" cy="${scaleY(d.low)}" r="2.5" 
                  fill="${CHART_CONFIG.colors.low}" stroke="#1e293b" stroke-width="1"/>` : ''}
    `;
  }).join('');
  
  // 图例
  const legendX = W - 160;
  const legendItems = [
    { color: CHART_CONFIG.colors.high, label: `高风险 (${data[data.length-1].high})` },
    { color: CHART_CONFIG.colors.mid, label: `中风险 (${data[data.length-1].mid})` },
    { color: CHART_CONFIG.colors.low, label: `低风险 (${data[data.length-1].low})` }
  ];
  const legendHtml = legendItems.map((item, i) => `
    <rect x="${legendX}" y="${15 + i * 20}" width="12" height="12" rx="2" fill="${item.color}"/>
    <text x="${legendX + 18}" y="${25 + i * 20}" fill="${CHART_CONFIG.colors.text}" font-size="10">${item.label}</text>
  `).join('');
  
  // 总面积填充（按优先级叠放）
  const areas = `
    <defs>
      <linearGradient id="gradHigh" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${CHART_CONFIG.colors.high}" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="${CHART_CONFIG.colors.high}" stop-opacity="0.02"/>
      </linearGradient>
      <linearGradient id="gradMid" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${CHART_CONFIG.colors.mid}" stop-opacity="0.25"/>
        <stop offset="100%" stop-color="${CHART_CONFIG.colors.mid}" stop-opacity="0.02"/>
      </linearGradient>
      <linearGradient id="gradLow" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${CHART_CONFIG.colors.low}" stop-opacity="0.15"/>
        <stop offset="100%" stop-color="${CHART_CONFIG.colors.low}" stop-opacity="0.02"/>
      </linearGradient>
    </defs>
    <path d="${makeAreaPath('low')}" fill="url(#gradLow)"/>
    <path d="${makeAreaPath('mid')}" fill="url(#gradMid)"/>
    <path d="${makeAreaPath('high')}" fill="url(#gradHigh)"/>
  `;
  
  // 线条
  const lines = `
    <path d="${makePath('low')}" fill="none" stroke="${CHART_CONFIG.colors.low}" 
          stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
    <path d="${makePath('mid')}" fill="none" stroke="${CHART_CONFIG.colors.mid}" 
          stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
    <path d="${makePath('high')}" fill="none" stroke="${CHART_CONFIG.colors.high}" 
          stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
  `;
  
  // 轴
  const axes = `
    <line x1="${P.left}" y1="${P.top}" x2="${P.left}" y2="${H - P.bottom}" 
          stroke="${CHART_CONFIG.colors.axis}" stroke-width="1"/>
    <line x1="${P.left}" y1="${H - P.bottom}" x2="${W - P.right}" y2="${H - P.bottom}" 
          stroke="${CHART_CONFIG.colors.axis}" stroke-width="1"/>
  `;
  
  return `
    <svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" 
         style="width:100%;height:auto;">
      ${axes}
      ${gridLines}
      ${areas}
      ${lines}
      ${dataPoints}
      ${xLabels}
      ${legendHtml}
    </svg>
  `;
});

// 汇总卡片
const summaryCards = computed(() => {
  if (!trendData.value.length) return [];
  const last = trendData.value[trendData.value.length - 1];
  const prev = trendData.value.length > 1 ? trendData.value[trendData.value.length - 2] : last;
  
  return [
    { 
      label: '今日总计', 
      value: last.total, 
      change: last.total - prev.total,
      icon: '📊'
    },
    { 
      label: '高风险数', 
      value: last.high, 
      change: last.high - prev.high,
      icon: '🔴',
      color: '#f87171'
    },
    { 
      label: '中风险数', 
      value: last.mid, 
      change: last.mid - prev.mid,
      icon: '🟡',
      color: '#fbbf24'
    },
    { 
      label: '低风险数', 
      value: last.low, 
      change: last.low - prev.low,
      icon: '🟢',
      color: '#4ade80'
    }
  ];
});
</script>

<template>
  <div class="dash">
    <h2 class="title">运营概览</h2>
    <div class="sub">实时数据 · 每 15 秒自动刷新{{ updatedAt ? '（更新于 ' + updatedAt + '）' : '' }}</div>
    
    <div v-if="loading" class="loading">数据加载中…</div>
    <div v-else-if="stats.error" class="err">{{ stats.error }}</div>
    
    <div v-else class="grid">
      <div v-for="c in cards" :key="c.key" class="card" :style="{ '--accent': c.color }">
        <div class="icon">{{ c.icon }}</div>
        <div class="num">{{ stats[c.key] }}</div>
        <div class="lbl">{{ c.label }}</div>
      </div>
    </div>

    <!-- 风险趋势汇总卡片 -->
    <div class="summary-row">
      <div v-for="(s, i) in summaryCards" :key="i" class="summary-card" 
           :style="{ '--sum-color': s.color || '#22d3ee' }">
        <div class="sum-icon">{{ s.icon }}</div>
        <div class="sum-num">{{ s.value }}</div>
        <div class="sum-label">{{ s.label }}</div>
        <div v-if="s.change !== 0" class="sum-change" :class="s.change > 0 ? 'up' : 'down'">
          {{ s.change > 0 ? '↑' : '↓' }} {{ Math.abs(s.change) }}
        </div>
      </div>
    </div>

    <!-- 趋势图 -->
    <div class="panel">
      <div class="panel-head">
        <h3>📈 风险趋势</h3>
        <div class="range-btns">
          <button :class="{ on: trendDays === 7 }" @click="changeDays(7)">近 7 天</button>
          <button :class="{ on: trendDays === 30 }" @click="changeDays(30)">近 30 天</button>
        </div>
      </div>
      <div v-if="trendLoading" class="chart-state">趋势图加载中…</div>
      <div v-else-if="!trendData.length" class="chart-state">暂无足够数据</div>
      <div v-else class="chart-wrap" v-html="chartSvg"></div>
    </div>

    <div class="panel">
      <h3>🚀 快速操作</h3>
      <ul class="tips">
        <li>在「工单」页导入客户对话，系统自动抽取分类并生成知识条目</li>
        <li>在「知识库」页用自然语言检索标准话术</li>
        <li>在「质检」页检测会话的情绪与敏感词风险</li>
        <li>在「对话」页输入客户问题，获取智能建议回复</li>
        <li>右上角 🎨 可切换背景颜色 / 图片，打造你的专属工作台</li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.title { color: #e2e8f0; font-weight: 700; margin: 0 0 4px; }
.sub { color: #64748b; font-size: 12px; margin: 0 0 18px; }
.loading, .err, .chart-state { color: #94a3b8; padding: 20px; }
.err { color: #f87171; }

.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; }
.card {
  background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12);
  border-radius: 14px; padding: 22px; position: relative; overflow: hidden;
  backdrop-filter: blur(10px);
}
.card::before { content: ''; position: absolute; top: -40px; right: -40px; width: 110px; height: 110px; border-radius: 50%; background: var(--accent); opacity: .18; filter: blur(8px); }
.icon { font-size: 22px; }
.num { font-size: 34px; font-weight: 800; color: #f8fafc; margin: 6px 0 2px; }
.lbl { color: #94a3b8; font-size: 13px; }

/* 趋势汇总卡片 */
.summary-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-top: 16px;
}
.summary-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  position: relative;
  overflow: hidden;
}
.summary-card::before {
  content: '';
  position: absolute;
  left: 0; top: 0; bottom: 0;
  width: 3px;
  background: var(--sum-color, #22d3ee);
  border-radius: 3px 0 0 3px;
}
.sum-icon { font-size: 20px; }
.sum-num { font-size: 22px; font-weight: 700; color: #f1f5f9; }
.sum-label { font-size: 11px; color: #64748b; }
.sum-change {
  position: absolute;
  top: 8px;
  right: 10px;
  font-size: 11px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 4px;
}
.sum-change.up { color: #f87171; background: rgba(248,113,113,0.15); }
.sum-change.down { color: #4ade80; background: rgba(74,222,128,0.15); }

.panel { margin-top: 22px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 14px; padding: 20px; backdrop-filter: blur(10px); }
.panel h3 { margin: 0 0 12px; color: #e2e8f0; }
.tips { margin: 0; padding-left: 18px; color: #cbd5e1; line-height: 1.9; font-size: 14px; }
.panel-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.range-btns { display: flex; gap: 6px; }
.range-btns button {
  background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.14);
  color: #cbd5e1; padding: 5px 12px; border-radius: 8px; cursor: pointer; font-size: 12px;
}
.range-btns button.on { background: rgba(34,211,238,0.2); border-color: #22d3ee; color: #fff; }
.chart-wrap { overflow-x: auto; }
.chart-wrap svg { width: 100%; max-width: 700px; height: auto; display: block; margin: 0 auto; }
</style>
