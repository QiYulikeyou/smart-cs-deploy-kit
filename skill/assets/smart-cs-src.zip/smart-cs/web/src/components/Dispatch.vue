<script setup>
/**
 * 工单智能派发（v2）
 * 功能保持：智能派单（分类/紧急度/候选打分/确认派发/转人工）、客服技能画像 CRUD
 * 优化：SCard 双栏布局 + UI 组件库 + SModal 确认/编辑弹窗 + Toast 反馈
 */
import { ref, onMounted } from 'vue';
import {
  routeDispatch,
  listAgents,
  createAgent,
  updateAgent,
  deleteAgent,
  assignDispatch
} from '../api.js';
import { SCard, SButton, SInput, SSelect, SModal, SEmpty, SBadge } from './ui';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

// ---- 智能派单 ----
const content = ref('');
const urgency = ref(1);
const routing = ref(false);
const result = ref(null);

const URGENCY_OPTIONS = [
  { value: 1, label: '一般' },
  { value: 2, label: '较急' },
  { value: 3, label: '紧急' }
];
const URGENCY_TEXT = ['', '一般', '较急', '紧急'];

async function onRoute() {
  if (!content.value.trim()) {
    toastError('请输入工单内容');
    return;
  }
  routing.value = true;
  result.value = null;
  try {
    result.value = await routeDispatch(content.value, '', urgency.value);
  } catch (e) {
    toastError(e.message);
  } finally {
    routing.value = false;
  }
}

const assigningId = ref(null);

async function onAssign(agent_id) {
  assigningId.value = agent_id;
  try {
    await assignDispatch({
      content: content.value,
      category: result.value?.category || '',
      urgency: urgency.value,
      agent_id
    });
    result.value.assigned = true;
    result.value.assignee = agent_id;
    success(`已分配至客服组 #${agent_id}`);
    await loadAgents();
  } catch (e) {
    toastError(e.message);
  } finally {
    assigningId.value = null;
  }
}

// ---- 客服技能画像 ----
const agents = ref([]);
const loadingAgents = ref(false);
const agentErr = ref('');
const editing = ref(null); // {} 表示新增，agent 对象表示编辑
const form = ref({ agent_id: '', skill_tags: '', avg_satisfaction: 4.5, load_current: 0 });
const agentMsg = ref('');
const saving = ref(false);
const pendingDelete = ref(null);

async function loadAgents() {
  loadingAgents.value = true;
  agentErr.value = '';
  try {
    agents.value = await listAgents();
  } catch (e) {
    agentErr.value = e.message;
  } finally {
    loadingAgents.value = false;
  }
}

function openCreate() {
  editing.value = {};
  form.value = { agent_id: '', skill_tags: '', avg_satisfaction: 4.5, load_current: 0 };
  agentMsg.value = '';
}

function openEdit(a) {
  editing.value = a;
  form.value = {
    agent_id: a.agent_id,
    skill_tags: (a.skill_tags || []).join(', '),
    avg_satisfaction: a.avg_satisfaction,
    load_current: a.load_current
  };
  agentMsg.value = '';
}

async function saveAgent() {
  const id = Number(form.value.agent_id);
  if (!id) {
    agentMsg.value = '⚠ 客服组 ID 必填';
    return;
  }
  const tags = form.value.skill_tags
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  saving.value = true;
  agentMsg.value = '';
  try {
    if (editing.value && editing.value.agent_id) {
      await updateAgent(editing.value.agent_id, {
        skill_tags: tags,
        avg_satisfaction: Number(form.value.avg_satisfaction),
        load_current: Number(form.value.load_current)
      });
      success('客服组已更新');
    } else {
      await createAgent({
        agent_id: id,
        skill_tags: tags,
        avg_satisfaction: Number(form.value.avg_satisfaction)
      });
      success('客服组已新增');
    }
    editing.value = null;
    await loadAgents();
  } catch (e) {
    agentMsg.value = '⚠ ' + e.message;
  } finally {
    saving.value = false;
  }
}

function askDelete(a) {
  pendingDelete.value = a;
}

async function confirmDelete() {
  const a = pendingDelete.value;
  if (!a) return;
  try {
    await deleteAgent(a.agent_id);
    pendingDelete.value = null;
    success('客服组已删除');
    await loadAgents();
  } catch (e) {
    toastError(e.message);
  }
}

onMounted(loadAgents);
</script>

<template>
  <div class="dispatch">
    <div class="head">
      <div>
        <h2>工单智能派发</h2>
        <p class="sub">
          进线工单自动分类 → 结合客服技能画像（技能匹配 + 负载 + 紧急度）综合打分路由；无匹配技能或打分过低转人工评审
        </p>
      </div>
    </div>

    <div class="grid">
      <!-- 派单 -->
      <SCard icon="🚦" title="智能派单" subtitle="粘贴工单内容，系统给出分类与推荐客服组">
        <SInput
          v-model="content"
          type="textarea"
          :rows="4"
          placeholder="粘贴一段客户工单 / 对话内容，如：我要申请退款，商品有瑕疵…"
        />

        <div class="row">
          <label class="fld">
            <span class="fld__label">紧急度</span>
            <SSelect v-model="urgency" :options="URGENCY_OPTIONS" size="sm" />
          </label>
          <SButton variant="warn" icon="🚦" :loading="routing" @click="onRoute">
            {{ routing ? '分析中…' : '智能派发' }}
          </SButton>
        </div>

        <div v-if="result" class="result" :class="{ 'is-human': result.needsHuman }">
          <div class="r-line">
            <span>分类</span><b>{{ result.category }}</b>
            <span>紧急度</span><b>{{ URGENCY_TEXT[result.urgency] }}</b>
          </div>

          <p v-if="result.needsHuman" class="banner banner--danger">⚠ 转人工评审：{{ result.reason }}</p>
          <p v-else class="banner banner--success">✓ {{ result.reason }}</p>

          <div v-if="!result.needsHuman && !result.assigned" class="assign-actions">
            <SButton
              variant="success"
              size="sm"
              :loading="assigningId === result.recommended.agent_id"
              @click="onAssign(result.recommended.agent_id)"
            >✓ 确认派发</SButton>
            <span class="muted">将分配给推荐客服组</span>
          </div>
          <p v-if="result.assigned" class="banner banner--success">✓ 已派发至客服组 #{{ result.assignee }}</p>

          <div class="r-sub">候选客服组（按综合打分）</div>
          <table class="ct">
            <thead>
              <tr>
                <th>客服组</th>
                <th>技能标签</th>
                <th>匹配</th>
                <th>负载</th>
                <th>打分</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="c in result.candidates"
                :key="c.agent_id"
                :class="{ 'is-top': c === result.candidates[0] && !result.needsHuman }"
              >
                <td>#{{ c.agent_id }}</td>
                <td class="tags">{{ (c.skill_tags || []).join('、') || '—' }}</td>
                <td>{{ Math.round(c.skillMatch * 100) }}%</td>
                <td>{{ c.load_current }}/5</td>
                <td class="score">{{ c.score.toFixed(3) }}</td>
                <td>
                  <SButton
                    v-if="!result.assigned"
                    variant="ghost"
                    size="sm"
                    :loading="assigningId === c.agent_id"
                    @click="onAssign(c.agent_id)"
                  >派发</SButton>
                  <span v-else class="muted">—</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </SCard>

      <!-- 画像 -->
      <SCard icon="👥" title="客服技能画像" :subtitle="`共 ${agents.length} 个客服组`">
        <template #actions>
          <SButton variant="ghost" size="sm" icon="🔄" :loading="loadingAgents" @click="loadAgents">刷新</SButton>
          <SButton variant="primary" size="sm" icon="＋" @click="openCreate">新增客服组</SButton>
        </template>

        <SEmpty
          v-if="loadingAgents || agentErr"
          :loading="loadingAgents"
          :error="agentErr"
          loading-text="加载客服画像…"
          @retry="loadAgents"
        />
        <SEmpty
          v-else-if="!agents.length"
          icon="👥"
          title="暂无客服组"
          desc="点击右上角「新增客服组」创建第一个技能画像"
        />
        <div v-else class="agents">
          <article v-for="a in agents" :key="a.agent_id" class="agent">
            <header class="a-top">
              <b>#{{ a.agent_id }}</b>
              <span class="sat">★ {{ a.avg_satisfaction }}</span>
            </header>
            <div class="a-tags">
              <span v-for="t in a.skill_tags || []" :key="t" class="tag">{{ t }}</span>
              <span v-if="!(a.skill_tags || []).length" class="muted">未设置技能标签</span>
            </div>
            <div v-if="a.users && a.users.length" class="a-users">
              <span class="muted">负责人：</span>
              <span v-for="u in a.users" :key="u.id" class="user-chip">
                {{ u.display_name || u.username }}<small>({{ u.role }})</small>
              </span>
            </div>
            <div v-else class="a-users muted">暂无绑定用户</div>
            <div class="a-load">当前负载 {{ a.load_current }}/5</div>
            <footer class="a-ops">
              <SButton variant="ghost" size="sm" @click="openEdit(a)">编辑</SButton>
              <SButton variant="danger" size="sm" @click="askDelete(a)">删除</SButton>
            </footer>
          </article>
        </div>
      </SCard>
    </div>

    <!-- 画像编辑 / 新增 -->
    <SModal :model-value="!!editing" width="480px" hide-footer @update:model-value="editing = null">
      <template #title>{{ editing?.agent_id ? '编辑客服组' : '新增客服组' }}</template>
      <div v-if="editing" class="form">
        <label class="fld">
          <span class="fld__label">客服组 ID</span>
          <SInput v-model="form.agent_id" type="number" :disabled="!!editing.agent_id" placeholder="数字，如 5" />
        </label>
        <label class="fld">
          <span class="fld__label">技能标签（逗号分隔）</span>
          <SInput v-model="form.skill_tags" placeholder="售后-退款, 售后-物流" />
        </label>
        <div class="row2">
          <label class="fld">
            <span class="fld__label">满意度</span>
            <SInput v-model="form.avg_satisfaction" type="number" />
          </label>
          <label class="fld">
            <span class="fld__label">当前负载</span>
            <SInput v-model="form.load_current" type="number" />
          </label>
        </div>
        <p v-if="agentMsg" class="form-msg">{{ agentMsg }}</p>
        <div class="form-foot">
          <SButton variant="ghost" @click="editing = null">取消</SButton>
          <SButton variant="primary" :loading="saving" @click="saveAgent">保存</SButton>
        </div>
      </div>
    </SModal>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" title="确认删除" width="420px" @update:model-value="pendingDelete = null">
      <p v-if="pendingDelete">确认删除客服组 #{{ pendingDelete.agent_id }}？删除后不可恢复。</p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" @click="confirmDelete">确认删除</SButton>
      </template>
    </SModal>
  </div>
</template>

<style scoped>
.dispatch {
  max-width: 1120px;
}
.head {
  margin-bottom: var(--sp-4);
}
h2 {
  margin: 0 0 var(--sp-1);
  font-size: var(--fs-2xl);
  color: var(--text-1);
}
.sub {
  margin: 0;
  font-size: var(--fs-base);
  color: var(--text-3);
  line-height: 1.6;
}
.grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-4);
  align-items: start;
}

/* 派单表单 */
.fld {
  display: flex;
  flex-direction: column;
  gap: var(--sp-1);
}
.fld__label {
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.row {
  display: flex;
  gap: var(--sp-3);
  align-items: flex-end;
  margin-top: var(--sp-3);
  flex-wrap: wrap;
}

/* 派单结果 */
.result {
  margin-top: var(--sp-4);
  padding: var(--sp-3);
  border: 1px solid var(--success-border);
  border-radius: var(--r-lg);
  background: var(--success-soft);
}
.result.is-human {
  border-color: var(--danger-border);
  background: var(--danger-soft);
}
.r-line {
  display: flex;
  gap: var(--sp-3);
  align-items: center;
  flex-wrap: wrap;
  font-size: var(--fs-base);
  color: var(--text-3);
}
.r-line b {
  color: var(--text-1);
  font-weight: var(--fw-semibold);
}
.banner {
  margin: var(--sp-2) 0;
  font-size: var(--fs-base);
}
.banner--success {
  color: var(--success-text);
}
.banner--danger {
  color: var(--danger-text);
}
.assign-actions {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  margin: var(--sp-2) 0;
}
.muted {
  color: var(--text-3);
}
.r-sub {
  margin: var(--sp-3) 0 var(--sp-2);
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.ct {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--fs-sm);
}
.ct th {
  padding: var(--sp-2);
  text-align: left;
  font-weight: var(--fw-medium);
  color: var(--text-3);
  border-bottom: 1px solid var(--border);
}
.ct td {
  padding: var(--sp-2);
  color: var(--text-2);
  border-bottom: 1px solid var(--border-soft);
}
.ct tr.is-top {
  background: var(--warn-soft);
}
.tags {
  color: var(--warn-text);
}
.score {
  color: var(--success-text);
  font-weight: var(--fw-semibold);
  font-variant-numeric: tabular-nums;
}

/* 客服画像 */
.agents {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.agent {
  padding: var(--sp-3) var(--sp-4);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  background: var(--overlay-1);
}
.a-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.a-top b {
  font-size: var(--fs-md);
  color: var(--text-1);
}
.sat {
  font-size: var(--fs-sm);
  color: var(--warn-text);
}
.a-tags {
  display: flex;
  flex-wrap: wrap;
  gap: var(--sp-1);
  margin: var(--sp-2) 0;
}
.tag {
  padding: 1px var(--sp-2);
  border-radius: var(--r-sm);
  font-size: var(--fs-xs);
  background: var(--warn-soft);
  color: var(--warn-text);
}
.a-users {
  margin: var(--sp-1) 0;
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.user-chip {
  display: inline-block;
  margin-right: var(--sp-2);
  padding: 2px var(--sp-2);
  border-radius: var(--r-full);
  font-size: var(--fs-xs);
  background: var(--info-soft);
  color: var(--info);
}
.user-chip small {
  margin-left: var(--sp-1);
  font-size: var(--fs-2xs);
  color: var(--text-4);
}
.a-load {
  font-size: var(--fs-sm);
  color: var(--text-3);
}
.a-ops {
  display: flex;
  gap: var(--sp-2);
  margin-top: var(--sp-2);
}

/* 编辑表单 */
.form {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}
.row2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
}
.form-msg {
  margin: 0;
  font-size: var(--fs-sm);
  color: var(--danger-text);
}
.form-foot {
  display: flex;
  justify-content: flex-end;
  gap: var(--sp-3);
}

@media (max-width: 1080px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>
