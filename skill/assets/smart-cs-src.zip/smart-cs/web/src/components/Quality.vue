<script setup>
/**
 * 智能质检中心（质检看板）
 * v2 重构：把 KPI 卡片 / 风险趋势 / 来源分布 / 快速检测 / 预警列表 拆为 quality/ 下独立子组件，
 * 本文件只负责数据编排与生命周期，模板从 ~680 行精简到组合 5 个子组件。
 */
import { ref, onMounted, computed, watch } from 'vue';
import {
  detectQa, getAlerts, dismissAlert,
  getStats, getRiskTrend, getConversations
} from '../api.js';
import { QualityKpi, RiskTrend, SourceDist, QuickDetect, AlertList } from './quality';

// ============ 时间周期 ============
const period = ref('today'); // today | week
function periodRange() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const fmt = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} 00:00:00`;
  if (period.value === 'today') {
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    return { from: fmt(now), to: fmt(end) };
  }
  // 本周：从今天开始往前 6 天
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  return { from: fmt(start), to: fmt(end) };
}

// ============ 指标概览 ============
const stats = ref({ sessions: 0, prevSessions: 0, riskRate: '—', prevRiskRate: '—', unresolved: 0, avgRisk: 'low' });
const statsLoading = ref(false);

function sumSlice(arr, start, end) {
  return arr.slice(start, end).reduce((acc, d) => ({
    total: acc.total + (d.total || 0),
    high: acc.high + (d.high || 0),
    mid: acc.mid + (d.mid || 0),
    low: acc.low + (d.low || 0)
  }), { total: 0, high: 0, mid: 0, low: 0 });
}

async function refreshStats() {
  statsLoading.value = true;
  try {
    const s = await getStats();
    // 拉取对比周期: 今日 vs 昨日(2天); 本周 vs 上周(14天)
    const days = period.value === 'today' ? 2 : 14;
    const trend = await getRiskTrend(days);
    const data = trend.data || [];

    let current = { total: 0, high: 0, mid: 0, low: 0 };
    let previous = { total: 0, high: 0, mid: 0, low: 0 };

    if (period.value === 'today') {
      if (data.length >= 2) {
        current = data[data.length - 1];
        previous = data[data.length - 2];
      } else if (data.length === 1) {
        current = data[0];
      }
    } else {
      if (data.length >= 14) {
        current = sumSlice(data, 7, 14);
        previous = sumSlice(data, 0, 7);
      } else if (data.length >= 7) {
        current = sumSlice(data, data.length - 7, data.length);
      }
    }

    const riskRate = current.total > 0 ? ((current.high + current.mid) / current.total * 100).toFixed(1) + '%' : '—';
    const prevRiskRate = previous.total > 0 ? ((previous.high + previous.mid) / previous.total * 100).toFixed(1) + '%' : '—';

    stats.value = {
      sessions: current.total,
      prevSessions: previous.total,
      riskRate,
      prevRiskRate,
      unresolved: s.alerts,
      avgRisk: current.high > 0 ? 'high' : current.mid > 0 ? 'mid' : 'low'
    };
  } catch (e) {
    console.warn('[stats] fail', e);
  } finally {
    statsLoading.value = false;
  }
}

const safeRate = computed(() => {
  const v = parseFloat(stats.value.riskRate);
  return isNaN(v) ? 0 : v;
});
const prevSafeRate = computed(() => {
  const v = parseFloat(stats.value.prevRiskRate);
  return isNaN(v) ? 0 : v;
});
const qualityRate = computed(() => (100 - safeRate.value).toFixed(1) + '%');

function makeTrend(cur, prev, mode = 'pct') {
  if (prev === null || prev === undefined || Number.isNaN(prev)) return { text: '—', up: null };
  const diff = cur - prev;
  if (Math.abs(diff) < 0.05) return { text: '→ 持平', up: null };
  if (mode === 'pp') {
    const sign = diff > 0 ? '+' : '';
    return { text: `${sign}${diff.toFixed(1)}pp 较上期`, up: diff > 0 };
  }
  const raw = Math.abs(Math.round(diff / (prev || 1) * 100));
  if (raw >= 999) {
    const sign = diff > 0 ? '+' : '';
    const arrow = diff > 0 ? '↑' : '↓';
    return { text: `${arrow} ${sign}${Math.abs(diff)} 较上期`, up: diff > 0 };
  }
  if (diff > 0) return { text: `↑ ${raw}% 较上期`, up: true };
  return { text: `↓ ${raw}% 较上期`, up: false };
}
const sessionTrend = computed(() => makeTrend(stats.value.sessions, stats.value.prevSessions, 'pct'));
const riskTrend = computed(() => makeTrend(safeRate.value, prevSafeRate.value, 'pp'));
const qualityTrend = computed(() => {
  const prev = prevSafeRate.value;
  if (prev === null || prev === undefined || Number.isNaN(prev)) return { text: '—', up: null };
  const diff = -(safeRate.value - prev); // 质量率变化与风险率相反
  if (Math.abs(diff) < 0.05) return { text: '→ 持平', up: null };
  const sign = diff > 0 ? '+' : '';
  return { text: `${sign}${diff.toFixed(1)}pp 较上期`, up: diff > 0 };
});

// ============ 风险趋势图 ============
const trendDays = ref(7);
const trendData = ref([]);
const trendLoading = ref(false);

async function loadTrend() {
  trendLoading.value = true;
  try {
    const r = await getRiskTrend(trendDays.value);
    trendData.value = (r.data || []).map(d => ({
      date: d.date || '',
      total: d.total || 0,
      high: d.high || 0,
      mid: d.mid || 0,
      low: d.low || 0
    }));
  } catch (e) {
    console.warn('[trend] fail', e);
  } finally {
    trendLoading.value = false;
  }
}

// ============ 会话来源分布 ============
const sourceDist = ref([]);
const sourceLoading = ref(false);

const SOURCE_META = {
  local:  { label: '本地知识库', color: '#3b82f6', grad: 'linear-gradient(90deg, #3b82f6, #06b6d4)' },
  script: { label: '话术库',      color: '#06b6d4', grad: 'linear-gradient(90deg, #06b6d4, #22d3ee)' },
  llm:    { label: 'AI生成',      color: '#8b5cf6', grad: 'linear-gradient(90deg, #8b5cf6, #a78bfa)' },
  feishu: { label: '飞书同步',    color: '#f59e0b', grad: 'linear-gradient(90deg, #f59e0b, #fbbf24)' },
  unknown:{ label: '其他',        color: '#64748b', grad: 'linear-gradient(90deg, #64748b, #94a3b8)' }
};

async function loadSourceDist() {
  sourceLoading.value = true;
  try {
    const range = periodRange();
    const r = await getConversations(100, 0, { from: range.from, to: range.to });
    const map = {};
    (r.items || []).forEach(item => {
      const src = item.source || 'unknown';
      map[src] = (map[src] || 0) + 1;
    });
    sourceDist.value = Object.entries(map)
      .map(([k, v]) => ({ source: k, count: v }))
      .sort((a, b) => b.count - a.count);
  } catch (e) {
    console.warn('[source-dist] fail', e);
    sourceDist.value = [];
  } finally {
    sourceLoading.value = false;
  }
}

const sourceTotal = computed(() => sourceDist.value.reduce((a, b) => a + b.count, 0));
const sourceDistDisplay = computed(() => {
  const total = sourceTotal.value || 1;
  return sourceDist.value.map(s => {
    const meta = SOURCE_META[s.source] || SOURCE_META.unknown;
    return { ...s, ...meta, pct: Math.round(s.count / total * 100) };
  });
});

// ============ 预警列表 ============
const alerts = ref([]);
const alertsLoading = ref(false);
const alertsFilter = ref('all');
const searchQuery = ref('');

async function refreshAlerts() {
  alertsLoading.value = true;
  try {
    const list = await getAlerts();
    alerts.value = list.map(a => ({
      ...a,
      user_text_short: (a.user_text || '').slice(0, 100),
      hits_text: parseHits(a.sensitive_hits),
      action_hint: getActionHint(a)
    }));
  } catch (e) {
    alerts.value = [];
  } finally {
    alertsLoading.value = false;
  }
}

const filteredAlerts = computed(() => {
  let list = alerts.value;
  if (alertsFilter.value !== 'all') {
    list = list.filter(a => (a.risk_level || '').toLowerCase() === alertsFilter.value);
  }
  if (searchQuery.value.trim()) {
    const q = searchQuery.value.toLowerCase();
    list = list.filter(a => (a.user_text || '').toLowerCase().includes(q));
  }
  return list;
});

const alertCounts = computed(() => ({
  all: alerts.value.length,
  high: alerts.value.filter(a => a.risk_level === 'high').length,
  mid: alerts.value.filter(a => a.risk_level === 'mid').length,
  low: alerts.value.filter(a => a.risk_level === 'low').length
}));

function parseHits(json) {
  if (!json) return '';
  try {
    const arr = JSON.parse(json);
    if (!Array.isArray(arr) || !arr.length) return '';
    return arr.map(h => h.word + (h.note ? `(${h.note})` : '')).join('、');
  } catch { return ''; }
}

function getActionHint(a) {
  if (!a.risk_level) return '—';
  if (['high', '紧急'].includes(a.risk_level)) return '立即介入处理';
  if (['mid', '中风险'].includes(a.risk_level)) return '安排回访跟进';
  return '记录备查';
}

async function onDismiss(a) {
  try {
    await dismissAlert(a.id);
    alerts.value = alerts.value.filter(x => x.id !== a.id);
  } catch (e) { /* silent */ }
}

// ============ 快速检测 ============
const detectText = ref('');
const detectResult = ref(null);
const detectLoading = ref(false);
const detectErr = ref('');

async function onDetect() {
  if (!detectText.value.trim()) { detectErr.value = '请输入检测内容'; return; }
  detectLoading.value = true; detectErr.value = ''; detectResult.value = null;
  try { detectResult.value = await detectQa(detectText.value); }
  catch (e) { detectErr.value = e.message; }
  finally { detectLoading.value = false; }
}

// ============ 子组件事件桥接 ============
function handleAlerts() { refreshAlerts(); }
function onTrendDays(d) { trendDays.value = d; loadTrend(); }
function resetDetect() { detectText.value = ''; detectResult.value = null; detectErr.value = ''; }

// ============ 初始化与联动 ============
watch(period, () => {
  refreshStats();
  loadSourceDist();
});

onMounted(() => {
  refreshStats();
  loadTrend();
  loadSourceDist();
  refreshAlerts();
  setInterval(() => { refreshStats(); loadTrend(); loadSourceDist(); refreshAlerts(); }, 60000);
});
</script>

<template>
  <div class="qc">
    <!-- 顶部导航栏 -->
    <div class="qc-header">
      <div class="qc-title">
        <span class="qc-icon">🛡</span>
        <div>
          <h2>智能质检中心</h2>
          <span class="qc-sub">会话质量监控 · 风险预警 · 持续改进</span>
        </div>
      </div>
      <div class="qc-period" role="tablist">
        <button :class="{ on: period === 'today' }" @click="period = 'today'" role="tab" :aria-selected="period === 'today'">今日</button>
        <button :class="{ on: period === 'week' }" @click="period = 'week'" role="tab" :aria-selected="period === 'week'">本周</button>
      </div>
    </div>

    <!-- 核心指标卡片 -->
    <QualityKpi
      :stats="stats"
      :quality-rate="qualityRate"
      :session-trend="sessionTrend"
      :risk-trend="riskTrend"
      :quality-trend="qualityTrend"
      :loading="statsLoading"
      @handle-alerts="handleAlerts"
    />

    <!-- 趋势图 + 来源分布 -->
    <div class="charts-row">
      <RiskTrend
        :data="trendData"
        :loading="trendLoading"
        :days="trendDays"
        @update:days="onTrendDays"
        @change-days="onTrendDays"
      />
      <SourceDist
        :items="sourceDistDisplay"
        :total="sourceTotal"
        :loading="sourceLoading"
      />
    </div>

    <!-- 快速检测 -->
    <QuickDetect
      v-model="detectText"
      :result="detectResult"
      :loading="detectLoading"
      :error="detectErr"
      @detect="onDetect"
      @reset="resetDetect"
    />

    <!-- 预警列表 -->
    <AlertList
      :alerts="filteredAlerts"
      :counts="alertCounts"
      :filter="alertsFilter"
      :search="searchQuery"
      :loading="alertsLoading"
      @update:filter="alertsFilter = $event"
      @update:search="searchQuery = $event"
      @refresh="refreshAlerts"
      @dismiss="onDismiss"
    />
  </div>
</template>

<style scoped>
.qc {
  max-width: 1200px;
  margin: 0 auto;
  padding-bottom: var(--sp-8);
}

/* 顶部导航 */
.qc-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--sp-6);
  gap: var(--sp-4);
  flex-wrap: wrap;
}
.qc-title {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
}
.qc-icon {
  font-size: 34px;
  width: 56px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--r-xl);
  background: var(--brand-soft);
  border: 1px solid var(--border);
}
.qc-title h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: var(--text-1);
  letter-spacing: -0.3px;
}
.qc-sub {
  color: var(--text-3);
  font-size: var(--fs-sm);
  display: block;
  margin-top: 2px;
}
.qc-period {
  display: flex;
  gap: var(--sp-1);
  background: var(--overlay-2);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: var(--sp-1);
}
.qc-period button {
  background: none;
  border: none;
  color: var(--text-3);
  padding: var(--sp-2) var(--sp-5);
  border-radius: var(--r-md);
  cursor: pointer;
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
  transition: var(--dur-fast) var(--ease);
}
.qc-period button:hover { color: var(--text-1); }
.qc-period button.on {
  background: var(--brand-grad);
  color: var(--brand-text);
  box-shadow: var(--shadow-sm);
}

/* 趋势 + 来源 两栏布局 */
.charts-row {
  display: grid;
  grid-template-columns: 1.6fr 1fr;
  gap: var(--sp-4);
  margin-bottom: var(--sp-4);
  align-items: start;
}
@media (max-width: 1080px) {
  .charts-row { grid-template-columns: 1fr; }
}
</style>
