<script setup>
import { ref, computed, onMounted, nextTick } from 'vue';
import { chat, getLLMInfo, detectQa, getUser, handoffQa, submitFeedback } from '../api.js';
import {
  ChatHeader,
  ChatMessage,
  ChatActionBar,
  ChatDraftBar,
  ChatConfigPanel,
  ChatLibDrawer
} from './chat/index.js';

const messages = ref([
  { role: 'bot', text: '您好，我是智能客服助手。请输入客户的问题，我会：① 实时质检（敏感词 / 情绪 / 风险）→ ② 检索知识库 → ③ 给出建议回复。' }
]);
const input = ref('');
const loading = ref(false);
const bodyRef = ref(null);
const user = ref(getUser());

const llmInfo = ref({ mode: 'pending', llm_model: '', embed_model: '' });

// 记录最近一轮：用户消息对象 + 对应 bot 消息对象 + 质检结果，便于「转人工/复核/反馈」
const lastTurn = ref(null);
const handing = ref(false);
const handoffMsg = ref('');
// 每轮 bot 消息的反馈状态：'correct' | 'incorrect' | null
const feedbackState = ref({}); // { index: 'correct'|'incorrect' }

// 检索来源（话术库 / 知识库 / 两者），同时驱动自动回复与检索抽屉
const retrieveMode = ref('knowledge');

// 坐席回复草稿（从话术库插入）+ 配置/检索抽屉开关
const draft = ref('');
const libOpen = ref(false);
const cfgOpen = ref(false);

async function scrollBottom() {
  await nextTick();
  if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight;
}

// 把历史里非命中卡片、非质检附属消息整理成对话历史（供 chat 的上下文）
function buildHistory() {
  return messages.value
    .filter((m) => !m.hits && !m.detectOnly)
    .map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', text: m.text }));
}

async function send() {
  const text = input.value.trim();
  if (!text || loading.value) return;
  loading.value = true;
  input.value = '';

  // 1) 先把客户问题作为「用户消息」落屏（带上质检占位，随后回填）
  const userMsg = { role: 'user', text, detect: null };
  messages.value.push(userMsg);
  scrollBottom();

  // 2) 并行：质检检测 + 知识检索/回复生成（两条链路互不阻塞）
  const detectP = detectQa(text).catch((e) => ({ error: e.message }));
  const chatP = chat(text, buildHistory(), retrieveMode.value).catch((e) => ({ error: e.message }));

  const [detectRes, chatRes] = await Promise.all([detectP, chatP]);

  // 2.1 回填质检结果到客户气泡（含写库返回的 id）
  if (detectRes && !detectRes.error) {
    userMsg.detect = detectRes;
  } else if (detectRes && detectRes.error) {
    userMsg.detect = { emotion: 'neutral', risk_level: 'low', needs_review: 0, sensitive_hits: [], error: detectRes.error };
  }

  // 2.2 追加建议回复（含命中来源、相似度与引用）
  let botMsg = null;
  if (chatRes && chatRes.error) {
    botMsg = { role: 'bot', text: '⚠ 对话生成失败：' + chatRes.error, source: 'error' };
    messages.value.push(botMsg);
  } else {
    const r = chatRes || {};
    botMsg = {
      role: 'bot',
      text: r.reply || '（未生成回复）',
      hits: r.hits || [],
      cited: r.cited || [],
      source: r.source || 'unknown',
      kb_source: r.kb_source || '',
      threshold: r.threshold || 0.6,
      conversation_id: detectRes && detectRes.id,
      session_id: r.session_id || null
    };
    messages.value.push(botMsg);
  }

  // 记最近一轮，供「转人工/复核」使用
  lastTurn.value = { userMsg, botMsg, detect: userMsg.detect };

  loading.value = false;
  scrollBottom();
}

// 反馈标记
async function markFeedback(index, type) {
  const m = messages.value[index];
  if (!m || m.role !== 'bot') return;
  const convId = m.conversation_id || null;
  const sessionId = m.session_id || null;
  const agentId = user.value?.userId || null;
  try {
    await submitFeedback({
      conversation_id: convId,
      session_id: sessionId,
      message: m.text,
      is_correct: type === 'correct' ? 1 : 0,
      agent_id: agentId
    });
    feedbackState.value = { ...feedbackState.value, [index]: type };
  } catch (e) {
    console.error('反馈提交失败:', e);
  }
}

// 一键转人工 / 转复核：把当前轮次推入待复核队列
async function handoff() {
  if (!lastTurn.value || handing.value) return;
  const t = lastTurn.value;
  const custText = t.userMsg.text;
  const reply = t.botMsg && t.botMsg.text ? t.botMsg.text : '';
  handing.value = true;
  handoffMsg.value = '';
  try {
    const r = await handoffQa({
      text: custText,
      detect: t.detect || null,
      reply,
      conversation_id: t.botMsg?.conversation_id ?? null
    });
    handoffMsg.value = '✅ ' + (r.message || '已转入待复核队列') + '（编号 #' + r.id + '）';
  } catch (e) {
    handoffMsg.value = '⚠ ' + (e.message || '转交失败');
  } finally {
    handing.value = false;
    setTimeout(() => (handoffMsg.value = ''), 4000);
  }
}

// 话术库「插入」：把内容追加到坐席草稿（由抽屉 emit 触发）
function insertTurn(content) {
  if (!content) return;
  draft.value = draft.value ? draft.value + '\n' + content : content;
}

function refreshInfo() {
  getLLMInfo().then((i) => (llmInfo.value = i)).catch(() => {});
}

onMounted(async () => {
  try {
    llmInfo.value = await getLLMInfo();
  } catch {}
});
</script>

<template>
  <div class="chat">
    <ChatHeader
      :llm-info="llmInfo"
      v-model:retrieve-mode="retrieveMode"
      @open-cfg="cfgOpen = true"
      @open-lib="libOpen = true"
    />

    <div class="body" ref="bodyRef">
      <ChatMessage
        v-for="(m, i) in messages"
        :key="i"
        :message="m"
        :index="i"
        :feedback="feedbackState[i]"
        :llm-model="llmInfo.llm_model"
        @feedback="markFeedback"
      />
      <div v-if="loading" class="msg bot"><div class="bubble bot typing">检索知识 + 生成回复中…</div></div>
    </div>

    <ChatActionBar :last-turn="lastTurn" :handing="handing" :handoff-msg="handoffMsg" @handoff="handoff" />

    <ChatDraftBar v-model="draft" :lib-open="libOpen" />

    <div class="inputbar">
      <input v-model="input" placeholder="输入客户问题，回车发送（自动质检 + 按所选来源检索）" @keyup.enter="send" :disabled="loading" />
      <button @click="send" :disabled="loading">发送</button>
    </div>

    <ChatConfigPanel v-model:open="cfgOpen" :llm-info="llmInfo" @applied="refreshInfo" />

    <ChatLibDrawer v-model:open="libOpen" v-model:retrieve-mode="retrieveMode" @insert="insertTurn" />
  </div>
</template>

<style scoped>
.chat { position: relative; display: flex; flex-direction: column; height: calc(100vh - 200px); min-height: 460px; max-width: 820px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.12); border-radius: 16px; overflow: hidden; backdrop-filter: blur(10px); }
.body { flex: 1; overflow-y: auto; padding: 18px; display: flex; flex-direction: column; gap: 12px; }
.inputbar { display: flex; gap: .10px; padding: 14px; border-top: 1px solid rgba(255,255,255,0.1); }
.inputbar input { flex: 1; padding: 11px 14px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.18); background: rgba(15,23,42,0.6); color: #f1f5f9; outline: none; }
.inputbar input:focus { border-color: #22d3ee; }
.inputbar button { background: linear-gradient(135deg, #06b6d4, #3b82f6); color: #fff; border: 0; padding: 0 22px; border-radius: 10px; cursor: pointer; font-weight: 600; }
.inputbar button:disabled { opacity: .6; }
</style>
