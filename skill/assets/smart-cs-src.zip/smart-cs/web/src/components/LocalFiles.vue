<!--
  本地文件夹知识源：webkitdirectory 选文件夹 → 读文本类文件 → 入库为 source_type='file' 的知识条目。
  支持勾选、导入后直接发布开关；已入库的 file 条目用统一 KnowledgeCard 管理（发布/撤下/删除）。
  v2：SCard 容器 + UI 组件库，原生 confirm 改为确认弹窗
-->
<script setup>
import { ref, onMounted } from 'vue';
import { listKnowledge, deleteKnowledge, publishKnowledge, unpublishKnowledge, ingestFiles } from '../api.js';
import KnowledgeCard from './KnowledgeCard.vue';
import SCard from './ui/SCard.vue';
import SButton from './ui/SButton.vue';
import SInput from './ui/SInput.vue';
import SModal from './ui/SModal.vue';
import SEmpty from './ui/SEmpty.vue';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

// 允许的文本类扩展名（pdf/docx/图片等非纯文本跳过，避免灌入乱码）
const TEXT_EXT = ['md', 'markdown', 'txt', 'text', 'csv', 'json', 'log', 'yaml', 'yml'];
const isText = (name) => {
  const m = name.toLowerCase().match(/\.([^.]+)$/);
  return m ? TEXT_EXT.includes(m[1]) : false; // 无扩展名也按文本处理
};

const folderInput = ref(null);
const pickedFiles = ref([]); // { name, content, size, checked }
const baseName = ref('本地文件');
const publish = ref(false); // 导入后直接发布（否则 draft，需审核）
const importing = ref(false);
const importMsg = ref('');

const knowledge = ref([]);
const total = ref(0);
const loading = ref(false);
const err = ref('');

const pendingDelete = ref(null);

function checkedFiles() {
  return pickedFiles.value.filter((p) => p.checked);
}

async function onPick(e) {
  const list = Array.from(e.target.files || []);
  if (!list.length) return;
  const picked = [];
  let skippedExt = 0;
  let topFolder = '';
  for (const f of list) {
    const rel = f.webkitRelativePath || f.name;
    if (!topFolder) topFolder = rel.split('/')[0];
    if (!isText(rel)) {
      skippedExt++;
      continue;
    }
    try {
      const content = await f.text();
      picked.push({ name: rel, content, size: f.size, checked: true });
    } catch {
      skippedExt++;
    }
  }
  // 去重（同名保留首个）
  const seen = new Set();
  pickedFiles.value = picked.filter((p) => (seen.has(p.name) ? false : (seen.add(p.name), true)));
  if (topFolder) baseName.value = topFolder;
  importMsg.value = pickedFiles.value.length
    ? `已读取 ${pickedFiles.value.length} 个文本文件` + (skippedExt ? `（跳过 ${skippedExt} 个非文本文件）` : '')
    : skippedExt
      ? `文件夹里没有支持的文本文件，已跳过 ${skippedExt} 个`
      : '未选择文件';
}

function selectAll(v) {
  pickedFiles.value.forEach((p) => (p.checked = v));
}

async function doImport() {
  const files = checkedFiles().map((p) => ({ name: p.name, content: p.content }));
  if (!files.length) {
    importMsg.value = '请先勾选要导入的文件';
    return;
  }
  importing.value = true;
  importMsg.value = `正在导入 ${files.length} 个文件…`;
  try {
    const r = await ingestFiles(files, baseName.value.trim() || '本地文件', publish.value);
    importMsg.value =
      `✅ 导入完成：从 ${r.docs ?? files.length} 个文件提炼入库 ${r.inserted} 条 FAQ` +
      (r.skipped ? `，跳过 ${r.skipped} 个` : '');
    pickedFiles.value = [];
    if (folderInput.value) folderInput.value.value = '';
    success(importMsg.value);
    await loadKnowledge();
  } catch (e) {
    importMsg.value = '❌ 导入失败：' + e.message;
    toastError(importMsg.value);
  } finally {
    importing.value = false;
  }
}

async function loadKnowledge() {
  loading.value = true;
  err.value = '';
  try {
    const r = await listKnowledge(200, 0, 'file', '', '');
    knowledge.value = r.rows || [];
    total.value = r.total || 0;
  } catch (e) {
    err.value = e.message;
  } finally {
    loading.value = false;
  }
}

async function onPublish(item) {
  try {
    await publishKnowledge(item.id);
    success('已发布');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function onUnpublish(item) {
  try {
    await unpublishKnowledge(item.id);
    success('已撤下');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function doDelete() {
  const item = pendingDelete.value;
  if (!item) return;
  try {
    await deleteKnowledge(item.id);
    success('已删除');
    pendingDelete.value = null;
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

onMounted(loadKnowledge);
</script>

<template>
  <SCard icon="📁" title="知识条目 · 本地文件" subtitle="从本地文件夹摄取文本类文件，自动提炼 FAQ 入库">
    <p class="hint">
      选择本地文件夹，把里面的 <b>.md / .txt / .csv / .json / .log / .yaml</b> 等文本文件一键摄取为知识条目。
      每个文件会用大模型<b>自动提炼出多条 FAQ 问答</b>入库（问题贴合客户提问、答案可直接发给客户）；
      模型不可用时退化为「整篇文档 = 1 条」。PDF / Word / 图片等非文本文件会被跳过。
    </p>

    <div class="picker">
      <label class="pick-btn">
        📁 选择文件夹
        <input
          ref="folderInput"
          type="file"
          webkitdirectory
          multiple
          accept=".md,.markdown,.txt,.text,.csv,.json,.log,.yaml,.yml"
          @change="onPick"
        />
      </label>

      <div class="opts">
        <label class="opt">
          库名
          <SInput v-model="baseName" size="sm" placeholder="本地文件" class="base-input" />
        </label>
        <label class="opt chk">
          <input v-model="publish" type="checkbox" />
          导入后直接发布（否则为草稿，需审核）
        </label>
      </div>
    </div>

    <div v-if="importMsg" class="msg">{{ importMsg }}</div>

    <!-- 待导入文件列表 -->
    <div v-if="pickedFiles.length" class="picked">
      <div class="picked-head">
        <span>待导入（{{ checkedFiles().length }}/{{ pickedFiles.length }} 已勾选）</span>
        <SButton size="sm" variant="link" @click="selectAll(true)">全选</SButton>
        <SButton size="sm" variant="link" @click="selectAll(false)">全不选</SButton>
      </div>

      <div class="picked-list">
        <label v-for="p in pickedFiles" :key="p.name" class="prow">
          <input v-model="p.checked" type="checkbox" class="cbx" />
          <span class="pname" :title="p.name">{{ p.name }}</span>
          <span class="psize">{{ (p.size / 1024).toFixed(1) }} KB</span>
        </label>
      </div>

      <SButton
        variant="primary"
        :loading="importing"
        :disabled="!checkedFiles().length"
        @click="doImport"
      >
        {{ importing ? '导入中…' : '导入 ' + checkedFiles().length + ' 个文件' }}
      </SButton>
    </div>

    <!-- 已入库条目 -->
    <div class="divider"><span>已入库的本地文件条目（共 {{ total }} 条）</span></div>

    <SEmpty v-if="err" error :desc="err" @retry="loadKnowledge" />

    <SEmpty
      v-else-if="!loading && !knowledge.length"
      icon="📁"
      title="暂无本地文件知识条目"
      desc="先选个文件夹导入吧"
    />

    <SEmpty v-else-if="loading" loading />

    <div v-else class="cards">
      <KnowledgeCard
        v-for="it in knowledge"
        :key="it.id"
        :item="it"
        @publish="onPublish"
        @unpublish="onUnpublish"
        @delete="(i) => (pendingDelete = i)"
      />
    </div>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" @update:model-value="pendingDelete = null" title="确认删除" width="420px">
      <p class="confirm-text">
        确认删除知识条目「<strong>{{ pendingDelete?.question }}</strong>」？此操作不可撤销。
      </p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" @click="doDelete">删除</SButton>
      </template>
    </SModal>
  </SCard>
</template>

<style scoped>
.hint {
  font-size: var(--fs-sm);
  color: var(--text-3);
  line-height: 1.7;
  background: var(--overlay-1);
  border: 1px solid var(--border);
  border-radius: var(--r-lg);
  padding: var(--sp-3) var(--sp-4);
  margin: 0 0 var(--sp-4);
}

.hint b {
  color: var(--brand-soft);
}

.picker {
  display: flex;
  gap: var(--sp-4);
  align-items: flex-end;
  flex-wrap: wrap;
  margin-bottom: var(--sp-4);
}

.pick-btn {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
  background: linear-gradient(135deg, var(--brand-strong), var(--brand-deep));
  color: #fff;
  padding: 9px var(--sp-4);
  border-radius: var(--r-lg);
  cursor: pointer;
  font-weight: var(--fw-semibold);
  font-size: var(--fs-base);
  box-shadow: 0 2px 10px var(--brand-glow);
}
.pick-btn:hover {
  filter: brightness(1.1);
}
.pick-btn input {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
}

.opts {
  display: flex;
  gap: var(--sp-5);
  align-items: center;
  flex-wrap: wrap;
}

.opt {
  font-size: var(--fs-sm);
  color: var(--text-2);
  display: inline-flex;
  align-items: center;
  gap: var(--sp-2);
}

.opt.chk {
  cursor: pointer;
}

.base-input {
  width: 140px;
}

.msg {
  font-size: var(--fs-sm);
  color: var(--brand-soft);
  margin-bottom: var(--sp-3);
  background: var(--brand-glow);
  border: 1px solid var(--brand-ring);
  border-radius: var(--r-md);
  padding: 7px var(--sp-3);
  word-break: break-word;
}

.picked {
  background: var(--overlay-0);
  border: 1px solid var(--border);
  border-radius: var(--r-xl);
  padding: var(--sp-3) var(--sp-4);
  margin-bottom: var(--sp-4);
}

.picked-head {
  font-size: var(--fs-sm);
  color: var(--text-2);
  margin-bottom: var(--sp-2);
  display: flex;
  gap: var(--sp-3);
  align-items: center;
}

.picked-list {
  max-height: 220px;
  overflow: auto;
  display: flex;
  flex-direction: column;
  gap: var(--sp-1);
  margin-bottom: var(--sp-3);
}

.prow {
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  font-size: var(--fs-sm);
  color: var(--text-2);
  padding: var(--sp-1) var(--sp-2);
  border-radius: var(--r-sm);
  cursor: pointer;
}
.prow:hover {
  background: var(--overlay-2);
}

.cbx {
  accent-color: var(--brand);
  cursor: pointer;
  flex-shrink: 0;
}

.pname {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.psize {
  color: var(--text-4);
  font-size: var(--fs-xs);
  flex-shrink: 0;
}

.divider {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  margin: var(--sp-5) 0 var(--sp-3);
  color: var(--text-4);
  font-size: var(--fs-sm);
}
.divider::before,
.divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

.cards {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}

.confirm-text {
  margin: 0;
  line-height: 1.7;
  color: var(--text-2);
}
.confirm-text strong {
  color: var(--text-1);
  word-break: break-word;
}
</style>
