<!--
  工单回流：导入 JSON 工单，自动生成 source_type='ticket' 的知识条目，并用统一卡片展示
  v2：SCard 容器 + SButton/SInput/SSelect/SModal/SEmpty，原生 confirm 改为确认弹窗
-->
<script setup>
import { ref, onMounted } from 'vue';
import {
  importTickets,
  listKnowledge,
  updateKnowledge,
  deleteKnowledge,
  publishKnowledge,
  unpublishKnowledge
} from '../api.js';
import KnowledgeCard from './KnowledgeCard.vue';
import SCard from './ui/SCard.vue';
import SButton from './ui/SButton.vue';
import SInput from './ui/SInput.vue';
import SSelect from './ui/SSelect.vue';
import SModal from './ui/SModal.vue';
import SEmpty from './ui/SEmpty.vue';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const knowledge = ref([]);
const total = ref(0);
const statusFilter = ref('');
const loading = ref(false);
const err = ref('');

/* 导入区 */
const showImport = ref(false);
const importText = ref(`[
  { "content": "我的订单还没发货，急用！", "category": "售后-物流", "urgency": 3, "customer_level": "vip" },
  { "content": "想问问这款耳机支持降噪吗？", "category": "售前咨询", "urgency": 1, "customer_level": "normal" }
]`);
const importMsg = ref('');
const importing = ref(false);

/* 编辑弹窗 */
const editing = ref(null);
const form = ref({ question: '', solution: '', category: '其他', product_module: '', urgency: 1 });
const saving = ref(false);

/* 删除确认 */
const pendingDelete = ref(null);
const deleting = ref(false);

const STATUS_OPTIONS = [
  { value: '', label: '全部状态' },
  { value: 'published', label: '已发布' },
  { value: 'draft', label: '草稿' }
];

const URGENCY_OPTIONS = [
  { value: 1, label: '一般' },
  { value: 2, label: '较急' },
  { value: 3, label: '紧急' }
];

async function loadKnowledge() {
  loading.value = true;
  err.value = '';
  try {
    const r = await listKnowledge(200, 0, 'ticket', '', statusFilter.value);
    knowledge.value = r.rows || [];
    total.value = r.total || 0;
  } catch (e) {
    err.value = e.message;
  } finally {
    loading.value = false;
  }
}

async function onPublish(item) {
  try {
    await publishKnowledge(item.id);
    success('已发布');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function onUnpublish(item) {
  try {
    await unpublishKnowledge(item.id);
    success('已撤下');
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  }
}

async function onImport() {
  importMsg.value = '';
  importing.value = true;
  try {
    const arr = JSON.parse(importText.value);
    const r = await importTickets(arr);
    importMsg.value = `✓ 已导入 ${r.imported} 条工单（自动生成知识条目）${r.skipped ? '，跳过重复 ' + r.skipped : ''}`;
    showImport.value = false;
    success(importMsg.value);
    await loadKnowledge();
  } catch (e) {
    importMsg.value = '失败：' + e.message;
    toastError(importMsg.value);
  } finally {
    importing.value = false;
  }
}

function openEdit(item) {
  editing.value = item;
  form.value = {
    question: item.question || '',
    solution: item.solution || '',
    category: item.category || '其他',
    product_module: item.product_module || '',
    urgency: item.urgency || 1
  };
}

async function save() {
  if (!form.value.question.trim()) {
    toastError('问题不能为空');
    return;
  }
  saving.value = true;
  try {
    if (editing.value && editing.value.id) {
      await updateKnowledge(editing.value.id, form.value);
      success('已更新');
    }
    editing.value = null;
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  } finally {
    saving.value = false;
  }
}

function confirmDelete(item) {
  pendingDelete.value = item;
}

async function doDelete() {
  const item = pendingDelete.value;
  if (!item) return;
  deleting.value = true;
  try {
    await deleteKnowledge(item.id);
    success('已删除');
    pendingDelete.value = null;
    await loadKnowledge();
  } catch (e) {
    toastError(e.message);
  } finally {
    deleting.value = false;
  }
}

onMounted(loadKnowledge);
</script>

<template>
  <SCard
    icon="🎫"
    title="知识条目 · 工单回流"
    :subtitle="`导入工单自动生成标准知识条目（source_type=ticket）· 共 ${total} 条`"
  >
    <template #actions>
      <SButton variant="primary" icon="＋" @click="showImport = !showImport">
        {{ showImport ? '收起导入' : '导入工单' }}
      </SButton>
    </template>

    <div class="toolbar">
      <SSelect
        v-model="statusFilter"
        :options="STATUS_OPTIONS"
        size="sm"
        @change="loadKnowledge"
      />
      <SButton v-if="statusFilter" size="sm" variant="link" @click="statusFilter = ''; loadKnowledge()">
        清除筛选
      </SButton>
    </div>

    <!-- 导入区 -->
    <Transition name="fold">
      <div v-if="showImport" class="import-box">
        <p class="tip">粘贴 JSON 数组（content / category / urgency / customer_level），导入后自动抽取并生成知识条目：</p>
        <SInput v-model="importText" type="textarea" :rows="7" class="mono" />
        <div class="row">
          <SButton variant="primary" :loading="importing" @click="onImport">确认导入</SButton>
          <span v-if="importMsg" :class="importMsg.startsWith('失败') ? 'e' : 'ok'">{{ importMsg }}</span>
        </div>
      </div>
    </Transition>

    <!-- 列表 -->
    <SEmpty
      v-if="err"
      error
      :desc="err"
      @retry="loadKnowledge"
    >
      <template #error-action>
        <SButton size="sm" variant="ghost" @click="loadKnowledge">重新加载</SButton>
      </template>
    </SEmpty>

    <SEmpty
      v-else-if="!loading && knowledge.length === 0"
      icon="🎫"
      title="暂无工单回流的知识条目"
      desc="点击右上角「导入工单」开始沉淀"
    />

    <SEmpty v-else-if="loading" loading loading-text="加载中…" />

    <div v-else class="grid">
      <KnowledgeCard
        v-for="item in knowledge"
        :key="item.id"
        :item="item"
        @edit="openEdit"
        @delete="confirmDelete"
        @publish="onPublish"
        @unpublish="onUnpublish"
      />
    </div>

    <!-- 编辑弹窗 -->
    <SModal :model-value="!!editing" @update:model-value="editing = null" :title="editing?.id ? '编辑知识' : '新增知识'" width="580px">
      <template v-if="editing">
        <div class="field">
          <label>问题（用于向量化检索）</label>
          <SInput v-model="form.question" placeholder="如：客户要退款怎么处理？" />
        </div>
        <div class="field">
          <label>标准话术 / 解决方案</label>
          <SInput v-model="form.solution" type="textarea" :rows="4" placeholder="坐席可直接发送给客户的回复" />
        </div>
        <div class="row2">
          <div class="field">
            <label>分类</label>
            <SInput v-model="form.category" placeholder="售后-退款" />
          </div>
          <div class="field">
            <label>模块</label>
            <SInput v-model="form.product_module" placeholder="订单" />
          </div>
        </div>
        <div class="field">
          <label>优先级</label>
          <SSelect v-model="form.urgency" :options="URGENCY_OPTIONS" />
        </div>
      </template>

      <template #footer>
        <SButton variant="ghost" @click="editing = null">取消</SButton>
        <SButton variant="primary" :loading="saving" @click="save">保存</SButton>
      </template>
    </SModal>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" @update:model-value="pendingDelete = null" title="确认删除" width="420px">
      <p class="confirm-text">
        确认删除「<strong>{{ pendingDelete?.question }}</strong>」？此操作不可撤销。
      </p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" :loading="deleting" @click="doDelete">删除</SButton>
      </template>
    </SModal>
  </SCard>
</template>

<style scoped>
.toolbar {
  display: flex;
  gap: var(--sp-3);
  align-items: center;
  margin-bottom: var(--sp-4);
  flex-wrap: wrap;
}

.toolbar :deep(.ssel) {
  min-width: 130px;
}

.import-box {
  background: var(--overlay-1);
  border: 1px solid var(--border);
  border-radius: var(--r-xl);
  padding: var(--sp-4);
  margin-bottom: var(--sp-4);
}

.tip {
  color: var(--text-3);
  font-size: var(--fs-base);
  margin: 0 0 var(--sp-3);
}

.mono :deep(.sinp__el) {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: var(--fs-sm);
}

.row {
  margin-top: var(--sp-3);
  display: flex;
  gap: var(--sp-3);
  align-items: center;
  flex-wrap: wrap;
}

.ok {
  color: var(--success-text);
  font-size: var(--fs-sm);
}

.e {
  color: var(--danger-text);
  font-size: var(--fs-sm);
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
  gap: var(--sp-3);
}

@media (max-width: 720px) {
  .grid {
    grid-template-columns: 1fr;
  }
}

.field {
  margin-bottom: var(--sp-4);
}

.field label {
  display: block;
  font-size: var(--fs-sm);
  color: var(--text-3);
  margin-bottom: var(--sp-2);
}

.row2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
}

.confirm-text {
  margin: 0;
  line-height: 1.7;
  color: var(--text-2);
}

.confirm-text strong {
  color: var(--text-1);
  word-break: break-word;
}

/* 折叠动画 */
.fold-enter-active,
.fold-leave-active {
  transition: opacity var(--dur) var(--ease), transform var(--dur) var(--ease);
  overflow: hidden;
}
.fold-enter-from,
.fold-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}
</style>
