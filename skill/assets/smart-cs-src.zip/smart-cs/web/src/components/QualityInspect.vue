<script setup>
/**
 * 全量质检（M4）—— 质检看板 / 历史对话
 * v2：改用 STabs 组件，去掉与 KnowledgeBuild 逐字重复的 tabs 样式
 * （对话工作台已独立为顶部一级导航）
 */
import { ref } from 'vue';
import Quality from './Quality.vue';
import History from './History.vue';
import STabs from './ui/STabs.vue';

const tab = ref('quality');

const TABS = [
  { id: 'quality', label: '质检看板', icon: '🛡', sub: '风险检测与趋势' },
  { id: 'history', label: '历史对话', icon: '🕘', sub: '会话日志与回溯' }
];
</script>

<template>
  <div class="qc">
    <STabs v-model="tab" :tabs="TABS" />

    <div class="block-body">
      <Quality v-if="tab === 'quality'" />
      <History v-else-if="tab === 'history'" />
    </div>
  </div>
</template>

<style scoped>
.qc {
  color: var(--text-2);
}

.block-body {
  animation: scs-fade-in var(--dur-slow) var(--ease-out);
}
</style>
