<!--
  历史FAQ —— 沉淀知识库的维护与检索测试
  视图：条目管理 / 检索测试
  管理侧能力：新增·编辑·发布·撤下·删除 / 状态筛选 / 全量重算向量 /
             会话去重合并 / 对话自动提炼 / 重算质量分 / 仅看待复审
  v2：SCard + STabs + 工具条分组，原生 confirm 改为 SModal 确认
-->
<script setup>
import { ref, onMounted, computed } from 'vue';
import {
  searchKnowledge,
  listKnowledge,
  createKnowledge,
  updateKnowledge,
  deleteKnowledge,
  reembedKnowledge,
  getLLMInfo,
  mergeSessions,
  autoExtractKnowledge,
  recalcQuality,
  getReviewQueue,
  publishKnowledge,
  unpublishKnowledge
} from '../api.js';
import KnowledgeCard from './KnowledgeCard.vue';
import SCard from './ui/SCard.vue';
import STabs from './ui/STabs.vue';
import SButton from './ui/SButton.vue';
import SInput from './ui/SInput.vue';
import SSelect from './ui/SSelect.vue';
import SModal from './ui/SModal.vue';
import SEmpty from './ui/SEmpty.vue';
import SBadge from './ui/SBadge.vue';
import { useToast } from '../composables/useToast.js';

const { success, error: toastError } = useToast();

const tab = ref('manage');
const TABS = [
  { id: 'manage', label: '条目管理', icon: '📚', sub: '维护 RAG 语料' },
  { id: 'search', label: '检索测试', icon: '🔍', sub: '验证召回效果' }
];

const q = ref('');
const results = ref([]);
const list = ref([]);
const total = ref(0);
const loading = ref(false);
const err = ref('');
const searched = ref(false);
const embedInfo = ref({ mode: 'pending', dim: 0 });

/* 编辑弹窗：null=关闭；{} = 新增；{id,...} = 编辑 */
const editing = ref(null);
const form = ref({ question: '', solution: '', category: '其他', product_module: '', urgency: 1 });
const saving = ref(false);

/* 运营操作状态 */
const reembedding = ref(false);
const merging = ref(false);
const autoExtracting = ref(false);
const recalculating = ref(false);

const reviewCount = ref(0);
const reviewThreshold = ref(0.35);
const onlyLowQuality = ref(false);
const statusFilter = ref('');

/* 危险/耗时操作的统一确认弹窗 */
const confirmState = ref({ open: false, title: '', message: '', action: null });
const confirming = ref(false);

function askConfirm(title, message, action) {
  confirmState.value = { open: true, title, message, action };
}
async function runConfirm() {
  const fn = confirmState.value.action;
  if (!fn) return;
  confirming.value = true;
  try {
    await fn();
    confirmState.value.open = false;
  } finally {
    confirming.value = false;
  }
}

const SUGGEST = ['退款怎么处理', '发票如何开具', '物流多久到', '产品保修政策'];

const STATUS_OPTIONS = [
  { value: '', label: '全部状态' },
  { value: 'published', label: '已发布' },
  { value: 'draft', label: '草稿' }
];

const URGENCY_OPTIONS = [
  { value: 1, label: '一般' },
  { value: 2, label: '较急' },
  { value: 3, label: '紧急' }
];

const embedLabel = computed(() => {
  const m = embedInfo.value.embed_mode;
  const d = embedInfo.value.embed_dim;
  return m === 'semantic' ? `真语义(${d}d)` : '离线哈希(256d)';
});

async function refreshList() {
  loading.value = true;
  err.value = '';
  try {
    // 历史FAQ：排除工单/飞书/IMA/本地文件渠道，只看「沉淀后」的内部知识（含对话提炼）
    let r;
    if (onlyLowQuality.value) {
      r = await getReviewQueue(reviewThreshold.value);
      r = { rows: r.rows || [], total: (r.rows || []).length };
    } else {
      r = await listKnowledge(100, 0, '', 'ticket,feishu,ima,file', statusFilter.value);
    }
    list.value = r.rows || [];
    total.value = r.total || 0;
  } catch (e) {
    err.value = e.message;
  } finally {
    loading.value = false;
  }

  // 复审计数独立刷新，失败不影响主列表
  try {
    const rq = await getReviewQueue(reviewThreshold.value);
    reviewCount.value = (rq.rows || []).length;
  } catch {}
}

async function onMergeSessions() {
  merging.value = true;
  try {
    const r = await mergeSessions();
    if (r.ok) {
      success(r.message || '会话合并完成');
    } else {
      toastError(r.error || '合并失败');
    }
  } catch (e) {
    toastError(e.message);
  } finally {
    merging.value = false;
  }
}

async function doAutoExtract() {
  autoExtracting.value = true;
  try {
    const r = await autoExtractKnowledge(50);
    if (r.ok) {
      success(`扫描 ${r.scanned} 段对话，新增 ${r.created} 条知识（来源：对话提炼）`);
    } else {
      toastError(r.error || '提炼失败');
    }
    await refreshList();
  } catch (e) {
    toastError(e.message);
  } finally {
    autoExtracting.value = false;
  }
}

async function doRecalcQuality() {
  recalculating.value = true;
  try {
    const r = await recalcQuality();
    if (r.ok) {
      success(`已重算 ${r.recomputed} 条知识质量分`);
    } else {
      toastError(r.error || '重算失败');
    }
    await refreshList();
  } catch (e) {
    toastError(e.message);
  } finally {
    recalculating.value = false;
  }
}

async function doReembed() {
  reembedding.value = true;
  try {
    const r = await reembedKnowledge();
    success(`已重算 ${r.ok}/${r.total} 条向量`);
    await refreshList();
  } catch (e) {
    toastError(e.message);
  } finally {
    reembedding.value = false;
  }
}

async function onSearch() {
  if (!q.value.trim()) return;
  loading.value = true;
  err.value = '';
  searched.value = true;
  try {
    const r = await searchKnowledge(q.value);
    results.value = r.results || [];
  } catch (e) {
    err.value = e.message;
    results.value = [];
  } finally {
    loading.value = false;
  }
}

function openCreate() {
  editing.value = {};
  form.value = { question: '', solution: '', category: '其他', product_module: '', urgency: 1 };
}

function openEdit(item) {
  editing.value = item;
  form.value = {
    question: item.question || '',
    solution: item.solution || '',
    category: item.category || '其他',
    product_module: item.product_module || '',
    urgency: item.urgency || 1
  };
}

async function save() {
  if (!form.value.question.trim()) {
    toastError('问题不能为空');
    return;
  }
  saving.value = true;
  try {
    if (editing.value && editing.value.id) {
      await updateKnowledge(editing.value.id, form.value);
      success('已更新并重新计算向量');
    } else {
      await createKnowledge(form.value);
      success('已新增并计算向量');
    }
    editing.value = null;
    await refreshList();
  } catch (e) {
    toastError(e.message);
  } finally {
    saving.value = false;
  }
}

const pendingDelete = ref(null);

async function doDelete() {
  const item = pendingDelete.value;
  if (!item) return;
  try {
    await deleteKnowledge(item.id);
    success('已删除');
    pendingDelete.value = null;
    await refreshList();
  } catch (e) {
    toastError(e.message);
  }
}

async function onPublish(item) {
  try {
    await publishKnowledge(item.id);
    success('已发布');
    await refreshList();
  } catch (e) {
    toastError(e.message);
  }
}

async function onUnpublish(item) {
  try {
    await unpublishKnowledge(item.id);
    success('已撤下');
    await refreshList();
  } catch (e) {
    toastError(e.message);
  }
}

function toggleLowQuality() {
  onlyLowQuality.value = !onlyLowQuality.value;
  refreshList();
}

onMounted(async () => {
  await refreshList();
  try {
    embedInfo.value = await getLLMInfo();
  } catch {}
});
</script>

<template>
  <SCard
    icon="📚"
    title="知识条目 · 沉淀知识库"
    :subtitle="`维护 RAG 语料 · 共 ${total} 条 · 向量：${embedLabel}`"
  >
    <STabs v-model="tab" :tabs="TABS" />

    <!-- ===== 条目管理 ===== -->
    <template v-if="tab === 'manage'">
      <div class="toolgroup">
        <div class="line">
          <SButton variant="primary" icon="＋" @click="openCreate">新增知识</SButton>
          <SSelect v-model="statusFilter" :options="STATUS_OPTIONS" size="sm" @change="refreshList" />
          <SButton size="sm" variant="ghost" :loading="reembedding" @click="askConfirm('全量重算向量', '将对全部知识条目重新计算向量（切换 embedding 模型后必须执行）。该操作耗时较长，确认继续？', doReembed)">
            🔄 全量重算向量
          </SButton>
          <SButton size="sm" variant="ghost" :loading="merging" @click="onMergeSessions">
            🔀 会话去重合并
          </SButton>
        </div>

        <div class="line">
          <SButton size="sm" variant="ghost" :loading="autoExtracting" @click="askConfirm('对话自动提炼', '将扫描「AI 回复被标记为正确」的对话，自动提炼为标准知识条目。确认继续？', doAutoExtract)">
            🤖 对话自动提炼
          </SButton>
          <SButton size="sm" variant="ghost" :loading="recalculating" @click="askConfirm('重算质量分', '将按「命中贡献 + 反馈校准 + 时效衰减」公式重算全部知识质量分。确认继续？', doRecalcQuality)">
            📊 重算质量分
          </SButton>
          <SButton size="sm" :variant="onlyLowQuality ? 'warn' : 'ghost'" @click="toggleLowQuality">
            🔥 仅看待复审
            <SBadge v-if="reviewCount" tone="danger" size="sm">{{ reviewCount }}</SBadge>
          </SButton>
        </div>
      </div>

      <SEmpty v-if="err" error :desc="err" @retry="refreshList" />

      <SEmpty
        v-else-if="!loading && list.length === 0"
        icon="📚"
        title="暂无历史 FAQ 知识条目"
        desc="可通过导入工单、同步飞书/IMA、或对话自动提炼来沉淀"
      />

      <SEmpty v-else-if="loading" loading />

      <div v-else class="grid">
        <KnowledgeCard
          v-for="r in list"
          :key="r.id"
          :item="r"
          @edit="openEdit"
          @delete="(it) => (pendingDelete = it)"
          @publish="onPublish"
          @unpublish="onUnpublish"
        />
      </div>
    </template>

    <!-- ===== 检索测试 ===== -->
    <template v-else>
      <div class="searchbar">
        <SInput v-model="q" placeholder="如：客户要退款，怎么处理？" @enter="onSearch" />
        <SButton variant="primary" :loading="loading" icon="🔍" @click="onSearch">检索</SButton>
      </div>

      <div class="suggest">
        <span class="lbl">试试：</span>
        <button v-for="s in SUGGEST" :key="s" class="chip" @click="q = s; onSearch()">{{ s }}</button>
      </div>

      <SEmpty v-if="err" error :desc="err" />

      <SEmpty
        v-else-if="searched && !loading && results.length === 0"
        icon="🔍"
        title="没有匹配的知识条目"
        desc="换个说法试试，或先补充相关知识"
      />

      <SEmpty v-else-if="loading" loading />

      <div v-else class="result-list">
        <article v-for="r in results" :key="r.id" class="rcard">
          <div class="top">
            <span class="q">{{ r.question }}</span>
            <SBadge tone="success" size="sm">
              相似度 {{ r.score != null ? r.score.toFixed(3) : '—' }}
            </SBadge>
          </div>
          <SBadge v-if="r.category" tone="violet" size="sm">{{ r.category }}</SBadge>
          <p class="sol">{{ r.solution }}</p>
        </article>
      </div>
    </template>

    <!-- 编辑/新增弹窗 -->
    <SModal :model-value="!!editing" @update:model-value="editing = null" :title="editing?.id ? '编辑知识' : '新增知识'" width="580px">
      <template v-if="editing">
        <div class="field">
          <label>问题（用于向量化检索）</label>
          <SInput v-model="form.question" placeholder="如：客户要退款怎么处理？" />
        </div>
        <div class="field">
          <label>标准话术 / 解决方案</label>
          <SInput v-model="form.solution" type="textarea" :rows="4" placeholder="坐席可直接发送给客户的回复" />
        </div>
        <div class="row2">
          <div class="field">
            <label>分类</label>
            <SInput v-model="form.category" placeholder="售后-退款" />
          </div>
          <div class="field">
            <label>模块</label>
            <SInput v-model="form.product_module" placeholder="订单" />
          </div>
        </div>
        <div class="field">
          <label>优先级</label>
          <SSelect v-model="form.urgency" :options="URGENCY_OPTIONS" />
        </div>
      </template>

      <template #footer>
        <SButton variant="ghost" @click="editing = null">取消</SButton>
        <SButton variant="primary" :loading="saving" @click="save">保存并计算向量</SButton>
      </template>
    </SModal>

    <!-- 通用操作确认 -->
    <SModal v-model="confirmState.open" :title="confirmState.title" width="440px">
      <p class="confirm-text">{{ confirmState.message }}</p>
      <template #footer>
        <SButton variant="ghost" @click="confirmState.open = false">取消</SButton>
        <SButton variant="primary" :loading="confirming" @click="runConfirm">确认执行</SButton>
      </template>
    </SModal>

    <!-- 删除确认 -->
    <SModal :model-value="!!pendingDelete" @update:model-value="pendingDelete = null" title="确认删除" width="420px">
      <p class="confirm-text">
        确认删除「<strong>{{ pendingDelete?.question }}</strong>」？此操作不可撤销。
      </p>
      <template #footer>
        <SButton variant="ghost" @click="pendingDelete = null">取消</SButton>
        <SButton variant="danger" @click="doDelete">删除</SButton>
      </template>
    </SModal>
  </SCard>
</template>

<style scoped>
.toolgroup {
  display: flex;
  flex-direction: column;
  gap: var(--sp-2);
  margin-bottom: var(--sp-4);
}

.line {
  display: flex;
  gap: var(--sp-2);
  align-items: center;
  flex-wrap: wrap;
}

.line :deep(.ssel) {
  min-width: 120px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
  gap: var(--sp-3);
}

@media (max-width: 720px) {
  .grid {
    grid-template-columns: 1fr;
  }
}

/* ===== 检索 ===== */
.searchbar {
  display: flex;
  gap: var(--sp-3);
  align-items: center;
}

.suggest {
  margin: var(--sp-4) 0 var(--sp-2);
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
  align-items: center;
}

.lbl {
  color: var(--text-4);
  font-size: var(--fs-base);
}

.chip {
  background: var(--overlay-1);
  border: 1px solid var(--border-strong);
  color: var(--text-2);
  padding: 5px 12px;
  border-radius: var(--r-full);
  cursor: pointer;
  font-size: var(--fs-base);
  font-family: inherit;
  transition: var(--dur-fast) var(--ease);
}
.chip:hover {
  border-color: var(--brand);
  color: var(--brand);
}

.result-list {
  margin-top: var(--sp-3);
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
}

.rcard {
  background: var(--overlay-1);
  border: 1px solid var(--border);
  border-radius: var(--r-xl);
  padding: var(--sp-4);
  transition: border-color var(--dur) var(--ease);
}
.rcard:hover {
  border-color: var(--brand-ring);
}

.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--sp-3);
  margin-bottom: var(--sp-2);
}

.q {
  font-weight: var(--fw-bold);
  color: var(--text-1);
  font-size: var(--fs-md);
  word-break: break-word;
}

.sol {
  color: var(--text-2);
  line-height: 1.7;
  font-size: var(--fs-md);
  margin: var(--sp-2) 0 0;
  white-space: pre-wrap;
  word-break: break-word;
}

/* ===== 弹窗表单 ===== */
.field {
  margin-bottom: var(--sp-4);
}

.field label {
  display: block;
  font-size: var(--fs-sm);
  color: var(--text-3);
  margin-bottom: var(--sp-2);
}

.row2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--sp-3);
}

.confirm-text {
  margin: 0;
  line-height: 1.7;
  color: var(--text-2);
}

.confirm-text strong {
  color: var(--text-1);
  word-break: break-word;
}
</style>
