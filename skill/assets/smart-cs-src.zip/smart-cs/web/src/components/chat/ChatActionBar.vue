<script setup>
const props = defineProps({
  lastTurn: { type: Object, default: null },
  handing: { type: Boolean, default: false },
  handoffMsg: { type: String, default: '' }
});
const emit = defineEmits(['handoff']);
</script>

<template>
  <div class="actionbar" v-if="lastTurn">
    <span class="ab-tip">本轮：{{ lastTurn.userMsg.text.slice(0, 24) }}{{ lastTurn.userMsg.text.length > 24 ? '…' : '' }}</span>
    <button class="ab-btn handoff" :disabled="handing" @click="emit('handoff')">
      {{ handing ? '转交中…' : '🚨 转人工 / 转复核' }}
    </button>
    <span v-if="handoffMsg" class="ab-msg">{{ handoffMsg }}</span>
  </div>
</template>

<style scoped>
.actionbar { display: flex; align-items: center; gap: 10px; padding: 8px 14px; border-top: 1px solid rgba(255,255,255,0.1); background: rgba(248,113,113,0.06); }
.ab-tip { font-size: 12px; color: #94a3b8; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ab-btn.handoff { flex: none; padding: 8px 16px; border: 0; border-radius: 9px; background: linear-gradient(135deg, #f59e0b, #ef4444); color: #fff; cursor: pointer; font-weight: 700; font-size: 13px; }
.ab-btn.handoff:disabled { opacity: .6; }
.ab-msg { font-size: 12px; color: #6ee7b7; }
</style>
