<script setup>
import { ref, computed, watch } from 'vue';
import { listScripts, listKnowledge, searchKnowledge } from '../../api.js';

const props = defineProps({
  open: { type: Boolean, default: false },
  retrieveMode: { type: String, default: 'knowledge' }
});
const emit = defineEmits(['update:open', 'update:retrieveMode', 'insert']);

// ---------- 话术库侧栏（已发布话术，坐席一键插入回复草稿）----------
const libQ = ref('');
const libRows = ref([]);
const libLoading = ref(false);
const libLoaded = ref(false);
const expanded = ref(null);
// 知识库检索结果（仅已发布）
const knRows = ref([]);
const knLoading = ref(false);

// 仅展示已发布话术；按关键词本地过滤 场景/触发条件/话术内容
const libFiltered = computed(() => {
  const q = libQ.value.trim().toLowerCase();
  if (!q) return libRows.value;
  return libRows.value.filter((s) => {
    const hay = [s.scene, s.trigger_cond, JSON.stringify(s.turns || [])].join(' ').toLowerCase();
    return hay.includes(q);
  });
});

async function loadLib() {
  if (libLoaded.value) return; // 懒加载一次即可
  libLoading.value = true;
  try {
    const r = await listScripts('published', ''); // 只拉已发布
    libRows.value = r.rows || [];
    libLoaded.value = true;
  } catch {
    libRows.value = [];
  } finally {
    libLoading.value = false;
  }
}
// 知识库检索：仅已发布条目；空查询时回退为浏览全部已发布知识
async function searchKn(q) {
  knLoading.value = true;
  try {
    if (!q || !q.trim()) {
      const r = await listKnowledge(50, 0, '', '', 'published');
      knRows.value = (r.rows || []).map((x) => ({ id: x.id, question: x.question, solution: x.solution, category: x.category }));
    } else {
      const r = await searchKnowledge(q.trim());
      knRows.value = (r.results || []).map((x) => ({ id: x.id, question: x.question, solution: x.solution, category: x.category }));
    }
  } catch {
    knRows.value = [];
  } finally {
    knLoading.value = false;
  }
}

// 抽屉搜索框输入：话术库走本地过滤（libFiltered）；知识库按需检索
function onLibSearch() {
  if (retrieveMode.value === 'knowledge' || retrieveMode.value === 'both') {
    searchKn(libQ.value);
  }
}
// 打开抽屉时预加载知识库结果（便于「两者 / 知识库」tab 直接展示）
watch(() => props.open, (v) => {
  if (v) { loadLib(); searchKn(libQ.value); }
});
// 把一条客服(agent)话术追加到回复草稿框（由父组件接管 draft 拼接）
function insertTurn(content) {
  if (!content) return;
  emit('insert', content);
}
</script>

<template>
  <Teleport to="body">
    <div v-if="open" class="lib-mask" @click.self="emit('update:open', false)">
      <div class="lib-panel">
        <div class="lib-head">
          <span>🔍 知识检索</span>
          <div class="lib-tabs">
            <button :class="{ on: retrieveMode === 'scripts' }" @click="emit('update:retrieveMode', 'scripts')">💬 话术库</button>
            <button :class="{ on: retrieveMode === 'knowledge' }" @click="emit('update:retrieveMode', 'knowledge')">📚 知识库</button>
            <button :class="{ on: retrieveMode === 'both' }" @click="emit('update:retrieveMode', 'both')">🔁 两者</button>
          </div>
          <button class="x" @click="emit('update:open', false)">✕</button>
        </div>
        <input v-model="libQ" class="lib-search" :placeholder="retrieveMode === 'knowledge' ? '搜索知识条目（问题/分类）' : '搜索场景 / 触发条件 / 话术内容'" @input="onLibSearch" />
        <div class="lib-list">
          <!-- 话术库 -->
          <template v-if="retrieveMode === 'scripts' || retrieveMode === 'both'">
            <div v-if="retrieveMode === 'both'" class="lib-group-h">💬 话术库（已发布）</div>
            <div v-if="libLoading" class="muted">加载中…</div>
            <div v-else-if="!libFiltered.length" class="muted">无匹配的已发布话术</div>
            <div v-for="s in libFiltered" :key="'s' + s.id" class="lib-item">
              <div class="lib-item-top" @click="expanded = expanded === s.id ? null : s.id">
                <span class="lib-scene">{{ s.scene || '未命名场景' }}</span>
                <span class="lib-badge">已发布 · {{ (s.turns || []).length }} 轮</span>
              </div>
              <div class="lib-trig">触发：{{ s.trigger_cond || '（未设置）' }}</div>
              <div v-if="expanded === s.id" class="lib-turns">
                <div v-for="(t, i) in (s.turns || [])" :key="i" class="lib-turn" :class="t.role">
                  <span class="who">{{ t.role === 'agent' ? '客服' : '客户' }}</span>
                  <span class="txt">{{ t.content }}</span>
                  <button v-if="t.role === 'agent'" class="ins" @click="insertTurn(t.content)">插入</button>
                </div>
              </div>
            </div>
          </template>
          <!-- 知识库 -->
          <template v-if="retrieveMode === 'knowledge' || retrieveMode === 'both'">
            <div v-if="retrieveMode === 'both'" class="lib-group-h">📚 知识库（已发布）</div>
            <div v-if="knLoading" class="muted">检索中…</div>
            <div v-else-if="!knRows.length" class="muted">无匹配的知识条目</div>
            <div v-for="k in knRows" :key="'k' + k.id" class="lib-item kn">
              <div class="lib-item-top">
                <span class="lib-scene">{{ k.question }}</span>
                <span class="lib-badge kn">{{ k.category || '知识' }}</span>
              </div>
              <div class="lib-trig kn-snip">{{ (k.solution || k.question || '').slice(0, 120) }}{{ (k.solution || '').length > 120 ? '…' : '' }}</div>
              <button class="ins kn-ins" @click="insertTurn(k.solution || k.question)">插入</button>
            </div>
          </template>
        </div>
        <div class="lib-foot">检索来源与上方「话术库 / 知识库 / 两者」一致，自动回复也按此来源生成</div>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.lib-mask { position: fixed; top: 0; right: 0; bottom: 0; width: 400px; max-width: 92vw; z-index: 9997; background: rgba(2,6,23,0.6); backdrop-filter: blur(2px); display: flex; justify-content: flex-end; }
.lib-panel { width: 100%; height: 100%; background: rgba(15,23,42,0.98); border-left: 1px solid rgba(167,139,250,0.3); display: flex; flex-direction: column; color: #e2e8f0; box-shadow: -20px 0 60px rgba(0,0,0,0.5); }
.lib-head { display: flex; justify-content: space-between; align-items: center; font-weight: 700; padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.1); }
.lib-head .x { background: none; border: 0; color: #94a3b8; cursor: pointer; font-size: 18px; line-height: 1; }
.lib-head .x:hover { color: #f1f5f9; }
.lib-search { margin: 12px 16px; padding: 10px 12px; border-radius: 9px; border: 1px solid rgba(255,255,255,0.18); background: rgba(15,23,42,0.6); color: #f1f5f9; outline: none; box-sizing: border-box; font-size: 13px; }
.lib-search:focus { border-color: #a78bfa; }
.lib-list { flex: 1; overflow-y: auto; padding: 0 16px 16px; display: flex; flex-direction: column; gap: 10px; }
.lib-item { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px; }
.lib-item-top { display: flex; justify-content: space-between; align-items: center; cursor: pointer; }
.lib-scene { color: #f8fafc; font-weight: 600; font-size: 14px; }
.lib-badge { font-size: 11px; color: #34d399; background: rgba(52,211,153,0.14); border: 1px solid rgba(52,211,153,0.3); padding: 1px 8px; border-radius: 6px; white-space: nowrap; }
.lib-trig { color: #94a3b8; font-size: 12px; margin-top: 4px; }
.lib-turns { margin-top: 10px; padding-top: 10px; border-top: 1px dashed rgba(255,255,255,0.18); display: flex; flex-direction: column; gap: 8px; }
.lib-turn { display: flex; align-items: flex-start; gap: 8px; font-size: 13px; line-height: 1.5; }
.lib-turn .who { flex: none; font-size: 11px; color: #94a3b8; width: 32px; }
.lib-turn.customer .txt { color: #cbd5e1; }
.lib-turn.agent .txt { color: #e2e8f0; }
.lib-turn .txt { flex: 1; }
.lib-turn .ins { flex: none; padding: 3px 10px; border-radius: 7px; border: 1px solid rgba(167,139,250,0.5); background: rgba(167,139,250,0.15); color: #ddd6fe; cursor: pointer; font-size: 12px; }
.lib-turn .ins:hover { border-color: #a78bfa; background: rgba(167,139,250,0.25); }
.muted { color: #94a3b8; text-align: center; padding: 16px 0; font-size: 13px; }
.lib-tabs { display: inline-flex; gap: 4px; }
.lib-tabs button { padding: 4px 10px; border: 1px solid rgba(255,255,255,0.18); background: transparent; color: #94a3b8; border-radius: 8px; cursor: pointer; font-size: 12px; white-space: nowrap; }
.lib-tabs button.on { background: rgba(34,211,238,0.18); border-color: #22d3ee; color: #e2e8f0; }
.lib-group-h { color: #64748b; font-size: 11px; font-weight: 700; letter-spacing: 1px; margin: 6px 2px 2px; }
.lib-foot { padding: 8px 16px; border-top: 1px solid rgba(255,255,255,0.1); color: #64748b; font-size: 11px; text-align: center; }
.lib-item.kn { display: flex; flex-direction: column; gap: 6px; }
.kn-snip { color: #94a3b8; font-size: 12px; line-height: 1.5; }
.lib-badge.kn { color: #93c5fd; background: rgba(96,165,250,0.14); border: 1px solid rgba(96,165,250,0.3); }
.kn-ins { align-self: flex-end; }
</style>
