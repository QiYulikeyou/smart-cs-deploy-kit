<script setup>
import { ref } from 'vue';

const props = defineProps({
  modelValue: { type: String, default: '' },
  libOpen: { type: Boolean, default: false }
});
const emit = defineEmits(['update:modelValue']);

const copyMsg = ref('');
async function copyDraft() {
  if (!props.modelValue.trim()) return;
  try {
    await navigator.clipboard.writeText(props.modelValue);
    copyMsg.value = '✓ 已复制';
  } catch {
    copyMsg.value = '复制失败，请手动选择';
  }
  setTimeout(() => (copyMsg.value = ''), 2000);
}
function clearDraft() {
  emit('update:modelValue', '');
}
</script>

<template>
  <div class="draftbar" v-if="libOpen || modelValue">
    <div class="draft-head">
      <span>💬 我的回复草稿 <em>（从右侧话术库点「插入」填充）</em></span>
      <span class="draft-tools">
        <span v-if="copyMsg" class="copy-msg">{{ copyMsg }}</span>
        <button class="draft-btn" :disabled="!modelValue.trim()" @click="copyDraft">📋 复制</button>
        <button class="draft-btn ghost" :disabled="!modelValue.trim()" @click="clearDraft">清空</button>
      </span>
    </div>
    <textarea
      :value="modelValue"
      @input="emit('update:modelValue', $event.target.value)"
      class="draft-ta"
      placeholder="在此撰写回复，或从话术库一键插入标准话术…"
    ></textarea>
  </div>
</template>

<style scoped>
.draftbar { padding: 10px 14px; border-top: 1px solid rgba(255,255,255,0.1); background: rgba(167,139,250,0.05); }
.draft-head { display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: #c4b5fd; margin-bottom: 6px; }
.draft-head em { color: #94a3b8; font-style: normal; font-size: 11px; }
.draft-tools { display: flex; align-items: center; gap: 8px; }
.copy-msg { color: #6ee7b7; font-size: 11px; }
.draft-btn { padding: 4px 12px; border-radius: 8px; border: 1px solid rgba(167,139,250,0.5); background: rgba(167,139,250,0.15); color: #ddd6fe; cursor: pointer; font-size: 12px; font-weight: 600; }
.draft-btn:disabled { opacity: .5; cursor: not-allowed; }
.draft-btn.ghost { border-color: rgba(255,255,255,0.2); background: transparent; color: #94a3b8; }
.draft-ta { width: 100%; min-height: 64px; max-height: 160px; resize: vertical; padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(167,139,250,0.3); background: rgba(15,23,42,0.6); color: #f1f5f9; outline: none; box-sizing: border-box; font-size: 13px; line-height: 1.5; font-family: inherit; }
</style>
