<script setup>
import { computed } from 'vue';

const props = defineProps({
  message: { type: Object, required: true },
  index: { type: Number, required: true },
  feedback: { type: String, default: null }, // 'correct' | 'incorrect' | null
  llmModel: { type: String, default: '' }
});
const emit = defineEmits(['feedback']);

const EMOTION_LABEL = { angry: '😠 愤怒', positive: '🙂 正向', neutral: '😐 中性' };
const RISK_CLASS = { high: 'r-high', mid: 'r-mid', low: 'r-low' };
const RISK_LABEL = { high: '高风险', mid: '中风险', low: '低风险' };

function srcLabel(s) {
  if (s === 'script') return '💬 话术库命中';
  if (s === 'knowledge' || s === 'local') return '📚 本地知识库命中';
  if (s === 'ima') return '🌐 IMA 知识库命中';
  if (s === 'feishu') return '🌐 飞书知识库命中';
  if (s === 'llm') return '🤖 ' + (props.llmModel || '大模型') + ' 生成';
  return '⚠ 未识别';
}

const riskClass = computed(() => (props.message.detect ? RISK_CLASS[props.message.detect.risk_level] : ''));
</script>

<template>
  <div class="msg" :class="message.role">
    <div class="bubble" :class="message.role">
      <!-- 客户消息：顶部质检角标（情绪 / 风险 / 敏感词） -->
      <div v-if="message.role === 'user' && message.detect" class="detect-bar" :class="riskClass">
        <span class="d-chip">{{ EMOTION_LABEL[message.detect.emotion] || '😐 中性' }}</span>
        <span class="d-chip risk">{{ RISK_LABEL[message.detect.risk_level] || '低风险' }}</span>
        <span v-if="message.detect.sensitive_hits && message.detect.sensitive_hits.length" class="d-chip sens">
          ⚠ 敏感词：{{ message.detect.sensitive_hits.map(s => s.word).join('、') }}
        </span>
        <span v-if="message.detect.error" class="d-chip err">质检不可用：{{ message.detect.error }}</span>
      </div>

      <!-- Bot 回复：来源标签 -->
      <div v-if="message.role === 'bot' && message.source" class="src-tag" :class="message.source">
        {{ srcLabel(message.source) }}
      </div>
      <pre v-if="message.role === 'bot' && message.text.includes('\n')">{{ message.text }}</pre>
      <template v-else>{{ message.text }}</template>

      <!-- Bot 回复：命中知识卡片（含相似度分数 + 引用来源） -->
      <div v-if="message.role === 'bot' && message.hits && message.hits.length" class="hits">
        <div class="hits-title">
          📚 检索增强命中（{{ message.hits.length }} 条 · 阈值 {{ (message.threshold || 0.6).toFixed(2) }}）
        </div>
        <div v-for="(h, k) in message.hits" :key="k" class="hit">
          <span class="cat">{{ h.source === 'ima' ? 'IMA' : h.source === 'feishu' ? '飞书' : h.category || '本地' }}</span>
          <span class="q">{{ h.title || h.question }}
            <span class="score" v-if="h.score != null">相似度 {{ h.score.toFixed(2) }}</span>
            <span class="snip" v-if="h.snippet">{{ h.snippet.slice(0, 80) }}{{ h.snippet.length > 80 ? '…' : '' }}</span>
          </span>
          <a v-if="h.url" class="src-link" :href="h.url" target="_blank" rel="noopener">原文 ↗</a>
        </div>
      </div>

      <!-- Bot 回复：命中话术卡片（自动回复来源=话术库/两者时） -->
      <div v-if="message.role === 'bot' && message.script_hits && message.script_hits.length" class="hits script">
        <div class="hits-title">💬 参考话术（{{ message.script_hits.length }} 条）</div>
        <div v-for="(s, k) in message.script_hits" :key="k" class="hit">
          <span class="cat script">话术</span>
          <span class="q">{{ s.scene }}
            <span class="snip" v-if="s.replyText">{{ s.replyText.slice(0, 80) }}{{ s.replyText.length > 80 ? '…' : '' }}</span>
          </span>
        </div>
      </div>

      <!-- Bot 回复：引用标注 + 人工复核提示 -->
      <div v-if="message.role === 'bot' && message.cited && message.cited.length" class="cited">
        🔗 引用知识：<template v-for="(c, k) in message.cited" :key="k">
          <a v-if="c.url" :href="c.url" target="_blank" rel="noopener" class="cited-item">{{ c.title }} ↗</a>
          <span v-else class="cited-item">{{ c.title }}</span>
          <span v-if="k < message.cited.length - 1" class="cited-sep"> · </span>
        </template>
      </div>
      <div v-if="message.role === 'bot' && message.source !== 'llm' && message.source !== 'error' && message.hits && message.hits.length" class="suggest-tip">
        ✅ 相似度 ≥ 阈值，为知识库精确匹配答案，可直接发送给客户
      </div>
      <div v-if="message.role === 'bot' && message.source === 'llm' && message.hits && message.hits.length" class="suggest-tip llm">
        🤖 命中相似度偏低（&lt; 阈值），已作为参考由大模型综合生成，建议人工确认后发送
      </div>
      <div v-if="message.role === 'bot' && message.source === 'llm' && (!message.hits || !message.hits.length)" class="suggest-tip llm">
        🤖 知识库无相关条目，由大模型生成，建议人工确认后发送
      </div>

      <!-- 反馈按钮（仅 bot 消息显示） -->
      <div v-if="message.role === 'bot'" class="feedback-row">
        <button
          class="fb-btn correct"
          :class="{ on: feedback === 'correct' }"
          @click="emit('feedback', index, 'correct')"
        >👍 正确</button>
        <button
          class="fb-btn incorrect"
          :class="{ on: feedback === 'incorrect' }"
          @click="emit('feedback', index, 'incorrect')"
        >👎 错误</button>
        <span v-if="feedback === 'correct'" class="fb-label correct">已标记正确</span>
        <span v-else-if="feedback === 'incorrect'" class="fb-label incorrect">已标记错误</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.msg { display: flex; }
.msg.user { justify-content: flex-end; }
.msg.bot { justify-content: flex-start; }
.bubble { max-width: 82%; padding: 11px 15px; border-radius: 14px; font-size: 14px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; }
.bubble.user { background: linear-gradient(135deg, #06b6d4, #3b82f6); color: #fff; border-bottom-right-radius: 4px; }
.bubble.bot { background: rgba(255,255,255,0.08); color: #e2e8f0; border-bottom-left-radius: 4px; border: 1px solid rgba(255,255,255,0.1); }
.bubble pre { margin: 0; white-space: pre-wrap; font-family: inherit; }
.src-tag { display: inline-block; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 6px; margin-bottom: 6px; }
.src-tag.knowledge, .src-tag.local { color: #34d399; background: rgba(52,211,153,0.12); border: 1px solid rgba(52,211,153,0.3); }
.src-tag.ima, .src-tag.feishu { color: #93c5fd; background: rgba(96,165,250,0.14); border: 1px solid rgba(96,165,250,0.35); }
.src-tag.llm { color: #22d3ee; background: rgba(34,211,238,0.12); border: 1px solid rgba(34,211,238,0.3); }
.src-tag.script { color: #c4b5fd; background: rgba(167,139,250,0.14); border: 1px solid rgba(167,139,250,0.35); }
.hits { margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,0.18); font-size: 12px; }
.hits.script { border-top-color: rgba(167,139,250,0.3); }
.hits.script .cat.script { color: #c4b5fd; }
.hits-title { color: #94a3b8; margin-bottom: 4px; }
.hit { display: flex; align-items: flex-start; flex-wrap: wrap; gap: 8px; padding: 2px 0; }
.hit .cat { flex: none; color: #22d3ee; }
.hit .cat.script { color: #c4b5fd; }
.hit .q { color: #cbd5e1; }
.hit .q .snip { color: #94a3b8; font-size: 11px; display: block; margin-top: 2px; }
.hit .score { color: #34d399; font-size: 11px; margin-left: 6px; white-space: nowrap; }
.hit .src-link { color: #67e8f9; font-size: 11px; margin-left: auto; text-decoration: none; }
.hit .src-link:hover { text-decoration: underline; }
.typing { color: #94a3b8; font-style: italic; }
.detect-bar { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; padding: 6px 8px; border-radius: 8px; font-size: 11px; }
.detect-bar.r-high { background: rgba(248,113,113,0.14); border: 1px solid rgba(248,113,113,0.4); }
.detect-bar.r-mid { background: rgba(251,191,36,0.12); border: 1px solid rgba(251,191,36,0.4); }
.detect-bar.r-low { background: rgba(52,211,153,0.1); border: 1px solid rgba(52,211,153,0.3); }
.d-chip { padding: 2px 8px; border-radius: 6px; font-weight: 600; background: rgba(255,255,255,0.08); color: #cbd5e1; white-space: nowrap; }
.d-chip.risk { color: #fca5a5; }
.r-mid .d-chip.risk { color: #fcd34d; }
.r-low .d-chip.risk { color: #6ee7b7; }
.d-chip.sens { color: #fca5a5; background: rgba(248,113,113,0.18); }
.d-chip.err { color: #fbbf24; background: rgba(251,191,36,0.12); }
.suggest-tip { margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,0.18); font-size: 12px; color: #6ee7b7; }
.suggest-tip.llm { color: #fcd34d; }
.cited { margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,0.18); font-size: 12px; color: #94a3b8; line-height: 1.8; }
.cited-item { color: #93c5fd; }
a.cited-item { text-decoration: none; }
a.cited-item:hover { text-decoration: underline; }
.cited-sep { color: #475569; }
.feedback-row { display: flex; align-items: center; gap: 8px; margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,0.1); }
.fb-btn { padding: 4px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.06); color: #94a3b8; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.15s; }
.fb-btn:hover { border-color: rgba(34,211,238,0.4); color: #e2e8f0; }
.fb-btn.correct.on { background: rgba(52,211,153,0.2); border-color: #34d399; color: #6ee7b7; }
.fb-btn.incorrect.on { background: rgba(248,113,113,0.2); border-color: #f87171; color: #fca5a5; }
.fb-label { font-size: 11px; font-weight: 600; }
.fb-label.correct { color: #6ee7b7; }
.fb-label.incorrect { color: #fca5a5; }
</style>
