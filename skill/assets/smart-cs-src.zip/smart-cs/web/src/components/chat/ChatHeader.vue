<script setup>
const props = defineProps({
  llmInfo: { type: Object, default: () => ({}) },
  retrieveMode: { type: String, default: 'knowledge' }
});
const emit = defineEmits(['update:retrieveMode', 'open-cfg', 'open-lib']);
</script>

<template>
  <div class="head">
    <span>💬 客服对话工作台</span>
    <div class="head-right">
      <span class="llm-tag" :title="JSON.stringify(llmInfo)">
        模型：{{ llmInfo.llm_model || llmInfo.mode || 'pending' }} · 库：{{ llmInfo.kb_source || 'local' }}
        <span v-if="llmInfo.embed_mode" class="emb" :class="llmInfo.embed_mode">
          {{ llmInfo.embed_mode === 'semantic' ? '语义向量' : '哈希向量' }}
        </span>
      </span>
      <div class="src-seg" title="检索来源：同时控制自动回复与检索抽屉的来源">
        <button :class="{ on: retrieveMode === 'scripts' }" @click="emit('update:retrieveMode', 'scripts')">话术库</button>
        <button :class="{ on: retrieveMode === 'knowledge' }" @click="emit('update:retrieveMode', 'knowledge')">知识库</button>
        <button :class="{ on: retrieveMode === 'both' }" @click="emit('update:retrieveMode', 'both')">两者</button>
      </div>
      <button class="cfg-btn" title="模型与知识库配置" @click="emit('open-cfg')">⚙️ 模型设置</button>
      <button class="lib-btn" title="知识检索（话术库 / 知识库 / 两者）" @click="emit('open-lib')">🔍 知识检索</button>
    </div>
  </div>
</template>

<style scoped>
.head { display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; border-bottom: 1px solid rgba(255,255,255,0.1); color: #e2e8f0; font-weight: 600; background: rgba(255,255,255,0.04); }
.llm-tag { font-size: 12px; font-weight: 500; color: #22d3ee; padding: 2px 8px; border: 1px solid rgba(34,211,238,0.4); border-radius: 999px; background: rgba(34,211,238,0.08); }
.llm-tag .emb { margin-left: 6px; padding: 1px 6px; border-radius: 6px; font-size: 11px; }
.llm-tag .emb.semantic { color: #6ee7b7; background: rgba(52,211,153,0.16); }
.llm-tag .emb.offline { color: #fbbf24; background: rgba(251,191,36,0.16); }
.head-right { display: flex; align-items: center; gap: 12px; }
.cfg-btn { flex: none; padding: 7px 14px; border-radius: 9px; border: 1px solid rgba(34,211,238,0.4); background: rgba(34,211,238,0.1); color: #22d3ee; cursor: pointer; font-size: 13px; font-weight: 600; white-space: nowrap; }
.cfg-btn:hover { border-color: #22d3ee; background: rgba(34,211,238,0.18); }
.lib-btn { flex: none; padding: 7px 14px; border-radius: 9px; border: 1px solid rgba(167,139,250,0.4); background: rgba(167,139,250,0.1); color: #c4b5fd; cursor: pointer; font-size: 13px; font-weight: 600; white-space: nowrap; }
.lib-btn:hover { border-color: #a78bfa; background: rgba(167,139,250,0.18); }
.src-seg { display: inline-flex; border: 1px solid rgba(34,211,238,0.35); border-radius: 9px; overflow: hidden; }
.src-seg button { padding: 6px 12px; border: 0; background: transparent; color: #94a3b8; cursor: pointer; font-size: 12px; font-weight: 600; white-space: nowrap; }
.src-seg button + button { border-left: 1px solid rgba(34,211,238,0.2); }
.src-seg button.on { background: linear-gradient(135deg, rgba(6,182,212,0.35), rgba(59,130,246,0.35)); color: #fff; }
.src-seg button:hover:not(.on) { color: #e2e8f0; }
</style>
