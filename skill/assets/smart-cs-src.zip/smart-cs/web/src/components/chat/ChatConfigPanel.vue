<script setup>
import { ref, watch } from 'vue';
import { getLLMInfo, applyConfig } from '../../api.js';

const props = defineProps({
  open: { type: Boolean, default: false },
  llmInfo: { type: Object, default: () => ({}) }
});
const emit = defineEmits(['update:open', 'applied']);

const cfg = ref({
  provider: 'ollama',
  base: 'http://localhost:11434',
  model: 'qwen3.6',
  embed_model: 'nomic-embed-text',
  api_key: '',
  kb_source: 'local',
  ima_client_id: '',
  ima_api_key: '',
  ima_kb_id: '',
  feishu_app_id: '',
  feishu_app_secret: '',
  feishu_space_ids: ''
});
const cfgSaved = ref(false);
const presetFlash = ref(false);
const showKey = ref(false);
const showIma = ref(false);
const showFs = ref(false);

// 初始化配置面板：以「后端真实生效配置」为权威来源，避免 localStorage 默认值
// 覆盖后端（footgun：之前 localStorage 残留 provider=api 会在点「应用」时把正确的
// ollama 覆盖回 api，导致语义向量回退为哈希）。localStorage 仅用于叠加密钥类字段
// （飞书/IMA 凭证等后端不回显的字段），保证用户已填的凭证不丢失。
async function loadCfg() {
  try {
    const info = await getLLMInfo();
    cfg.value = {
      ...cfg.value,
      provider: info.provider || cfg.value.provider,
      base: info.base || cfg.value.base,
      model: info.llm_model || cfg.value.model,
      embed_model: info.embed_model || cfg.value.embed_model,
      kb_source: info.kb_source || cfg.value.kb_source
    };
  } catch {}
  try {
    const s = localStorage.getItem('scs_llm_cfg');
    if (s) {
      const saved = JSON.parse(s);
      cfg.value = {
        ...cfg.value,
        api_key: saved.api_key ?? cfg.value.api_key,
        ima_client_id: saved.ima_client_id ?? cfg.value.ima_client_id,
        ima_api_key: saved.ima_api_key ?? cfg.value.ima_api_key,
        ima_kb_id: saved.ima_kb_id ?? cfg.value.ima_kb_id,
        feishu_app_id: saved.feishu_app_id ?? cfg.value.feishu_app_id,
        feishu_app_secret: saved.feishu_app_secret ?? cfg.value.feishu_app_secret,
        feishu_space_ids: saved.feishu_space_ids ?? cfg.value.feishu_space_ids
      };
    }
  } catch {}
}
function saveCfg() {
  localStorage.setItem('scs_llm_cfg', JSON.stringify(cfg.value));
  cfgSaved.value = true;
  presetFlash.value = true;
  setTimeout(() => (cfgSaved.value = false), 2000);
  setTimeout(() => (presetFlash.value = false), 1200);
}

const applying = ref(false);
const applyMsg = ref('');
async function applyToBackend() {
  applying.value = true;
  applyMsg.value = '';
  try {
    const r = await applyConfig({
      provider: cfg.value.provider,
      base: cfg.value.base,
      model: cfg.value.model,
      embed_model: cfg.value.embed_model,
      api_key: cfg.value.api_key,
      kb_source: cfg.value.kb_source,
      ima_client_id: cfg.value.ima_client_id,
      ima_api_key: cfg.value.ima_api_key,
      ima_kb_id: cfg.value.ima_kb_id,
      feishu_app_id: cfg.value.feishu_app_id,
      feishu_app_secret: cfg.value.feishu_app_secret,
      feishu_space_ids: cfg.value.feishu_space_ids
    });
    applyMsg.value = r.message || '已生效';
    emit('applied');
  } catch (e) {
    applyMsg.value = '⚠ ' + (e.message || '应用失败');
  } finally {
    applying.value = false;
  }
}

// 面板打开时拉一次后端真实配置
watch(() => props.open, (v) => { if (v) loadCfg(); });
</script>

<template>
  <Teleport to="body">
    <div v-if="open" class="cfg-mask" @click.self="emit('update:open', false)">
      <div class="cfg-panel">
        <div class="cfg-head">
          <span>⚙️ 模型与知识库配置</span>
          <button class="x" @click="emit('update:open', false)">✕</button>
        </div>

        <!-- 生效状态对比：后端真实 vs 前端预设 -->
        <div class="live">
          <div class="live-col">
            <div class="live-h">后端真实生效</div>
            <div class="live-row"><span>引擎</span><b>{{ llmInfo.mode || '—' }}</b></div>
            <div class="live-row"><span>模型</span><b>{{ llmInfo.llm_model || '—' }}</b></div>
            <div class="live-row"><span>知识库</span><b>{{ llmInfo.kb_source || 'local' }}</b></div>
          </div>
          <div class="live-col preset" :class="{ flash: presetFlash }">
            <div class="live-h">前端预设 <span class="preset-tag">本机</span></div>
            <div class="live-row"><span>引擎</span><b>{{ cfg.provider }}</b></div>
            <div class="live-row"><span>模型</span><b>{{ cfg.model || '—' }}</b></div>
            <div class="live-row"><span>知识库</span><b>{{ cfg.kb_source }}</b></div>
          </div>
        </div>
        <p class="cfg-note">
          右侧为前端预设（保存到本机浏览器）；左侧为后端当前真实生效值。<b>预设要真正生效，需在后端配置对应环境变量并重启服务</b>
          （如 <code>OLLAMA_LLM_MODEL</code> / <code>LLM_PROVIDER</code> / <code>KB_SOURCE</code> 等）。两侧不一致时，以左侧为准。
        </p>

        <div class="cards">
          <!-- 卡片：对话模型 -->
          <div class="card">
            <div class="card-title">🤖 对话模型</div>
            <div class="chips">
              <button v-for="p in ['ollama','api','offline']" :key="p"
                      class="chip" :class="{ on: cfg.provider === p }" @click="cfg.provider = p">
                {{ p === 'ollama' ? '本地 Ollama' : p === 'api' ? 'OpenAI 兼容' : '离线' }}
              </button>
            </div>
            <label>Base URL
              <input v-model="cfg.base" placeholder="http://localhost:11434" :disabled="cfg.provider === 'offline'" />
            </label>
            <label>对话模型
              <input v-model="cfg.model" placeholder="qwen3.6" :disabled="cfg.provider === 'offline'" />
            </label>
            <label>Embedding 模型
              <input v-model="cfg.embed_model" placeholder="qwen3.6" :disabled="cfg.provider === 'offline'" />
            </label>
            <label v-if="cfg.provider === 'api'">API Key
              <div class="pw">
                <input v-model="cfg.api_key" :type="showKey ? 'text' : 'password'" placeholder="sk-..." />
                <button class="eye" @click="showKey = !showKey">{{ showKey ? '🙈' : '👁' }}</button>
              </div>
            </label>
          </div>

          <!-- 卡片：知识库数据源 -->
          <div class="card">
            <div class="card-title">📚 知识库数据源</div>
            <div class="chips">
              <button v-for="k in ['local','ima','feishu']" :key="k"
                      class="chip" :class="{ on: cfg.kb_source === k }" @click="cfg.kb_source = k">
                {{ k === 'local' ? '本地库' : k === 'ima' ? 'IMA' : '飞书' }}
              </button>
            </div>

            <template v-if="cfg.kb_source === 'ima'">
              <label>IMA Client ID
                <input v-model="cfg.ima_client_id" placeholder="IMA_OPENAPI_CLIENTID" />
              </label>
              <label>IMA API Key
                <div class="pw">
                  <input v-model="cfg.ima_api_key" :type="showIma ? 'text' : 'password'" placeholder="IMA_OPENAPI_APIKEY" />
                  <button class="eye" @click="showIma = !showIma">{{ showIma ? '🙈' : '👁' }}</button>
                </div>
              </label>
              <label>IMA 知识库 ID
                <input v-model="cfg.ima_kb_id" placeholder="IMA_KB_ID" />
              </label>
            </template>

            <template v-if="cfg.kb_source === 'feishu'">
              <label>飞书 App ID
                <input v-model="cfg.feishu_app_id" placeholder="FEISHU_APP_ID" />
              </label>
              <label>飞书 App Secret
                <div class="pw">
                  <input v-model="cfg.feishu_app_secret" :type="showFs ? 'text' : 'password'" placeholder="FEISHU_APP_SECRET" />
                  <button class="eye" @click="showFs = !showFs">{{ showFs ? '🙈' : '👁' }}</button>
                </div>
              </label>
              <label>飞书空间 ID（逗号分隔）
                <input v-model="cfg.feishu_space_ids" placeholder="FEISHU_SPACE_IDS" />
              </label>
            </template>

            <p v-if="cfg.kb_source === 'local'" class="cfg-note" style="margin:6px 0 0">
              本地向量库零配置即用；切换 IMA / 飞书需在后端配置对应环境变量后重启。
            </p>
          </div>
        </div>

        <button class="save" @click="saveCfg">保存配置到本地</button>
        <span v-if="cfgSaved" class="saved">✓ 已保存到本机</span>

        <div class="apply-row">
          <button class="apply" :disabled="applying" @click="applyToBackend">
            {{ applying ? '应用并重启服务…' : '⚡ 应用配置并生效（管理员）' }}
          </button>
        </div>
        <p v-if="applyMsg" class="apply-msg">{{ applyMsg }}</p>
        <p class="cfg-note" style="margin-top:8px">
          点「应用并生效」会把当前预设写入后端运行时配置并重载，<b>无需手动改环境变量或重启进程</b>；重启后端仍保留。仅管理员可用。
        </p>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.cfg-mask { position: fixed; inset: 0; z-index: 9998; background: rgba(2,6,23,0.55); display: flex; align-items: center; justify-content: center; backdrop-filter: blur(2px); padding: 24px; }
.cfg-panel { width: 1000px; max-width: calc(100vw - 32px); max-height: 88vh; overflow-y: auto; background: rgba(15,23,42,0.97); border: 1px solid rgba(34,211,238,0.3); border-radius: 16px; padding: 22px; color: #e2e8f0; box-shadow: 0 20px 60px rgba(0,0,0,0.6); }
.cfg-head { display: flex; justify-content: space-between; align-items: center; font-weight: 700; font-size: 15px; margin-bottom: 14px; }
.cfg-head .x { background: none; border: 0; color: #94a3b8; cursor: pointer; font-size: 18px; line-height: 1; }
.cfg-head .x:hover { color: #f1f5f9; }
.cfg-note { font-size: 12px; color: #94a3b8; line-height: 1.6; margin: 0 0 12px; }
.cfg-note code { color: #22d3ee; background: rgba(34,211,238,0.1); padding: 1px 5px; border-radius: 4px; font-size: 11px; }
.cfg-note b { color: #fbbf24; }
.live { display: flex; gap: 12px; margin-bottom: 12px; }
.live-col { flex: 1; background: rgba(34,211,238,0.06); border: 1px solid rgba(34,211,238,0.2); border-radius: 10px; padding: 10px 12px; }
.live-col.preset { background: rgba(251,191,36,0.06); border-color: rgba(251,191,36,0.25); }
.live-h { font-size: 11px; font-weight: 700; color: #94a3b8; margin-bottom: 6px; letter-spacing: .3px; }
.live-col.preset .live-h { color: #fbbf24; }
.preset-tag { font-size: 10px; font-weight: 600; color: #fbbf24; background: rgba(251,191,36,0.15); border: 1px solid rgba(251,191,36,0.35); border-radius: 5px; padding: 0 5px; margin-left: 4px; }
.live-row { display: flex; justify-content: space-between; align-items: center; font-size: 12px; padding: 2px 0; }
.live-row span { color: #94a3b8; }
.live-row b { color: #22d3ee; font-weight: 600; }
.live-col.preset .live-row b { color: #fcd34d; }
.live-col.preset.flash { animation: presetFlash .4s ease 2; }
@keyframes presetFlash { 0%,100% { box-shadow: 0 0 0 0 rgba(251,191,36,0); } 50% { box-shadow: 0 0 0 2px rgba(251,191,36,0.6); } }
.cards { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 14px; margin-bottom: 12px; }
.card-title { font-size: 13px; font-weight: 700; color: #e2e8f0; margin-bottom: 10px; }
.chips { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.chip { flex: 1; min-width: 72px; padding: 8px 6px; border-radius: 9px; border: 1px solid rgba(255,255,255,0.16); background: rgba(2,6,23,0.5); color: #cbd5e1; cursor: pointer; font-size: 12px; font-weight: 600; transition: all .15s; }
.chip:hover { border-color: rgba(34,211,238,0.5); }
.chip.on { background: linear-gradient(135deg, rgba(6,182,212,0.25), rgba(59,130,246,0.25)); border-color: #22d3ee; color: #e2f6ff; box-shadow: 0 0 0 1px rgba(34,211,238,0.3) inset; }
.cfg-panel label { display: block; font-size: 12px; color: #cbd5e1; margin: 9px 0 3px; }
.cfg-panel input { width: 100%; padding: 9px 11px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.18); background: rgba(2,6,23,0.7); color: #f1f5f9; outline: none; box-sizing: border-box; font-size: 13px; }
.cfg-panel input:focus { border-color: #22d3ee; box-shadow: 0 0 0 2px rgba(34,211,238,0.18); }
.cfg-panel input:disabled { opacity: .45; cursor: not-allowed; }
.pw { position: relative; display: flex; align-items: center; }
.pw input { padding-right: 40px; }
.pw .eye { position: absolute; right: 6px; background: none; border: 0; cursor: pointer; font-size: 14px; padding: 4px; line-height: 1; }
.save { margin-top: 4px; width: 100%; padding: 11px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #06b6d4, #3b82f6); color: #fff; font-weight: 600; cursor: pointer; font-size: 14px; }
.save:hover { filter: brightness(1.08); }
.saved { display: block; text-align: center; margin-top: 8px; color: #34d399; font-size: 12px; }
.apply-row { margin-top: 12px; }
.apply { width: 100%; padding: 11px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #f59e0b, #ef4444); color: #fff; font-weight: 700; cursor: pointer; font-size: 14px; }
.apply:hover { filter: brightness(1.08); }
.apply:disabled { opacity: .6; cursor: not-allowed; }
.apply-msg { margin-top: 8px; font-size: 12px; color: #34d399; }
</style>
