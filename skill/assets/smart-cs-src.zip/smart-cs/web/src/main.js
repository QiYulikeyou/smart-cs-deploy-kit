import { createApp } from 'vue';
import App from './App.vue';

// 设计系统 token + 全局基础样式（必须在 App 之前引入）
import './styles/tokens.css';

createApp(App).mount('#app');
