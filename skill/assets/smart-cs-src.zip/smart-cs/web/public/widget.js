/* ============================================================
 * 智能客服挂件 · 配置驱动版 (widget.js)
 * ------------------------------------------------------------
 * 用法：在页面 </body> 前引入即可，样式与 DOM 由本脚本自行注入。
 *   <script src="/cs/widget.js"></script>
 *
 * 官网推荐做法（避免重新部署丢失挂件）：
 *   由 Nginx sub_filter 自动注入上面这一行，无需改动官网源码。
 *
 * 可覆盖项（在引入本脚本前定义 window.SCS_*）：
 *   SCS_API    后端地址，跨域部署时必填，如 'https://cs.example.com'
 *   SCS_SITE   站点标识（暂未启用多站点差异，预留）
 *
 * v2 变更：外观文案 / 主题色 / 预置问题全部改为启动时向后端拉取，
 *         不再写死在本文件里 —— 复制到新客户只需改后台「部署配置」，
 *         无需重新打包或替换挂件。
 *         拉取失败时使用兜底默认值，保证挂件永远可用。
 * ============================================================ */
(function () {
  // 幂等：已注入则直接返回，避免重复渲染
  if (document.getElementById('scs-fab')) return;

  var API = window.SCS_API || '';
  var SITE = window.SCS_SITE || '';

  // 同源部署时（未设置 SCS_API）统一走 /cs 前缀，由 Nginx 反代剥离 /cs 转发到后端 :3100；
  // 跨域部署时（已设置 SCS_API）保持原样，路径由对端决定。
  function apiPath(p) { return (API ? API : '/cs') + p; }

  // 兜底默认值：仅在配置接口不可用时使用，保证挂件不白屏
  var DEFAULTS = {
    title: '在线客服',
    greeting: '您好，很高兴为您服务 👋\n请问有什么可以帮您？',
    placeholder: '输入您的问题，回车发送',
    powered: 'AI 智能客服 · 7×24 在线',
    accentFrom: '#06b6d4',
    accentTo: '#3b82f6',
    siteToken: '',
    presetQuestions: []
  };

  function css(c) {
    return [
      '#scs-fab {',
      '  position: fixed; right: 20px; bottom: 20px; z-index: 2147483000;',
      '  width: 56px; height: 56px; border-radius: 50%;',
      '  background: linear-gradient(135deg, ' + c.accentFrom + ', ' + c.accentTo + ');',
      '  color: #fff; font-size: 24px; border: none; cursor: pointer;',
      '  box-shadow: 0 8px 24px ' + hexA(c.accentFrom, 0.45) + ';',
      '}',
      '#scs-fab:hover { filter: brightness(1.08); }',
      '#scs-panel {',
      '  position: fixed; right: 20px; bottom: 88px; z-index: 2147483000;',
      '  width: 360px; max-width: calc(100vw - 32px); height: 520px; max-height: calc(100vh - 120px);',
      '  background: #1e293b; border: 1px solid ' + hexA(c.accentFrom, 0.3) + '; border-radius: 16px;',
      '  display: flex; flex-direction: column; overflow: hidden;',
      '  box-shadow: 0 20px 60px rgba(0,0,0,0.5); animation: scs-in .2s ease;',
      '}',
      '@keyframes scs-in { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }',
      '.scs-head { display: flex; align-items: center; justify-content: space-between;',
      '  padding: 12px 16px; background: ' + hexA(c.accentFrom, 0.08) + '; border-bottom: 1px solid rgba(255,255,255,0.08); }',
      '.scs-head .t { font-weight: 700; font-size: 14px; color: #e2e8f0; }',
      '.scs-head .x { background: none; border: 0; color: #94a3b8; cursor: pointer; font-size: 18px; }',
      '.scs-body { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 10px; }',
      '.scs-msg { max-width: 86%; padding: 9px 13px; border-radius: 12px; font-size: 13px; line-height: 1.55;',
      '  word-break: break-word; white-space: pre-wrap; color: #e2e8f0; }',
      '.scs-msg.user { align-self: flex-end; background: linear-gradient(135deg, ' + c.accentFrom + ', ' + c.accentTo + '); color: #fff; border-bottom-right-radius: 4px; }',
      '.scs-msg.bot { align-self: flex-start; background: #243244; border: 1px solid rgba(255,255,255,0.08); border-bottom-left-radius: 4px; }',
      '.scs-preset { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 14px 10px; }',
      '.scs-preset button { background: rgba(255,255,255,0.06); border: 1px solid ' + hexA(c.accentFrom, 0.28) + ';',
      '  color: #cbd5e1; font-size: 12px; padding: 5px 11px; border-radius: 999px; cursor: pointer;',
      '  font-family: inherit; transition: all .15s; }',
      '.scs-preset button:hover { background: ' + hexA(c.accentFrom, 0.16) + '; color: #fff; }',
      '.scs-inputbar { display: flex; gap: 8px; padding: 12px; border-top: 1px solid rgba(255,255,255,0.1); }',
      '.scs-inputbar input { flex: 1; padding: 10px 12px; border-radius: 9px; border: 1px solid rgba(255,255,255,0.18);',
      '  background: #0f172a; color: #f1f5f9; outline: none; font-size: 13px; }',
      '.scs-inputbar input:focus { border-color: ' + c.accentFrom + '; }',
      '.scs-inputbar button { background: linear-gradient(135deg, ' + c.accentFrom + ', ' + c.accentTo + '); color: #fff; border: 0;',
      '  padding: 0 16px; border-radius: 9px; cursor: pointer; font-weight: 600; }',
      '.scs-msg strong { font-weight: 700; }',
      '.scs-msg code { background: rgba(255,255,255,0.1); padding: 1px 5px; border-radius: 4px; font-size: 12px; }',
      '.scs-typing { align-self: flex-start; color: #94a3b8; font-style: italic; font-size: 12px; }',
      '.scs-powered { text-align: center; font-size: 10px; color: #94a3b8; padding: 4px; }'
    ].join('\n');
  }

  // #rrggbb + alpha → rgba()，用于把主题色转成半透明
  function hexA(hex, a) {
    var h = String(hex || '').replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return 'rgba(6,182,212,' + a + ')';
    return 'rgba(' + parseInt(h.slice(0, 2), 16) + ',' + parseInt(h.slice(2, 4), 16) + ',' + parseInt(h.slice(4, 6), 16) + ',' + a + ')';
  }

  var cfg = null;
  var body, input, fab, panel, presetBox;
  var history = [];

  function mount(c) {
    cfg = c;
    var style = document.createElement('style');
    style.id = 'scs-widget-style';
    style.textContent = css(c);
    document.head.appendChild(style);

    document.body.insertAdjacentHTML('beforeend', [
      '<button id="scs-fab" title="' + c.title + '">💬</button>',
      '<div id="scs-panel" style="display:none">',
      '  <div class="scs-head">',
      '    <span class="t">💬 ' + c.title + '</span>',
      '    <button class="x" id="scs-close">✕</button>',
      '  </div>',
      '  <div class="scs-body" id="scs-body">',
      '    <div class="scs-msg bot"></div>',
      '  </div>',
      '  <div class="scs-preset" id="scs-preset"></div>',
      '  <div class="scs-inputbar">',
      '    <input id="scs-input" placeholder="' + c.placeholder + '" />',
      '    <button id="scs-send">发送</button>',
      '  </div>',
      '  <div class="scs-powered">' + (c.powered || '') + '</div>',
      '</div>'
    ].join('\n'));

    body = document.getElementById('scs-body');
    input = document.getElementById('scs-input');
    fab = document.getElementById('scs-fab');
    panel = document.getElementById('scs-panel');
    presetBox = document.getElementById('scs-preset');

    body.firstChild.textContent = c.greeting;
    renderPresets(c.presetQuestions);

    fab.addEventListener('click', toggle);
    document.getElementById('scs-close').addEventListener('click', toggle);
    document.getElementById('scs-send').addEventListener('click', send);
    input.addEventListener('keyup', function (e) { if (e.key === 'Enter') send(); });
  }

  function toggle() {
    panel.style.display = panel.style.display === 'none' ? 'flex' : 'none';
    if (panel.style.display === 'flex') input.focus();
  }

  // 预置问题只在首轮（还没提问过）展示，避免打扰已经进入正题的访客
  function renderPresets(list) {
    if (!presetBox || !list || !list.length) return;
    presetBox.innerHTML = '';
    list.forEach(function (q) {
      var b = document.createElement('button');
      b.textContent = q;
      b.addEventListener('click', function () { input.value = q; send(); });
      presetBox.appendChild(b);
    });
  }

  function hidePresets() {
    if (presetBox) presetBox.style.display = 'none';
  }

  // 访客端只呈现干净的答案正文：单独来源标签、参考知识、相似度与质检结果
  // 等内部信息不下发。统一用 textContent 渲染，天然转义、避免注入。
  function renderUser(text) {
    var d = document.createElement('div');
    d.className = 'scs-msg user';
    d.textContent = text;
    body.appendChild(d);
    scroll();
  }

  // 安全富文本渲染：先完整转义 HTML，再把常见 Markdown 标记转成可读样式，
  // 避免客户看到 **加粗**、# 标题符等原始标记，同时杜绝 HTML 注入。
  function renderRich(el, text) {
    var esc = String(text == null ? '' : text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    el.innerHTML = esc
      .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`\n]+)`/g, '<code>$1</code>')
      .replace(/(^|\n)\s{0,3}#{1,6}\s*/g, '$1');
  }

  function renderBot(r) {
    var d = document.createElement('div');
    d.className = 'scs-msg bot';
    var text = r.reply || '抱歉，我没太理解您的问题，方便换个说法或补充一点细节吗？';
    if (text.indexOf('**') > -1 || text.indexOf('`') > -1 || /(^|\n)\s{0,3}#{1,6}\s/.test(text)) {
      renderRich(d, text);
    } else {
      d.textContent = text;
    }
    body.appendChild(d);
    scroll();
  }

  function scroll() { body.scrollTop = body.scrollHeight; }

  function send() {
    var text = input.value.trim();
    if (!text) return;
    input.value = '';
    hidePresets();
    renderUser(text);
    var typing = document.createElement('div');
    typing.className = 'scs-typing';
    typing.textContent = '正在为您解答…';
    body.appendChild(typing);
    scroll();

    var payload = { text: text, history: history };
    if (cfg && cfg.siteToken) payload.site_token = cfg.siteToken;
    if (SITE) payload.site_id = SITE;

    fetch(apiPath('/api/qa/public-chat'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (res) { return res.json(); }).then(function (j) {
      if (typing.parentNode) body.removeChild(typing);
      // 后端错误信息对客户不透明，统一给友好提示
      if (j.error) {
        renderBot({ reply: '抱歉，服务暂时有点忙，请稍后再试～' });
        return;
      }
      history.push({ role: 'user', text: text });
      history.push({ role: 'assistant', text: j.reply || '' });
      history = history.slice(-6);
      renderBot(j);
    }).catch(function () {
      if (typing.parentNode) body.removeChild(typing);
      renderBot({ reply: '抱歉，网络似乎不太稳定，请稍后再试～' });
    });
  }

  // 先拉配置再渲染：拿不到就用兜底值，保证挂件始终可用
  var url = apiPath('/api/deploy/widget-config') + (SITE ? '?site=' + encodeURIComponent(SITE) : '');
  fetch(url)
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (j) {
      mount(Object.assign({}, DEFAULTS, j || {}));
    })
    .catch(function () {
      mount(Object.assign({}, DEFAULTS));
    });
})();
