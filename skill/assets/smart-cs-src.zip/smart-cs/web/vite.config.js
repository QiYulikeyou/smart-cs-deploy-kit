import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  base: process.env.VITE_BASE || '/',
  server: {
    port: 5273,
    proxy: {
      '/api': 'http://localhost:3200'
    }
  },
  build: {
    outDir: 'dist',
    chunkSizeWarningLimit: 800
  }
});
