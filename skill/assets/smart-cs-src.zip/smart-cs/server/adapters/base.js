// server/adapters/base.js
// 电商适配器抽象基类：所有平台适配器（Amazon / Tumi / 未来扩展）继承本类，
// 对外暴露统一的「意图识别 + 实时数据获取」接口，供 doChat 在调用 LLM 前注入真实业务数据，
// 让 AI 回复基于订单/物流/退货/商品等实时信息，而非纯知识库泛化内容。

export const COMMERCE_INTENTS = {
  ORDER: 'order', // 查订单
  TRACKING: 'tracking', // 查物流
  RETURN: 'return', // 退货/换货
  PRODUCT: 'product' // 查商品
};

export class BaseCommerceAdapter {
  constructor(config = {}) {
    this.type = config.type || 'generic';
    this.name = config.name || 'Generic';
    // sandbox 默认开启：无凭证时返回 mock 数据，便于联调与演示；
    // 生产环境设置 sandbox=false 且注入真实凭证后走真实 API。
    this.sandbox = config.sandbox !== false;
    this.config = config || {};
  }

  // 凭证是否就绪（生产模式需要，子类覆盖）
  isConfigured() {
    return false;
  }

  // 意图识别：根据用户输入文本返回意图类型或 null。
  // 通用关键词兜底，子类可用更精准的平台术语覆盖。
  detectIntent(text) {
    const t = text || '';
    if (/订单|order|下单|购买记录|买了什么|查一下我的单/.test(t)) return COMMERCE_INTENTS.ORDER;
    if (/物流|快递|发货|配送|tracking|ship|到哪|寄|运单|单号/.test(t)) return COMMERCE_INTENTS.TRACKING;
    if (/退货|退款|换货|return|refund|退掉|取消订单/.test(t)) return COMMERCE_INTENTS.RETURN;
    if (/这款|商品|产品|product|有没有|卖吗|规格|库存|多少钱/.test(t)) return COMMERCE_INTENTS.PRODUCT;
    return null;
  }

  // 从文本抽取订单号/物流单号（通用兜底，子类应覆盖为平台专属格式）
  extractOrderId(text) {
    const m = (text || '').match(/(?:订单|order|no|单号|运单)?[:\s#]*([A-Za-z0-9][A-Za-z0-9\-]{5,})/i);
    return m ? m[1] : null;
  }

  // —— 各业务方法：返回结构化数据；子类必须实现（sandbox 或真实） ——
  async getOrder(/* orderId */) {
    throw new Error('getOrder 未实现');
  }
  async getTracking(/* orderIdOrTrackingNo */) {
    throw new Error('getTracking 未实现');
  }
  async getReturnPolicy() {
    throw new Error('getReturnPolicy 未实现');
  }
  async createReturn(/* orderId */) {
    throw new Error('createReturn 未实现');
  }
  async getProduct(/* query */) {
    throw new Error('getProduct 未实现');
  }

  // 核心入口：根据文本解析意图并拉取实时数据，返回可注入 LLM 的 context 片段。
  // 返回 { intent, data, context } 或 null（未命中电商意图）。
  async resolve(text, ctx = {}) {
    const intent = this.detectIntent(text);
    if (!intent) return null;

    let data = null;
    try {
      if (intent === COMMERCE_INTENTS.ORDER) {
        const oid = this.extractOrderId(text) || ctx.orderId;
        data = oid ? await this.getOrder(oid) : { hint: '请提供订单号以便查询' };
      } else if (intent === COMMERCE_INTENTS.TRACKING) {
        const oid = this.extractOrderId(text) || ctx.orderId;
        data = oid ? await this.getTracking(oid) : { hint: '请提供订单号或物流单号' };
      } else if (intent === COMMERCE_INTENTS.RETURN) {
        data = await this.getReturnPolicy();
      } else if (intent === COMMERCE_INTENTS.PRODUCT) {
        data = await this.getProduct(text);
      }
    } catch (e) {
      data = { error: String((e && e.message) || e) };
    }

    const context = this.buildContext(intent, data);
    return { intent, data, context };
  }

  // 把结构化数据转成自然语言指令，注入 LLM，使回复贴合真实数据。
  buildContext(intent, data) {
    if (!data) return '';
    if (data.error) {
      return `【${this.name}实时数据获取失败】${data.error}（请礼貌告知用户暂时无法查询，并建议转人工客服）`;
    }
    if (data.hint) return `【${this.name}提示】${data.hint}`;

    const L = [];
    L.push(`【${this.name}实时数据 · 类型:${intent}】`);
    if (intent === COMMERCE_INTENTS.ORDER && data.orderId) {
      L.push(`订单号：${data.orderId}`);
      L.push(`状态：${data.status}`);
      if (data.purchaseDate) L.push(`下单时间：${data.purchaseDate}`);
      if (Array.isArray(data.items) && data.items.length) {
        L.push('商品：' + data.items.map((i) => `${i.title} x${i.qty}`).join('、'));
      }
      if (data.total != null) L.push(`金额：${data.currency || ''} ${data.total}`);
      if (data.estimatedDelivery) L.push(`预计送达：${data.estimatedDelivery}`);
    } else if (intent === COMMERCE_INTENTS.TRACKING && data.trackingNo) {
      L.push(`物流单号：${data.trackingNo}`);
      if (data.carrier) L.push(`承运商：${data.carrier}`);
      if (data.status) L.push(`状态：${data.status}`);
      if (data.latest) L.push(`最新轨迹：${data.latest}`);
    } else if (intent === COMMERCE_INTENTS.RETURN) {
      if (data.policy) L.push(`退货政策：${data.policy}`);
      if (data.window != null) L.push(`时效：${data.window}天`);
      if (Array.isArray(data.steps) && data.steps.length) L.push('流程：' + data.steps.join(' → '));
    } else if (intent === COMMERCE_INTENTS.PRODUCT) {
      if (data.title) L.push(`商品：${data.title}`);
      if (data.price != null) L.push(`价格：${data.currency || ''} ${data.price}`);
      if (data.spec) L.push(`规格：${data.spec}`);
      if (data.stock) L.push(`库存：${data.stock}`);
    } else {
      L.push(JSON.stringify(data, null, 2));
    }
    return L.join('\n');
  }
}
