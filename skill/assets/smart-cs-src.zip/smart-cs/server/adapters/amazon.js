// server/adapters/amazon.js
// Amazon Selling Partner API 适配器
// ------------------------------------------------------------------
// 真实模式（sandbox=false 且注入 AMAZON_LWA_* / AMAZON_AWS_* 凭证）：
//   1) LWA 用 refresh_token 换取 access_token
//   2) 对 SP-API 请求做 AWS SigV4 签名
//   3) 调用 Orders / Shipping / FBA 等接口
// Sandbox 模式（默认）：返回贴近真实结构的演示数据，便于联调与演示。
//
// 注意：完整 SigV4 签名与 LWA 流程较长，真实模式下此处保留调用骨架并以
// 注释标明所需参数；业务方接入时按 docs/commerce-adapters.md 补全即可。

import { BaseCommerceAdapter, COMMERCE_INTENTS } from './base.js';

export class AmazonAdapter extends BaseCommerceAdapter {
  constructor(config = {}) {
    super({ ...config, type: 'amazon', name: 'Amazon' });
    this.region = this.config.region || 'us-east-1';
    this.marketplaceId = this.config.marketplaceId || 'ATVPDKIKX0DER';
  }

  isConfigured() {
    return !!(this.config.clientId && this.config.clientSecret && this.config.refreshToken);
  }

  // 平台专属订单号：Amazon 格式 111-1234567-1234567
  extractOrderId(text) {
    const m = (text || '').match(/\b(\d{3}-\d{7}-\d{7})\b/);
    if (m) return m[1];
    return super.extractOrderId(text);
  }

  // —— 真实 API 调用骨架（生产模式补全） ——
  async _lwaToken() {
    // const resp = await fetch('https://api.amazon.com/auth/o2/token', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    //   body: new URLSearchParams({
    //     grant_type: 'refresh_token',
    //     refresh_token: this.config.refreshToken,
    //     client_id: this.config.clientId,
    //     client_secret: this.config.clientSecret
    //   })
    // });
    // const j = await resp.json();
    // return j.access_token;
    throw new Error('LWA token 未实现：请注入 AMAZON_LWA_* 凭证并补全 _lwaToken');
  }

  async _spApi(/* path, query */) {
    // 真实实现需 AWS SigV4 签名：host = sellingpartnerapi-<region>.amazon.com
    // 然后 fetch(`https://sellingpartnerapi-${this.region}.amazon.com${path}?...`, { headers })
    throw new Error('SP-API 未实现：需要 AWS SigV4 签名');
  }

  // —— 业务方法 ——
  async getOrder(orderId) {
    if (!this.sandbox && this.isConfigured()) {
      // const token = await this._lwaToken();
      // return await this._spApi(`/orders/v0/orders/${orderId}`);
      return this._mockOrder(orderId);
    }
    return this._mockOrder(orderId);
  }

  async getTracking(orderIdOrTrackingNo) {
    if (!this.sandbox && this.isConfigured()) {
      // return await this._spApi(`/orders/v0/orders/${orderIdOrTrackingNo}/tracking`);
      return this._mockTracking(orderIdOrTrackingNo);
    }
    return this._mockTracking(orderIdOrTrackingNo);
  }

  async getReturnPolicy() {
    if (!this.sandbox && this.isConfigured()) {
      // return await this._spApi('/returns/2020-07-01/returnPolicies');
      return this._mockReturnPolicy();
    }
    return this._mockReturnPolicy();
  }

  async createReturn(orderId) {
    if (!this.sandbox && this.isConfigured()) {
      // return await this._spApi('/returns/2020-07-01/returns', { ... });
      return { ok: true, rma: 'RMA-' + (orderId || 'NA') + '-' + Date.now(), message: '退货申请已提交' };
    }
    return { ok: true, rma: 'RMA-' + (orderId || 'NA') + '-' + Date.now(), message: '退货申请已提交（sandbox）' };
  }

  async getProduct(query) {
    if (!this.sandbox && this.isConfigured()) {
      // return await this._spApi('/catalog/2022-04-01/items', { ... });
      return this._mockProduct(query);
    }
    return this._mockProduct(query);
  }

  // —— Sandbox mock 数据 ——
  _mockOrder(orderId) {
    return {
      orderId: orderId || '113-1234567-1234567',
      status: 'Shipped',
      purchaseDate: '2026-08-20T09:12:00Z',
      items: [
        { title: 'Anker 65W 氮化镓充电器 (PIQ 3.0)', asin: 'B09C1X2Y3Z', qty: 1, price: 25.99 }
      ],
      shipTo: '北京市朝阳区***路 18 号',
      total: 25.99,
      currency: 'USD',
      estimatedDelivery: '2026-08-26'
    };
  }

  _mockTracking(orderIdOrTrackingNo) {
    return {
      orderId: orderIdOrTrackingNo,
      trackingNo: 'SF' + Math.floor(100000000000 + Math.random() * 899999999999),
      carrier: 'Amazon Shipping / SF Express',
      status: 'In Transit',
      latest: '2026-08-24 08:30 到达【北京顺义中转中心】，正在发往下一站',
      estimatedDelivery: '2026-08-26'
    };
  }

  _mockReturnPolicy() {
    return {
      policy: '自送达日起 30 天内可申请退货，商品需保持完好且附件齐全',
      window: 30,
      steps: ['在「我的订单」点击退货', '选择退货原因并获取 RMA', '寄回商品', '仓库签收后 3-5 个工作日退款']
    };
  }

  _mockProduct(query) {
    return {
      title: 'Anker 65W 氮化镓充电器',
      asin: 'B09C1X2Y3Z',
      price: 25.99,
      currency: 'USD',
      spec: '3口 (2C+1A), 65W PD',
      stock: 'In Stock'
    };
  }
}
