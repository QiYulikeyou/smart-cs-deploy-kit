// server/adapters/index.js
// 适配器注册表：根据站点在 site_tokens.adapter 配置的适配器类型返回对应实例。
import { BaseCommerceAdapter, COMMERCE_INTENTS } from './base.js';
import { adaptersConfig } from './config.js';
import { AmazonAdapter } from './amazon.js';
import { TumiAdapter } from './tumi.js';

// 新增平台在此注册：type -> Adapter 类
const registry = {
  amazon: AmazonAdapter,
  tumi: TumiAdapter
};

// 实例缓存（配置不变则复用，避免重复构造）
const instances = new Map();

// 列出所有已注册适配器及其状态（供 /api/commerce/adapters 使用）
export function listAdapters() {
  return Object.keys(registry).map((type) => {
    const Cls = registry[type];
    const cfg = adaptersConfig[type] || {};
    const inst = new Cls(cfg);
    return {
      type,
      name: inst.name,
      sandbox: inst.sandbox,
      configured: inst.isConfigured()
    };
  });
}

// 根据 adapter 类型创建/取回实例（site_tokens.adapter 字段对应）
export function getAdapter(type) {
  if (!type || !registry[type]) return null;
  if (!instances.has(type)) {
    const Cls = registry[type];
    const cfg = adaptersConfig[type] || {};
    instances.set(type, new Cls(cfg));
  }
  return instances.get(type);
}

export { BaseCommerceAdapter, COMMERCE_INTENTS };
