// server/adapters/config.js
// 从环境变量加载各平台电商适配器凭证与 sandbox 开关。
// 凭证不入库，避免明文泄露；生产环境请通过环境变量 / .env 注入（见 docs/commerce-adapters.md）。
// 默认全部 sandbox=true，无凭证即可返回 mock 数据用于联调演示。

function bool(v, def) {
  if (v === undefined || v === null || v === '') return def;
  return /^(1|true|yes|on)$/i.test(String(v).trim());
}

export const adaptersConfig = {
  amazon: {
    type: 'amazon',
    name: 'Amazon',
    sandbox: bool(process.env.AMAZON_SANDBOX, true),
    // LWA (Login with Amazon) 凭证
    clientId: process.env.AMAZON_LWA_CLIENT_ID || '',
    clientSecret: process.env.AMAZON_LWA_CLIENT_SECRET || '',
    refreshToken: process.env.AMAZON_LWA_REFRESH_TOKEN || '',
    // AWS SigV4 凭证
    awsAccessKey: process.env.AMAZON_AWS_ACCESS_KEY || '',
    awsSecretKey: process.env.AMAZON_AWS_SECRET_KEY || '',
    region: process.env.AMAZON_REGION || 'us-east-1',
    marketplaceId: process.env.AMAZON_MARKETPLACE_ID || 'ATVPDKIKX0DER'
  },
  tumi: {
    type: 'tumi',
    name: 'Tumi',
    sandbox: bool(process.env.TUMI_SANDBOX, true),
    baseUrl: process.env.TUMI_API_BASE_URL || 'https://api.tumi.com/v1',
    apiKey: process.env.TUMI_API_KEY || ''
  }
};

export function getAdapterConfig(type) {
  return adaptersConfig[type] || null;
}
