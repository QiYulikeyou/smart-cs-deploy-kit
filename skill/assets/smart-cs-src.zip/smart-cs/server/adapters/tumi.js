// server/adapters/tumi.js
// Tumi 品牌电商适配器
// ------------------------------------------------------------------
// Tumi 作为品牌方，通常提供自有 REST API（订单/物流/退货/商品），采用 API Key 认证。
// 真实模式（sandbox=false 且注入 TUMI_API_BASE_URL + TUMI_API_KEY）：
//   以 Authorization: Bearer <apiKey> 调用 {baseUrl}/orders、/tracking 等接口。
// Sandbox 模式（默认）：返回演示数据，便于联调与演示。
//
// 若 Tumi 实际通过某电商平台（如官方商城/第三方 OM）承载交易，可在此替换 baseUrl 与路径。

import { BaseCommerceAdapter, COMMERCE_INTENTS } from './base.js';

export class TumiAdapter extends BaseCommerceAdapter {
  constructor(config = {}) {
    super({ ...config, type: 'tumi', name: 'Tumi' });
    this.baseUrl = (this.config.baseUrl || 'https://api.tumi.com/v1').replace(/\/$/, '');
    this.apiKey = this.config.apiKey || '';
  }

  isConfigured() {
    return !!(this.baseUrl && this.apiKey);
  }

  // 平台专属订单号：Tumi 演示格式 TU-XXXXXXXX
  extractOrderId(text) {
    const m = (text || '').match(/\b(TU-[\w\d]{6,})\b/i);
    if (m) return m[1].toUpperCase();
    return super.extractOrderId(text);
  }

  // —— 真实 API 调用骨架（生产模式补全） ——
  async _call(path, query = {}) {
    if (this.sandbox || !this.isConfigured()) return null; // 交给 mock
    const url = new URL(this.baseUrl + path);
    Object.entries(query).forEach(([k, v]) => url.searchParams.set(k, v));
    const resp = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' }
    });
    if (!resp.ok) throw new Error(`Tumi API ${resp.status}`);
    return resp.json();
  }

  // —— 业务方法 ——
  async getOrder(orderId) {
    const real = await this._call(`/orders/${encodeURIComponent(orderId)}`);
    return real || this._mockOrder(orderId);
  }

  async getTracking(orderIdOrTrackingNo) {
    const real = await this._call(`/tracking/${encodeURIComponent(orderIdOrTrackingNo)}`);
    return real || this._mockTracking(orderIdOrTrackingNo);
  }

  async getReturnPolicy() {
    const real = await this._call('/returns/policy');
    return real || this._mockReturnPolicy();
  }

  async createReturn(orderId) {
    const real = await this._call(`/orders/${encodeURIComponent(orderId)}/returns`, {});
    if (real) return real;
    return { ok: true, rma: 'TUMI-RMA-' + (orderId || 'NA'), message: '退货申请已提交（sandbox）' };
  }

  async getProduct(query) {
    const real = await this._call('/products/search', { q: query });
    return real || this._mockProduct(query);
  }

  // —— Sandbox mock 数据 ——
  _mockOrder(orderId) {
    return {
      orderId: orderId || 'TU-20240817',
      status: 'Delivered',
      purchaseDate: '2026-08-15T14:02:00Z',
      items: [
        { title: 'Tumi Alpha 3 商务双肩包', sku: 'TU-117315', qty: 1, price: 595.0 }
      ],
      shipTo: '上海市浦东新区***路 8 号',
      total: 595.0,
      currency: 'USD',
      estimatedDelivery: '2026-08-19'
    };
  }

  _mockTracking(orderIdOrTrackingNo) {
    return {
      orderId: orderIdOrTrackingNo,
      trackingNo: 'YT' + Math.floor(100000000000 + Math.random() * 899999999999),
      carrier: 'UPS / 圆通国际',
      status: 'Delivered',
      latest: '2026-08-19 11:05 已签收（本人签收）',
      estimatedDelivery: '2026-08-19'
    };
  }

  _mockReturnPolicy() {
    return {
      policy: 'Tumi 官方提供 2 年质保；30 天内未使用商品可退换',
      window: 30,
      steps: ['登录 Tumi 账号进入订单', '发起退换货', '预约上门取件', '质检通过后退款/换货']
    };
  }

  _mockProduct(query) {
    return {
      title: 'Tumi Alpha 3 商务双肩包',
      sku: 'TU-117315',
      price: 595.0,
      currency: 'USD',
      spec: '尼龙 / 15寸笔记本仓 / 黑色',
      stock: 'In Stock'
    };
  }
}
