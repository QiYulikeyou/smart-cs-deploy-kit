// LLM / Embedding 接入层（可插拔 provider）
//
import { getRuntimeConfig } from './runtimeConfig.js';
function getRuntimeConfigSafe() {
  try {
    return getRuntimeConfig();
  } catch {
    return {};
  }
}
//
// 三种 provider（通过环境变量 LLM_PROVIDER 选择，默认 ollama）：
//   - ollama  : 本地 Ollama（优先，零费用、数据不出本机）
//   - api     : 外接 OpenAI 兼容 API（通义/OpenAI/自建 等）
//   - offline : 离线启发式（无需任何外部服务，骨架永远能跑）
//
// 启动时会探活：若 ollama/api 配了但连不上，自动回退 offline，保证服务可用。
// 真实模型仅在「离线批处理」场景调用（建库、抽字段），实时检索也走 embedding，
// 日常运行若用 offline 则零外部调用。

// ---------- 配置 ----------
const ENV_DEFAULTS = {
  PROVIDER: (process.env.LLM_PROVIDER || 'ollama').toLowerCase(),
  OLLAMA_HOST: process.env.OLLAMA_HOST || 'http://localhost:11434',
  OLLAMA_EMBED_MODEL: process.env.OLLAMA_EMBED_MODEL || 'nomic-embed-text',
  OLLAMA_LLM_MODEL: process.env.OLLAMA_LLM_MODEL || 'qwen3.6',
  EMBED_API_BASE: process.env.EMBED_API_BASE || '',
  EMBED_API_KEY: process.env.EMBED_API_KEY || '',
  EMBED_MODEL: process.env.EMBED_MODEL || 'text-embedding-3-small',
  LLM_API_BASE: process.env.LLM_API_BASE || '',
  LLM_API_KEY: process.env.LLM_API_KEY || '',
  LLM_MODEL: process.env.LLM_MODEL || 'gpt-4o-mini'
};

function loadConfig() {
  let rt = {};
  try {
    rt = getRuntimeConfigSafe();
  } catch {
    rt = {};
  }
  // 运行时配置覆盖环境变量（仅当非空）
  return {
    PROVIDER: (rt.provider && rt.provider.trim()) || ENV_DEFAULTS.PROVIDER,
    OLLAMA_HOST: (rt.base && rt.base.trim()) || ENV_DEFAULTS.OLLAMA_HOST,
    OLLAMA_EMBED_MODEL: (rt.embed_model && rt.embed_model.trim()) || ENV_DEFAULTS.OLLAMA_EMBED_MODEL,
    OLLAMA_LLM_MODEL: (rt.model && rt.model.trim()) || ENV_DEFAULTS.OLLAMA_LLM_MODEL,
    EMBED_API_BASE: (rt.base && rt.base.trim()) || ENV_DEFAULTS.EMBED_API_BASE,
    EMBED_API_KEY: rt.api_key || ENV_DEFAULTS.EMBED_API_KEY,
    EMBED_MODEL: (rt.model && rt.model.trim()) || ENV_DEFAULTS.EMBED_MODEL,
    LLM_API_BASE: (rt.base && rt.base.trim()) || ENV_DEFAULTS.LLM_API_BASE,
    LLM_API_KEY: rt.api_key || ENV_DEFAULTS.LLM_API_KEY,
    LLM_MODEL: (rt.model && rt.model.trim()) || ENV_DEFAULTS.LLM_MODEL
  };
}

// 当前生效配置（每次 init 时刷新）
let CFG = loadConfig();

// ---------- 运行状态（initLLM 后锁定）----------
let mode = null; // 'ollama' | 'api' | 'offline'
let embedMode = null; // 'semantic' | 'offline'（语义向量 vs 离线哈希）
let embedDim = 0; // 当前生效 embedding 维度（用于跨条目一致性校验）
let initPromise = null;

async function fetchWithTimeout(url,  opts = {}, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

// ---------- 离线占位 embedding（确定性，零依赖）----------
const DIM = 256;
function tokenize(text = '') {
  const t = (text || '').toLowerCase();
  const cjk = t.match(/[一-龥]/g) || [];
  const latin = t.match(/[a-z0-9]+/g) || [];
  return [...cjk, ...latin];
}
export function offlineEmbed(text = '') {
  const vec = new Array(DIM).fill(0);
  const tokens = tokenize(text);
  if (tokens.length === 0) return vec;
  for (const tk of tokens) {
    let h = 2166136261;
    for (let i = 0; i < tk.length; i++) {
      h ^= tk.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    vec[Math.abs(h) % DIM] += 1;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
  return vec.map((v) => v / norm);
}

// ---------- 离线抽取启发式 ----------
function guessCategory(text) {
  if (/退款|退货|换货/.test(text)) return '售后-退款';
  if (/发货|物流|快递|签收/.test(text)) return '售后-物流';
  if (/怎么|如何|什么|能不能|支持/.test(text)) return '售前咨询';
  if (/投诉|差评|生气|愤怒|骗|垃圾/.test(text)) return '投诉处理';
  return '其他';
}
function offlineExtract(content) {
  const text = (content || '').trim();
  const firstLine = (text.split(/[\n。.!?！？]/)[0] ? text.split(/[\n。.!?！？]/)[0] : text).slice(0, 80);
  return {
    question: firstLine,
    solution: '',
    category: guessCategory(text),
    urgency: /紧急|立刻|马上|投诉|曝光/.test(text) ? 3 : /退款|退货|差评/.test(text) ? 2 : 1,
    confidence: 0.5
  };
}

// ---------- provider 探活 ----------
export async function initLLM() {
  if (initPromise) return initPromise;
  return reloadLLM();
}

export async function reloadLLM() {
  CFG = loadConfig();
  initPromise = (async () => {
    if (CFG.PROVIDER === 'offline') {
      mode = 'offline';
    } else if (CFG.PROVIDER === 'api') {
      if (!CFG.EMBED_API_BASE || !CFG.EMBED_API_KEY) {
        console.warn('[llm] provider=api 但缺少 EMBED_API_BASE/EMBED_API_KEY，回退 offline');
        mode = 'offline';
      } else {
        mode = 'api';
      }
    } else {
      // 默认 ollama：探活
      try {
        const r = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/tags`, {}, 2000);
        if (!r.ok) throw new Error('tags ' + r.status);
        mode = 'ollama';
      } catch (e) {
        console.warn(`[llm] Ollama 探活失败（${CFG.OLLAMA_HOST}）：${e.message}，回退 offline`);
        mode = 'offline';
      }
    }
    // 探测 embedding 能力：优先 Ollama 真实语义向量，否则离线哈希
    embedMode = 'offline';
    if (mode === 'ollama') {
      try {
        const probe = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/embeddings`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: CFG.OLLAMA_EMBED_MODEL, prompt: '__probe__' })
        }, 8000);
        if (!probe.ok) throw new Error('status ' + probe.status);
        const pj = await probe.json();
        if (!Array.isArray(pj.embedding)) throw new Error('no embedding array');
        embedDim = pj.embedding.length;
        embedMode = 'semantic';
      } catch (e) {
        console.warn(`[llm] Ollama embedding(${CFG.OLLAMA_EMBED_MODEL}) 不可用，降级离线哈希向量：${e.message}`);
        embedDim = DIM;
        embedMode = 'offline';
      }
    } else if (mode === 'api') {
      // 外接 API：若配置了 embedding 端点则探活，否则离线
      if (CFG.EMBED_API_BASE && CFG.EMBED_API_KEY) {
        try {
          const probe = await fetchWithTimeout(`${CFG.EMBED_API_BASE}/embeddings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CFG.EMBED_API_KEY}` },
            body: JSON.stringify({ model: CFG.EMBED_MODEL, input: '__probe__' })
          }, 8000);
          if (!probe.ok) throw new Error('status ' + probe.status);
          const pj = await probe.json();
          const emb = pj?.data?.[0]?.embedding;
          if (!Array.isArray(emb)) throw new Error('no embedding');
          embedDim = emb.length;
          embedMode = 'semantic';
        } catch (e) {
          console.warn(`[llm] 外接 embedding 不可用，降级离线哈希：${e.message}`);
          embedDim = DIM;
          embedMode = 'offline';
        }
      } else {
        embedDim = DIM;
      }
    } else {
      embedDim = DIM;
    }
    console.log(`[llm] provider 模式已锁定：${mode}` +
      (mode === 'ollama' ? `（embed=${CFG.OLLAMA_EMBED_MODEL}, llm=${CFG.OLLAMA_LLM_MODEL}）` :
       mode === 'api' ? `（embed=${CFG.EMBED_MODEL}, llm=${CFG.LLM_MODEL}）` : '（离线启发式）') +
      ` | embedding=${embedMode}${embedMode === 'semantic' ? '(' + embedDim + 'd)' : '(hash256)'}`);
    return mode;
  })();
  return initPromise;
}

export function getLLMMode() {
  return mode || 'pending';
}
export function getEmbedInfo() {
  return { mode: embedMode || 'pending', dim: embedDim };
}
export function getLLMInfo() {
  let base = null;
  if (mode === 'ollama') base = CFG.OLLAMA_HOST;
  else if (mode === 'api') base = CFG.LLM_API_BASE || CFG.EMBED_API_BASE || null;
  return {
    mode: mode || 'pending',
    provider: CFG.PROVIDER,
    base,
    embed_model: mode === 'ollama' ? CFG.OLLAMA_EMBED_MODEL : mode === 'api' ? CFG.EMBED_MODEL : null,
    llm_model: mode === 'ollama' ? CFG.OLLAMA_LLM_MODEL : mode === 'api' ? CFG.LLM_MODEL : null,
    embed_mode: embedMode || 'pending',
    embed_dim: embedDim
  };
}

// L2 归一化：nomic-embed-text 默认输出未归一化向量，若直接点积会被模长主导，
// 导致 cosine 分数虚高、语义排序失真。统一归一化到单位向量，使 cosine() 点积 = 真实余弦。
function normalize(vec) {
  if (!Array.isArray(vec) || vec.length === 0) return vec;
  let n = Math.sqrt(vec.reduce((s, x) => s + x * x, 0)) || 1;
  return vec.map((x) => x / n);
}

// ---------- embedding ----------
// 优先级：语义向量（Ollama / 外接 API，取决于 embedMode） → 离线哈希降级。
// embedMode 在 initLLM 时锁定；若已锁定为 offline 则直接哈希，不发无效请求。
export async function embedText(text) {
  if (!mode) await initLLM();

  // 已探测确认为离线哈希：直接本地算，零外部调用
  if (embedMode === 'offline') return offlineEmbed(text);

  try {
    if (mode === 'ollama' && embedMode === 'semantic') {
      const r = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/embeddings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: CFG.OLLAMA_EMBED_MODEL, prompt: text })
      });
      if (!r.ok) throw new Error('status ' + r.status);
      const j = await r.json();
      if (!Array.isArray(j.embedding)) throw new Error('no embedding');
      return normalize(j.embedding);
    }
    if (mode === 'api' && embedMode === 'semantic') {
      const r = await fetchWithTimeout(`${CFG.EMBED_API_BASE}/embeddings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CFG.EMBED_API_KEY}` },
        body: JSON.stringify({ model: CFG.EMBED_MODEL, input: text })
      });
      if (!r.ok) throw new Error('status ' + r.status);
      const j = await r.json();
      const emb = j?.data?.[0]?.embedding;
      if (!Array.isArray(emb)) throw new Error('no embedding');
      return normalize(emb);
    }
  } catch (e) {
    // embedding 调用失败仅本次降级为离线向量，不污染全局 embedMode
    console.warn(`[llm] embedding 调用失败，本次回退离线向量：${e.message}`);
    return offlineEmbed(text);
  }
  return offlineEmbed(text);
}

// ---------- 工单抽取 ----------
function extractPrompt(content) {
  return [
    '你是客服工单结构化抽取器。从用户消息中抽取字段，仅输出 JSON，不要多余解释。',
    'JSON 字段：',
    '  question: 用一句话概括用户的核心问题（不超过 40 字）',
    '  category: 从 [售后-退款, 售后-物流, 售前咨询, 投诉处理, 其他] 选一',
    '  urgency: 1(一般)/2(较急)/3(紧急) 的整数',
    '  solution: 给用户的建议或解决方案（无则空字符串）',
    '  confidence: 0~1 之间的置信度浮点数',
    `用户消息：${content}`
  ].join('\n');
}

function parseJSON(obj) {
  // 兼容：直接是对象 / 字符串包裹对象 / 含 ```json 代码块
  if (obj && typeof obj === 'object') return obj;
  let s = String(obj).trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const brace = s.match(/\{[\s\S]*\}/);
  if (brace) s = brace[0];
  return JSON.parse(s);
}

export async function extractTicket(content) {
  if (!mode) await initLLM();
  if (mode === 'offline') return offlineExtract(content);

  const prompt = extractPrompt(content);
  try {
    let raw = '';
    if (mode === 'ollama') {
      const r = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: CFG.OLLAMA_LLM_MODEL, prompt, stream: false, format: 'json' })
      });
      if (!r.ok) throw new Error('status ' + r.status);
      raw = (await r.json()).response;
    } else if (mode === 'api') {
      const r = await fetchWithTimeout(`${CFG.LLM_API_BASE}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CFG.LLM_API_KEY}` },
        body: JSON.stringify({
          model: CFG.LLM_MODEL,
          temperature: 0.2,
          messages: [{ role: 'user', content: prompt }]
        })
      });
      if (!r.ok) throw new Error('status ' + r.status);
      raw = (await r.json())?.choices?.[0]?.message?.content;
    }
    const j = parseJSON(raw);
    return {
      question: String(j.question || '').slice(0, 80) || offlineExtract(content).question,
      solution: String(j.solution || ''),
      category: String(j.category || guessCategory(content)),
      urgency: [1, 2, 3].includes(Number(j.urgency)) ? Number(j.urgency) : 1,
      confidence: typeof j.confidence === 'number' ? j.confidence : 0.6
    };
  } catch (e) {
    console.warn(`[llm] 抽取调用失败，本次回退离线启发式：${e.message}`);
    return offlineExtract(content);
  }
}

// ---------- 对话回复生成 ----------
// systemPrompt 可携带检索到的知识上下文，让回复更贴合业务标准话术。
export async function generateReply(userText, { context = '', history = [], public: isPublic = false } = {}) {
  if (!mode) await initLLM();

  // offline：启发式兜底（仍能基于检索上下文组织话术）
  if (mode === 'offline') {
    const kb = (context || '').trim();
    if (kb) {
      // 访客端只给可用的参考内容本身，不暴露「标准话术参考」「离线模式」等内部标注
      return isPublic
        ? kb
        : `【标准话术参考】\n${kb}\n\n（当前为离线模式，未调用大模型，请结合上下文自然回复客户。）`;
    }
    return isPublic
      ? '抱歉，我暂时没查到相关信息。方便换个说法描述您的问题吗？如需人工协助，我们会尽快为您安排。'
      : '（离线模式）建议先安抚客户情绪，明确诉求后按标准流程处理，必要时转人工坐席。';
  }

  const sysBase = '你是专业、耐心、合规的智能客服助手。' +
    '请用简洁自然的中文回复客户的提问，语气友好且专业，避免绝对化承诺。' +
    // 访客端：直接面对客户作答，不得暴露内部检索机制
    (isPublic
      ? '\n重要约束：你正在直接回复客户。不要提及“知识库”“参考资料”“文档编号”“相似度”“检索结果”等内部机制，' +
        '也不要复述原文条目编号或来源名称；直接给出自然、友好、可执行的答复即可。' +
        '回复请用纯文本表达，通过换行分段，不要使用 Markdown 标记（不要用 ** 加粗、# 标题等）。'
      : '');
  const kbBlock = (context || '').trim()
    ? `\n\n=== 知识库参考话术（仅供借鉴，不要照抄原文编号）===\n${context}\n=== 参考结束 ===`
    : '';
  const histBlock = Array.isArray(history) && history.length
    ? '\n\n对话前文：\n' + history.map(h => `${h.role === 'user' ? '客户' : '客服'}：${h.text}`).join('\n')
    : '';
  const system = sysBase + kbBlock + histBlock;
  const messages = [
    { role: 'system', content: system },
    { role: 'user', content: userText }
  ];

  try {
    if (mode === 'ollama') {
      const r = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: CFG.OLLAMA_LLM_MODEL, messages, stream: false })
      }, 60000);
      if (!r.ok) throw new Error('status ' + r.status);
      const j = await r.json();
      const c = j?.message?.content;
      if (!c) throw new Error('empty content');
      return c.trim();
    }
    if (mode === 'api') {
      const r = await fetchWithTimeout(`${CFG.LLM_API_BASE}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CFG.LLM_API_KEY}` },
        body: JSON.stringify({ model: CFG.LLM_MODEL, temperature: 0.6, messages })
      }, 60000);
      if (!r.ok) throw new Error('status ' + r.status);
      const c = (await r.json())?.choices?.[0]?.message?.content;
      if (!c) throw new Error('empty content');
      return c.trim();
    }
  } catch (e) {
    console.warn(`[llm] 对话生成失败：${e.message}`);
    const kb = (context || '').trim();
    if (kb) {
      return isPublic ? kb : `【生成失败，降级为知识库参考】\n${kb}`;
    }
    return isPublic
      ? '抱歉，我这边稍有点忙，没能马上给出答复。请稍后再试一次，或联系人工客服为您处理。'
      : '（生成失败）建议先安抚客户情绪，明确诉求后按标准流程处理，必要时转人工坐席。';
  }
  return isPublic
    ? '抱歉，我暂时无法回答这个问题，您可以换个方式提问，或联系人工客服。'
    : '（无可用回复）';
}

// ---------- 通用文本生成（供话术生成、分类、FAQ 提炼等场景化任务复用）----------
// 单次生成：任何失败（含超时 abort、非 2xx、空内容）都向上抛，由外层 generateText 统一重试。
async function generateTextOnce(prompt, { temperature = 0.6, system = '', timeout = 60000 } = {}) {
  const messages = [];
  if (system) messages.push({ role: 'system', content: system });
  messages.push({ role: 'user', content: prompt });
  if (mode === 'ollama') {
    const r = await fetchWithTimeout(`${CFG.OLLAMA_HOST}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: CFG.OLLAMA_LLM_MODEL, messages, stream: false })
    }, timeout);
    if (!r.ok) throw new Error('status ' + r.status);
    const c = (await r.json())?.message?.content;
    if (!c) throw new Error('empty content');
    return c.trim();
  }
  // mode === 'api'
  const r = await fetchWithTimeout(`${CFG.LLM_API_BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CFG.LLM_API_KEY}` },
    body: JSON.stringify({ model: CFG.LLM_MODEL, temperature, messages })
  }, timeout);
  if (!r.ok) throw new Error('status ' + r.status);
  const c = (await r.json())?.choices?.[0]?.message?.content;
  if (!c) throw new Error('empty content');
  return c.trim();
}

// 通用文本生成（带超时 + 失败重试）。retries 控制重试次数，timeout 为单次请求上限（毫秒）。
// 重试仅在该次调用抛错时触发（超时 abort / 网络抖动 / 5xx），并在两次之间做线性退避，
// 以缓解外部 LLM API 的限流与瞬时抖动——这正是之前「（生成失败：This operation was aborted）」
// 这类静默丢结果的根因。最终仍失败才返回「（生成失败：...）」占位串。
export async function generateText(prompt, { temperature = 0.6, system = '', retries = 0, timeout = 60000 } = {}) {
  if (!mode) await initLLM();
  if (mode === 'offline') {
    return '（离线模式：未配置可用大模型，无法生成。请配置 Ollama 或外接 API 后重试。）';
  }
  let lastErr = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await generateTextOnce(prompt, { temperature, system, timeout });
    } catch (e) {
      lastErr = e;
      console.warn(`[llm:generateText] 第 ${attempt + 1}/${retries + 1} 次生成失败: ${e.message}`);
      if (attempt < retries) {
        const backoff = 800 * (attempt + 1); // 0.8s, 1.6s 线性退避，给限流器腾出窗口
        await new Promise((res) => setTimeout(res, backoff));
      }
    }
  }
  return `（生成失败：${lastErr?.message}）`;
}

// 从一段长文本里提炼 FAQ 问答对（JSON 数组 [{question, solution}]）。
// 适合把飞书/IMA 知识库的整篇文档内容喂进来，批量生成可入库的标准 FAQ。
export async function extractFAQs(content, { limit = 10, temperature = 0.5 } = {}) {
  if (!content || !content.trim()) return [];
  if (!mode) await initLLM();
  if (mode === 'offline') return [];
  const system = `你是一个客服知识库专家。请仔细阅读下面提供的文本，从中提取出最实用的 FAQ 问答对。
- 每个问答对包含「问题」和「标准答案」两部分。
- 问题要简洁、典型，符合客户实际提问方式（如"怎么退款"而非"关于退款流程的说明"）。
- 答案要完整、可直接作为坐席回复发送给客户，包含具体操作步骤。
- 优先提取与售后、售前、退款、物流、发票、产品功能、常见问题相关的问答。
- 如果原文是某个具体文档的片段（如公告、日志），请结合常识推断可能的客户提问。
- 输出严格的 JSON 数组格式，不要任何额外说明。`;
  const prompt = `请从以下文本中提取 FAQ 问答对（最多 ${limit} 条）：\n\n${content.slice(0, 4000)}\n\n请以 JSON 数组格式返回，格式：[{"question":"问题","solution":"答案"}]`;
  try {
    // 单条文档提炼允许更长的单次超时（90s），并自动重试 2 次以扛住外部 API 限流/抖动
    const raw = await generateText(prompt, { temperature, system, retries: 2, timeout: 90000 });
    // 健壮解析：LLM 常返回带 markdown 代码块、前导说明、甚至错误文案（如「（生成失败：...）」）。
    // 1) 去掉 ```json / ``` 包裹
    let cleaned = raw.replace(/```(?:json)?\n?/g, '').trim();
    // 2) 优先提取首个 JSON 数组（兼容前后有噪声文本的情况）
    const arrMatch = cleaned.match(/\[[\s\S]*\]/);
    if (arrMatch) cleaned = arrMatch[0];
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      // 3) 退一步：用正则抓取 "question"/"问题" + "solution"/"答案" 配对
      const qa = [];
      const re = /["“]?(?:question|问题)["”]?\s*[:：]\s*"([^"]+)"[\s\S]*?["“]?(?:solution|答案|answer)["”]?\s*[:：]\s*"([^"]+)"/gi;
      let m;
      while ((m = re.exec(cleaned)) && qa.length < limit) {
        qa.push({ question: m[1].trim(), solution: m[2].trim() });
      }
      if (qa.length) return qa;
      console.warn(`[llm:extractFAQs] 无法解析 JSON，原始返回前 200 字: ${raw.slice(0, 200)}`);
      return [];
    }
    // 4) 兼容中文键 question/问题、solution/答案
    const norm = (f) => ({
      question: String(f.question ?? f.问题 ?? '').trim(),
      solution: String(f.solution ?? f.答案 ?? f.answer ?? '').trim()
    });
    if (Array.isArray(parsed)) {
      const valid = parsed
        .map(norm)
        .filter((f) => f.question && f.solution)
        .slice(0, limit);
      return valid;
    }
  } catch (e) {
    console.warn(`[llm:extractFAQs] 解析失败: ${e.message}`);
  }
  return [];
}
