// 质检引擎：敏感词（规则）+ 情绪（关键词），离线零成本。
// 复杂「服务规范」检测（对照标准流程）放到二期，用 LLM 实现。

const SENSITIVE = [
  { word: '绝对', note: '可能违反广告法绝对化用语' },
  { word: '100%', note: '绝对化表述风险' },
  { word: '包治', note: '医疗违规承诺' },
  { word: ' guaranteed', note: '绝对化表述风险' },
  { word: '最便宜', note: '违反广告法「最」字禁用' }
];

// 强负面词：仅出现1个即触发 mid，需配合上下文才有意义
const NEG_STRONG = ['垃圾', '骗', '曝光', '忽悠', '诈骗', '黑心'];
// 普通负面词：需连续出现 ≥3 个才触发 mid（从≥2提升至≥3），避免"我要投诉你们""差评怎么改"等正常咨询误判
const NEG_NORMAL = ['投诉', '差评', '生气', '愤怒', '退钱', '失望'];
const POS = ['谢谢', '满意', '好的', '理解', '感谢', '麻烦了'];

/**
 * 对一段对话文本做三维度检测。
 * - 命中任何敏感词 → high（广告法/医疗违规等硬性风险）
 * - 出现3个及以上 NEG_NORMAL 词 或 任意 NEG_STRONG 词 → mid（情绪预警）
 * - 其余 → low
 */
export function detect(text = '') {
  const hits = [];
  for (const s of SENSITIVE) {
    if (text.includes(s.word)) hits.push({ word: s.word, note: s.note });
  }

  let negStrong = 0;
  let negNormal = 0;
  for (const w of NEG_STRONG) if (text.includes(w)) negStrong++;
  for (const w of NEG_NORMAL) if (text.includes(w)) negNormal++;
  let pos = 0;
  for (const w of POS) if (text.includes(w)) pos++;

  const emotion = (negStrong + negNormal) > pos ? 'angry' : pos > 0 ? 'positive' : 'neutral';

  let risk = 'low';
  if (hits.length > 0) risk = 'high';
  else if (negNormal >= 2 || negStrong >= 1) risk = 'mid';

  // 生成建议话术
  let suggestion = '';
  if (risk === 'high') {
    suggestion = '⚠️ 检测到敏感词/违规表述，建议立即停止使用该话术，重新审核内容后发送。';
  } else if (risk === 'mid') {
    suggestion = '⚠️ 客户情绪激动，建议采用安抚话术：先表达理解与共情，再提供解决方案。避免激化矛盾。';
  } else if (emotion === 'angry') {
    suggestion = '💡 客户情绪负面，建议主动致歉并提供补偿方案，同时记录备查。';
  } else {
    suggestion = '✓ 对话正常，按标准流程处理即可。';
  }

  return {
    sensitive_hits: hits,
    emotion,
    risk_level: risk,
    needs_review: risk !== 'low',
    suggestion
  };
}
