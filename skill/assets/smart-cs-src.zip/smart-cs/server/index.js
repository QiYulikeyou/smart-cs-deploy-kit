import Fastify from 'fastify';
import cors from '@fastify/cors';
import fastifyStatic from '@fastify/static';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

import ticketsRoutes from './routes/tickets.js';
import knowledgeRoutes from './routes/knowledge.js';
import qaRoutes from './routes/qa.js';
import scriptsRoutes from './routes/scripts.js';
import dispatchRoutes from './routes/dispatch.js';
import authRoutes from './routes/auth.js';
import syncRoutes from './routes/sync.js';
import deployRoutes from './routes/deploy.js';
import { verifyToken } from './auth.js';
import { initLLM, getLLMInfo, getEmbedInfo, embedText } from './llm.js';
import db, { readyPromise as dbReady } from './db.js';
import { buildDocText } from './embed.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const WEB_DIST = process.env.WEB_DIST || path.join(__dirname, '../web/dist');

const app = Fastify({ logger: true });

await dbReady; // 等 sql.js 加载 + 建表完成
await app.register(cors, { origin: true });

// 全局鉴权 hook：除白名单外的 /api 路由必须携带有效 Bearer token
const OPEN_PATHS = new Set([
  '/api/health',
  '/api/auth/login',
  '/api/llm/info',
  '/api/qa/public-chat',
  // 挂件拉取外观配置（已做字段白名单，不含任何密钥）
  '/api/deploy/widget-config'
]);
app.addHook('onRequest', async (req, reply) => {
  if (!req.url.startsWith('/api')) return; // 静态资源 / 前端
  const path = req.url.split('?')[0];
  if (OPEN_PATHS.has(path)) return;
  const auth = req.headers['authorization'] || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const payload = verifyToken(token);
  if (!payload) {
    return reply.code(401).send({ error: 'unauthorized' });
  }
  req.user = { id: payload.uid, username: payload.username, role: payload.role };
});

await app.register(ticketsRoutes);
await app.register(knowledgeRoutes);
await app.register(qaRoutes);
await app.register(scriptsRoutes);
await app.register(dispatchRoutes);
await app.register(authRoutes);
await app.register(syncRoutes);
await app.register(deployRoutes);

// 启动飞书自动同步调度器（无论 kb_source 是否配置，调度器始终可手动触发）
const { startScheduler } = await import('./scheduler.js');
startScheduler();

// 生产：托管前端构建产物（release 后存在于 current/web/dist）
if (fs.existsSync(WEB_DIST)) {
  await app.register(fastifyStatic, { root: WEB_DIST });
  app.setNotFoundHandler((req, reply) => {
    if (req.url.startsWith('/api')) return reply.code(404).send({ error: 'not found' });
    return reply.sendFile('index.html');
  });
}

app.get('/api/health', async () => ({ ok: true, ts: Date.now(), llm: getLLMInfo() }));

try {
  await initLLM(); // 锁定 embedding/LLM provider 模式（offline/ollama/api）

  // 启动自动迁移：embedding 模型切换后，维度不一致的知识向量自动重算为当前维度。
  // 仅当语义模式(semantic)生效时执行，避免 ollama 宕机回退 offline 时把 768d 向量覆盖成 256d 哈希。
  const { mode: embedMode, dim } = getEmbedInfo();
  if (embedMode === 'semantic' && dim) {
    const rows = db.prepare('SELECT id, question, solution, embedding FROM knowledge_item').all();
    const mismatch = rows.some((r) => {
      try {
        const v = JSON.parse(r.embedding);
        return !Array.isArray(v) || v.length !== dim;
      } catch {
        return true;
      }
    });
    if (mismatch && rows.length) {
      console.log(`[migrate] 检测到向量维度不一致（目标 ${dim}d），自动重算 ${rows.length} 条知识向量...`);
      for (const r of rows) {
        const emb = JSON.stringify(await embedText(buildDocText(r)));
        db.prepare('UPDATE knowledge_item SET embedding = ? WHERE id = ?').run(emb, r.id);
      }
      console.log('[migrate] 向量重算完成，真语义检索已就绪');
    }
  }

  await app.listen({ port: PORT, host: '0.0.0.0' });
} catch (e) {
  app.log.error(e);
  process.exit(1);
}
