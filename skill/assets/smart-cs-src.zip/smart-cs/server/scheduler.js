// 飞书文档自动同步调度器。
// 启动时检查 .runtime-config.json 的 feishu_sync 配置，按 cron 表达式定时调用 syncExternalKnowledge()。
// 同时也暴露 runNow() 供前端手动触发。

import cron from 'node-cron';
import { syncExternalKnowledge } from './kb/sync.js';
import { getRuntimeConfig } from './runtimeConfig.js';

let cronTask = null;
let lastSync = null;
let syncStatus = 'idle'; // idle | running | success | error

export function getSyncStatus() {
  return { lastSync, syncStatus, configured: Boolean(getRuntimeConfig().feishu_app_id) };
}

// 执行一次同步（幂等：重复调用不会重复写入，sync.js 内部已去重）
export async function runNow(keyword = '常见问题') {
  const rc = getRuntimeConfig();
  if (!rc.feishu_app_id) return { ok: false, error: '飞书未配置' };
  syncStatus = 'running';
  try {
    const r = await syncExternalKnowledge('feishu', keyword);
    lastSync = new Date().toISOString();
    syncStatus = r.ok !== false ? 'success' : 'error';
    return { ok: true, ...r, syncedAt: lastSync };
  } catch (e) {
    lastSync = new Date().toISOString();
    syncStatus = 'error';
    return { ok: false, error: e.message, syncedAt: lastSync };
  }
}

// 注册定时任务（cron 表达式格式：分 时 日 月 周）
// 默认每天凌晨 3 点同步一次；config 中 feishu_sync.cron 可覆盖
export function startScheduler() {
  const rc = getRuntimeConfig();
  const cronExpr = rc.feishu_sync?.cron || '0 3 * * *'; // 默认每天 03:00
  try {
    cronTask = cron.schedule(cronExpr, async () => {
      console.log(`[sync-scheduler] 定时同步触发 at ${new Date().toISOString()}`);
      const r = await runNow(rc.feishu_sync?.keyword || '常见问题');
      console.log('[sync-scheduler] 同步结果:', JSON.stringify(r));
    }, { scheduled: true, timezone: 'Asia/Shanghai' });
    console.log(`[sync-scheduler] 已注册定时任务 cron=${cronExpr}`);
  } catch (e) {
    console.error('[sync-scheduler] 注册失败:', e.message);
  }
}

export function stopScheduler() {
  if (cronTask) {
    cronTask.stop();
    cronTask = null;
    console.log('[sync-scheduler] 已停止');
  }
}
