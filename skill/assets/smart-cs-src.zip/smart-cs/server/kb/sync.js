// 外部知识库同步：把飞书 / IMA 知识库拉取到本地 RAG（knowledge_item），
// 便于运营在飞书 / IMA 维护 FAQ，一键同步进来作为本地向量检索语料。
import db from '../db.js';
import { FeishuProvider } from './feishu.js';
import { ImaProvider } from './ima.js';
import { createKnowledgeItem, SOURCE_TYPES } from './ingest.js';
import { extractFAQs } from '../llm.js';

// 从飞书拉取「可入库」的条目：先用 search 拿到命中，再逐条拉取完整正文。
// 原因：飞书 search 默认只回标题级 snippet（太短，无法提炼 FAQ）；这里额外调 docx
// raw_content 取完整正文（封顶 4000 字），让 LLM 能从一篇文档里提炼出多条 FAQ。
// 返回 [{ title, content, url, knowledge_base_name }]
async function fetchFromFeishu(keyword, targetSpaceId = null) {
  const p = new FeishuProvider();
  if (!p.configured) throw new Error('飞书未配置（缺 FEISHU_APP_ID/SECRET/SPACE_IDS）');

  // 拉取知识库名称映射（spaceId -> 真实库名），让 knowledge_base_name 显示具体库名而非拼 ID
  const nameMap = {};
  try {
    const spaces = await p.listSpaces();
    for (const s of spaces) nameMap[s.space_id] = s.name;
  } catch {
    /* 名称映射失败不影响主流程，降级为「飞书知识库-<spaceId>」 */
  }

  // 如果指定了 targetSpaceId，只搜索该 space；否则搜索所有 space
  const hits = await p.search(keyword, 20);
  const results = [];
  for (const h of hits) {
    const meta = h.raw?.result_meta || {};
    const spaceId = meta.space_id || targetSpaceId || null;
    const kbName = spaceId ? nameMap[spaceId] || `飞书知识库-${spaceId}` : '飞书知识库';
    let content = h.snippet || '';
    // 拉完整正文（FAQ 提炼需要足够上下文）；仅文档类命中带 token
    if (meta.token) {
      try {
        const token = await p._getToken();
        const doc = await p._get(`/docx/v1/documents/${meta.token}/raw_content`, token);
        const full = doc?.content || '';
        if (full) content = full.slice(0, 4000);
      } catch {
        /* 取正文失败则退化用片段 */
      }
    }
    results.push({
      title: h.title || '(无标题)',
      content,
      url: h.url || '',
      knowledge_base_id: spaceId,
      knowledge_base_name: kbName
    });
  }
  return results;
}

// 递归枚举 IMA 知识库全部条目（根目录 + 所有子文件夹），不依赖关键词。
// 返回扁平化的条目数组（仅真实文档，文件夹不计入）。
// IMA 标记：文件夹 media_type===99 且 media_id 形如 folder_xxx；递归时用文件夹的
// media_id 作为下一级的 folder_id 入参。真实文档 media_type 非 99 且含 media_id。
async function listImaItems(p, kbId, folderId = null, seen = new Set(), out = []) {
  let cursor = '';
  let guard = 0;
  do {
    const body = { knowledge_base_id: kbId, cursor, limit: 50 };
    if (folderId) body.folder_id = folderId;
    const data = await p._post('/get_knowledge_list', body);
    const list = data.knowledge_list || [];
    for (const it of list) {
      const isFolder = it.media_type === 99 || (it.media_id && String(it.media_id).startsWith('folder_'));
      if (isFolder) {
        // 文件夹：递归进入（用 seen 防环，key 用文件夹 media_id）
        if (!seen.has(it.media_id)) {
          seen.add(it.media_id);
          await listImaItems(p, kbId, it.media_id, seen, out);
        }
      } else if (it.media_id) {
        out.push(it);
      }
    }
    cursor = data.next_cursor || '';
    if (data.is_end) break;
  } while (cursor && guard++ < 30);
  return out;
}

async function fetchFromIma(keyword, kbId = null, kbName = '') {
  const p = new ImaProvider();
  if (!p.configured) throw new Error('IMA 未配置（缺 IMA_OPENAPI_CLIENTID/APIKEY/KB_ID）');

  // 使用指定的 kbId 或默认的 kbId
  const targetKbId = kbId || p.kbId;
  if (!targetKbId) throw new Error('IMA 知识库 ID 未配置');

  // 枚举整个知识库（不依赖关键词），逐条拉取正文。
  // 注意：这里直接调 _post，让其抛错——同步是显式人工操作，应把 IMA 的真实错误
  // （如 220004 invalid knowledge_base_id）暴露给前端，而不是静默返回空数组导致「新增0/跳过0」。
  const items = await listImaItems(p, targetKbId);
  const results = [];
  for (const it of items) {
    const title = (it.title || '(无标题)').toString().trim();
    let solution = '';
    let url = '';
    try {
      const media = await p._post('/get_media_info', { media_id: it.media_id });
      const d = media || {};
      // 笔记 / Markdown 等带正文
      const nb = d.notebook_ext_info || {};
      solution = nb.content || nb.text || d.content || d.text || '';
      // 网页 / 公众号等只有原文链接
      if (!solution && d.url_info && d.url_info.url) {
        url = d.url_info.url;
        solution = `[原文链接] ${url}`;
      }
    } catch {
      /* 单条取原文失败不影响其它条目 */
    }
    // 网页 / 公众号等只有原文链接（无正文）→ 直接跳过，无法用于检索
    if (!solution) continue;
    results.push({
      question: title,
      solution: solution || '',
      category: 'IMA同步',
      url,
      knowledge_base_id: targetKbId,
      knowledge_base_name: kbName || `IMA知识库-${targetKbId.slice(0, 8)}`
    });
  }
  return results;
}

// 统一「文档 → FAQ 知识条目」入库。
// 对每篇文档调用 LLM（extractFAQs）提炼多条问答对，逐条写入 knowledge_item；
// 若 LLM 不可用（离线模式）/ 文档过短 / 提炼结果为空，则退化为「整篇文档作为 1 条」写入，
// 保证内容不丢。用于本地文件 / 飞书 / IMA 三条渠道的统一入库，避免「整篇文档 = 1 条」的低粒度。
// @param {Array<{title, content, url?, knowledge_base_name?}>} docs
// @returns {Promise<{added:number, skipped:number, failed:Array, docs:number}>}
export async function ingestDocsAsFAQ(
  docs,
  { sourceType, kbName = '', publish = false, limitPerDoc = 6, concurrency = 3 } = {}
) {
  if (!SOURCE_TYPES.includes(sourceType)) throw new Error('非法 source_type: ' + sourceType);

  // 同来源已存在 question 去重基线（单次同步只针对单一 source）。
  // 注意：不能用 IN (?, ?) 传同一个值两次——sql.js 会把第二个占位符绑成 NULL，
  // 导致 IN ('ima', NULL) 永远不命中（实测去重失效、每次全量重复入库）。
  const existing = new Set(
    db.prepare('SELECT question FROM knowledge_item WHERE source_type = ?').all(sourceType).map((r) => r.question)
  );
  const seen = new Set();

  // 过滤完全没有内容、也没链接的文档
  const realDocs = [];
  let skipped = 0;
  for (const d of docs || []) {
    const content = (d && d.content) || '';
    const hasUrl = d && d.url;
    if (!content.trim() && !hasUrl) {
      skipped++;
      continue;
    }
    realDocs.push(d);
  }

  let added = 0;
  const failed = [];

  async function processDoc(doc) {
    const title = String(doc.title || '').trim();
    const kb = doc.knowledge_base_name || kbName || '';
    // 分类沿用来源标记，便于「知识库清洗」按 category 识别外部同步噪音
    const category = sourceType === 'feishu' ? '飞书同步' : sourceType === 'ima' ? 'IMA同步' : kb || '本地文件';
    let content = String(doc.content || '');
    if (!content.trim() && doc.url) content = `[原文链接] ${doc.url}`; // 纯链接文档兜底

    // 1) 尝试 LLM 提炼 FAQ（仅当正文足够长；过短没必要、也易提炼失败）
    let faqs = [];
    if (content.length > 150) {
      try {
        faqs = await extractFAQs(content, { limit: limitPerDoc });
      } catch (e) {
        console.warn(`[kb:ingestFAQ] 提炼失败 ${title}: ${e.message}`);
        faqs = [];
      }
    }

    // 2) 收集待入库条目（按 question 去重：已入库 / 本批已写入 都跳过）
    const toInsert = [];
    for (const f of faqs) {
      const q = String(f.question || '').trim();
      const a = String(f.solution || '').trim();
      if (!q || !a) continue;
      if (existing.has(q) || seen.has(q)) {
        skipped++;
        continue;
      }
      seen.add(q);
      toInsert.push({ question: q, solution: a, extracted_from: title || null });
    }

    // 3) 退化：无任何可用 FAQ → 整篇文档作为 1 条（保留原始内容）
    if (!toInsert.length) {
      const q = title || content.slice(0, 40).replace(/\s+/g, ' ').trim();
      if (!q) {
        skipped++;
        return;
      }
      if (existing.has(q) || seen.has(q)) {
        skipped++;
        return;
      }
      seen.add(q);
      toInsert.push({ question: q, solution: content, extracted_from: title || null });
    }

    // 4) 落库（统一模板：向量自动计算，草稿态待审核发布）
    for (const it of toInsert) {
      try {
        const r = await createKnowledgeItem({
          question: it.question,
          solution: it.solution,
          category,
          urgency: 1,
          source_type: sourceType,
          knowledge_base_name: kb,
          extracted_from: it.extracted_from,
          status: publish ? 'published' : 'draft'
        });
        if (r.id) added++;
      } catch (e) {
        failed.push({ question: it.question, error: e.message });
      }
    }
  }

  // 并发池：限制同时进行的 LLM 提炼数量，避免打爆本地 Ollama / 触发外部 API 限流
  let idx = 0;
  const n = Math.max(1, Math.min(concurrency, realDocs.length));
  await Promise.all(
    Array.from({ length: n }, async () => {
      while (idx < realDocs.length) {
        const cur = realDocs[idx++];
        await processDoc(cur);
      }
    })
  );

  return { added, skipped, failed, docs: realDocs.length };
}

// 按 knowledge_base_name 同步指定远程库：
// - 先从远端拉取文档列表（不入库）
// - 删除本地所有 knowledge_base_name 匹配该库名的旧条目
// - 把远端文档走 FAQ 提炼入库（去重按 question）
// 返回 { deleted, added, skipped, failed, docs }
// 用于「清理旧整篇 + 重新提炼」的二次翻新场景。
export async function syncByKbName(kbSource, kbName, options = {}) {
  // 1) 按源拉文档（不依赖用户传入的 kbId——由 kbName 识别远端库）
  let items;
  if (kbSource === 'feishu') items = await fetchFromFeishu('常见问题', null);
  else if (kbSource === 'ima') items = await fetchFromIma('', null, kbName);
  else throw new Error('syncByKbName 仅支持 feishu / ima');

  // 按 kb_name 过滤（IMA 用传入的 kbName，飞书按 space 名匹配）
  const kbDocs = (items || []).filter((d) => d.knowledge_base_name === kbName);

  // 2) 删除本地该库名下的所有旧条目（飞书旧条目可能带空间ID后缀，用 LIKE 匹配）
  let existingIds = db
    .prepare("SELECT id FROM knowledge_item WHERE knowledge_base_name = ?")
    .all(kbName)
    .map((r) => r.id);
  // 飞书兼容：即使有精确匹配，也要清理旧的空间ID后缀条目（如 '飞书知识库-7677423561501379534'）
  if (kbSource === 'feishu') {
    const legacyIds = db
      .prepare("SELECT id FROM knowledge_item WHERE source_type = 'feishu' AND knowledge_base_name LIKE '飞书知识库-%'")
      .all()
      .map((r) => r.id);
    existingIds = [...new Set([...existingIds, ...legacyIds])];
  }
  for (const id of existingIds) {
    db.prepare('DELETE FROM knowledge_item WHERE id = ?').run(id);
  }
  const deleted = existingIds.length;
  console.log(`[kb:syncKbName] 已清理 ${deleted} 条旧条目 (source=${kbSource}, kb=${kbName})`);

  // 3) 走 FAQ 提炼入库（自动发布，让外部库条目参与检索）
  return ingestDocsAsFAQ(kbDocs, {
    sourceType: kbSource,
    kbName,
    publish: true,
    limitPerDoc: options.limitPerDoc || 6,
    concurrency: options.concurrency || 3
  });
}

// 同步入口：按 kb_source 拉取文档，并统一走 FAQ 提炼入库（去重按 question）。
// keyword 可为空串（部分源支持空检索返回热门）；为稳妥默认给一个通用词。
// spaceId/kbId: 可选，指定具体知识库（飞书传 space_id，IMA 传 kb_id）
export async function syncExternalKnowledge(kbSource, keyword = '常见问题', spaceId = null, kbId = null, kbName = '') {
  let items;
  if (kbSource === 'feishu') items = await fetchFromFeishu(keyword, spaceId);
  else if (kbSource === 'ima') items = await fetchFromIma(keyword, kbId, kbName);
  else throw new Error('同步仅支持 feishu / ima');

  // 统一 FAQ 提炼入库：每篇文档 → 多条 FAQ；LLM 不可用时退化为整篇 1 条。
  // 飞书每条文档自带 knowledge_base_name；IMA 用传入的 kbName。
  return ingestDocsAsFAQ(items, {
    sourceType: kbSource,
    kbName: kbSource === 'ima' ? kbName : items[0]?.knowledge_base_name || '飞书知识库',
    limitPerDoc: 6
  });
}

/**
 * 从外部知识库内容中自动提炼 FAQ（LLM）。
 * @param {string} kbSource - 'feishu' | 'ima'
 * @param {string} keyword - 检索关键词
 * @param {string} [spaceId] - 飞书 space_id（可选）
 * @param {string} [kbId] - IMA kb_id（可选）
 * @param {number} [limit] - 最多提炼几条（默认 10）
 * @returns {Promise<{count: number, items: Array<{question, solution}>}>}
 */
export async function extractFAQFromExternal(kbSource, keyword, spaceId = null, kbId = null, limit = 10, kbName = '') {
  // 1. 先拉取原始文档内容
  const rawItems = kbSource === 'feishu'
    ? await fetchFromFeishu(keyword, spaceId)
    : kbSource === 'ima'
    ? await fetchFromIma(keyword, kbId, kbName)
    : [];

  if (rawItems.length === 0) return { count: 0, items: [] };

  // 2. 对前 3 条文档并发调用 LLM 提炼 FAQ（并发控制总耗时，避免顺序堆叠超时）
  const top = rawItems.slice(0, 3);
  const settled = await Promise.all(
    top.map(async (item) => {
      if (!item.solution) return [];
      try {
        const faqs = await extractFAQs(item.solution, { limit: Math.ceil(limit / 3) });
        return faqs.map((faq) => ({
          ...faq,
          source: kbSource,
          knowledge_base_name: item.knowledge_base_name,
          original_title: item.question
        }));
      } catch (e) {
        console.warn(`[kb:extractFAQ] 提炼失败 ${item.question}: ${e.message}`);
        return [];
      }
    })
  );
  const allFAQs = settled.flat();

  // 3. 去重并限制数量
  const seen = new Set();
  const uniqueFAQs = [];
  for (const faq of allFAQs) {
    const key = faq.question;
    if (seen.has(key)) continue;
    seen.add(key);
    uniqueFAQs.push(faq);
    if (uniqueFAQs.length >= limit) break;
  }

  return { count: uniqueFAQs.length, items: uniqueFAQs };
}
