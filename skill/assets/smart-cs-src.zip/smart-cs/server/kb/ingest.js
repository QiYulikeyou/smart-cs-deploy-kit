// 统一知识条目写入模板（ingest）
// 三个构建渠道（工单回流 / 历史FAQ / 飞书·IMA 同步）+ 对话提炼，统一从这里入库，
// 保证 knowledge_item 的字段形态、来源标记、初始质量分一致，避免各渠道各写各的 INSERT。
import db from '../db.js';
import { embedText } from '../llm.js';
import { buildDocText } from '../embed.js';

// 合法来源类型（统一模板的核心标识）
export const SOURCE_TYPES = ['manual', 'faq', 'ticket', 'feishu', 'ima', 'conversation', 'file'];

function normalizeSourceType(t) {
  return SOURCE_TYPES.includes(t) ? t : 'manual';
}

// 发布状态：仅 draft / published 合法，缺省 published（人工新增即生效）。
// 自动入库渠道（工单回流 / 飞书·IMA 同步 / 对话提炼）传入 'draft'，需审核发布后才进下游检索。
function normalizeStatus(s) {
  return s === 'draft' ? 'draft' : 'published';
}

// 统一初始质量分：避免所有新条目都是写死的 0.5 / 0.6 死值。
// 基于「答案完整度」给起点，飞书 / IMA 同步条目 snippet 常常为空，给折扣提示待补全。
// 后续由 /api/knowledge/recalc-quality 按命中 / 反馈 / 陈旧重算覆盖。
function estimateInitialQuality({ solution = '', sourceType = 'manual' } = {}) {
  let score = 0.5;
  const sLen = String(solution).length;
  score += Math.min(sLen / 100, 1) * 0.2; // 答案越完整，初始分越高（封顶 +0.2）
  if ((sourceType === 'feishu' || sourceType === 'ima') && sLen < 10) score -= 0.1;
  return Math.max(0, Math.min(1, score));
}

// 把任意渠道的入参归一成统一字段形态（核心：统一模板）
export function normalizeKnowledgeFields(opts = {}) {
  const question = String(opts.question || '').trim();
  const solution = String(opts.solution || '');
  const source_type = normalizeSourceType(opts.source_type);
  const category = String(opts.category || '其他').trim() || '其他';
  const product_module = String(opts.product_module || '').trim();
  const urgency = [1, 2, 3].includes(Number(opts.urgency)) ? Number(opts.urgency) : 1;
  return {
    question,
    solution,
    source_type,
    category,
    product_module,
    urgency,
    quality_score: estimateInitialQuality({ solution, sourceType: source_type }),
    source_ticket_id: opts.source_ticket_id ?? null,
    extracted_from: opts.extracted_from ?? null,
    knowledge_base_name: opts.knowledge_base_name ?? null,
    status: normalizeStatus(opts.status),
    embedding: opts.embedding ?? null
  };
}

// 同步落库（向量已预计算时使用，如工单批量回流）
export function insertKnowledgeRow(n) {
  const info = db
    .prepare(
      `INSERT INTO knowledge_item
        (question, solution, category, product_module, urgency, embedding, source_type, quality_score, source_ticket_id, extracted_from, knowledge_base_name, status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
    )
    .run(
      n.question,
      n.solution,
      n.category,
      n.product_module,
      n.urgency,
      n.embedding,
      n.source_type,
      n.quality_score,
      n.source_ticket_id,
      n.extracted_from,
      n.knowledge_base_name,
      n.status || 'published'
    );
  return info.lastInsertRowid;
}

// 统一写入入口（异步）：缺 embedding 时自动计算向量。
// opts: { question, solution, category, product_module, urgency, source_type, source_ticket_id, extracted_from }
// 返回 { id, quality_score }
export async function createKnowledgeItem(opts = {}) {
  const n = normalizeKnowledgeFields(opts);
  if (!n.question) throw new Error('question 不能为空');
  if (!n.embedding) {
    n.embedding = JSON.stringify(
      await embedText(buildDocText({ question: n.question, category: n.category, product_module: n.product_module, solution: n.solution }))
    );
  }
  return { id: insertKnowledgeRow(n), quality_score: n.quality_score };
}
