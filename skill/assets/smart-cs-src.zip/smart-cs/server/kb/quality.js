import db from '../db.js';
import { extractTicket } from '../llm.js';
import { createKnowledgeItem } from './ingest.js';

// ---- 知识质量评分 ----
// 综合公式：基础分 + 命中贡献 + 反馈贡献 + 陈旧惩罚，clamp[0,1]
export function recomputeQuality(id) {
  const row = db
    .prepare('SELECT hit_count, feedback_pos, feedback_neg, last_hit_at, created_at FROM knowledge_item WHERE id = ?')
    .get(id);
  if (!row) return 0;

  let score = 0.5; // 基础分
  // 命中贡献：越多越好，封顶 +0.3
  score += Math.min((row.hit_count || 0) / 20, 0.3);
  // 反馈贡献：好评率加权，存在差评时权重更高（×1.5）以放大纠错信号
  const pos = row.feedback_pos || 0;
  const neg = row.feedback_neg || 0;
  const total = pos + neg;
  if (total > 0) {
    const rate = pos / total;
    const weight = neg > 0 ? 0.45 : 0.3;
    score += (rate - 0.5) * 2 * weight;
  }
  // 陈旧惩罚：近 30 天无命中 -0.1；从未命中且超 7 天 -0.08
  const now = Date.now();
  if (row.last_hit_at) {
    const last = new Date(String(row.last_hit_at).replace(' ', 'T') + 'Z').getTime();
    if (now - last > 30 * 864e5) score -= 0.1;
  } else if (row.hit_count === 0 && row.created_at) {
    const created = new Date(String(row.created_at).replace(' ', 'T') + 'Z').getTime();
    if (now - created > 7 * 864e5) score -= 0.08;
  }
  score = Math.max(0, Math.min(1, score));
  db.prepare('UPDATE knowledge_item SET quality_score = ? WHERE id = ?').run(score, id);
  return score;
}

// 反馈联动：坐标准确性 → 更新对应知识反馈统计并重算
export function bumpFeedback(id, isCorrect) {
  if (!id) return;
  if (isCorrect) {
    db.prepare('UPDATE knowledge_item SET feedback_pos = feedback_pos + 1 WHERE id = ?').run(id);
  } else {
    db.prepare('UPDATE knowledge_item SET feedback_neg = feedback_neg + 1 WHERE id = ?').run(id);
  }
  recomputeQuality(id);
}

export function recomputeAll() {
  const rows = db.prepare('SELECT id FROM knowledge_item').all();
  for (const r of rows) recomputeQuality(r.id);
  return rows.length;
}

// ---- 对话自动提炼为知识 ----
// 候选：被坐标准确信服的对话（is_correct=1），且尚未提炼过（无 knowledge_item.extracted_from 指向它）
export function getExtractCandidates(limit = 50) {
  return db
    .prepare(
      `SELECT c.id, c.user_text, c.bot_reply, c.created_at
       FROM conversation_log c
       JOIN feedback f ON f.conversation_id = c.id AND f.is_correct = 1
       WHERE c.bot_reply IS NOT NULL AND c.bot_reply <> ''
         AND NOT EXISTS (SELECT 1 FROM knowledge_item k WHERE k.extracted_from = c.id)
       ORDER BY c.id DESC LIMIT ?`
    )
    .all(limit);
}

// 自动提炼：把候选对话用 LLM 抽成 question/solution，写入 knowledge_item（source_type='conversation'）
export async function autoExtract({ limit = 50 } = {}) {
  const candidates = getExtractCandidates(limit);
  let created = 0;
  for (const c of candidates) {
    const content = `客户问题：${c.user_text}\n客服有效回复：${c.bot_reply}`;
    let ex = null;
    try {
      ex = await extractTicket(content);
    } catch {
      ex = null;
    }
    if (!ex || !ex.question) continue;
    // 统一模板入库：来源标记 conversation，关联对话 id，向量自动计算，初始质量分按内容给
    await createKnowledgeItem({
      question: ex.question,
      solution: ex.solution || c.bot_reply,
      category: ex.category || '其他',
      urgency: ex.urgency,
      source_type: 'conversation',
      extracted_from: c.id,
      status: 'draft'
    });
    created++;
  }
  return { scanned: candidates.length, created };
}
