// 知识库数据源工厂。
// 数据源选择优先级：运行时配置（.runtime-config.json）→ 环境变量 KB_SOURCE → local。
//   local  → 本地向量库（默认，零配置）
//   ima    → IMA 开放平台知识库
//   feishu → 飞书知识库
//
// 无论选哪个，对话层都通过 kbSearch() 拿统一结构的命中结果。

import { KBProvider } from './provider.js';
import { LocalProvider } from './local.js';
import { ImaProvider } from './ima.js';
import { FeishuProvider } from './feishu.js';
import { getRuntimeConfig } from '../runtimeConfig.js';

// 本地 Provider 单例：作为「基座检索层」始终参与，不受 kb_source 切换影响。
// 远程飞书/IMA 只作为「补充增强层」——即便它们失败或未配置，本地 26 条混合检索（词法+语义）
// 仍保证可用，避免「选了飞书就把本地精心优化过的库整个旁路掉」的断层。
const localProvider = new LocalProvider();

function buildProvider(source) {
  switch ((source || 'local').toLowerCase()) {
    case 'ima':
      return new ImaProvider();
    case 'feishu':
      return new FeishuProvider();
    default:
      return new LocalProvider();
  }
}

// 启动时：环境变量 KB_SOURCE 优先，其次运行时配置（前端「应用配置」写入的 kb_source），兜底 local。
// 修复：之前只读 process.env，导致 runtimeConfig 里选好的 feishu/ima 源在重启后失效。
let SOURCE = (process.env.KB_SOURCE || getRuntimeConfig().kb_source || 'local').toLowerCase();
let provider = buildProvider(SOURCE);

function logSource() {
  console.log(
    `[kb] 知识库数据源 = ${SOURCE}` +
      (provider.configured === false && SOURCE !== 'local'
        ? '（⚠ 未检测到对应凭证，检索将返回空，建议检查环境变量或使用 local）'
        : '')
  );
}
logSource();

/**
 * 运行时重载知识库数据源（供一键切换）。
 * @param {string} source
 */
export function reloadKB(source) {
  SOURCE = (source || getRuntimeConfig().kb_source || 'local').toLowerCase();
  provider = buildProvider(SOURCE);
  logSource();
  return SOURCE;
}

/**
 * 统一检索入口。
 * @param {string}  query
 * @param {number} [topK=3]
 * @returns {Promise<import('./provider.js').KBHit[]>}
 *
 * 检索优先级（硬规则）：本地基座 > 远程增强(飞书/IMA) > LLM 生成。
 * 实现方式：给每个命中打 priority（local=0，remote=1），合并后「先按 priority 升序，
 * 再按 score 降序」。这样本地强命中永远排在飞书前面——即使飞书 score 固定 0.9，
 * 也不会盖过本地更精准的词法命中。doChat 取 topHit 即可自然拿到最高优先级命中。
 */
const PRIORITY = { local: 0, feishu: 1, ima: 1 };

export async function kbSearch(query, topK = 3) {
  // 融合检索：本地基座（始终）+ 远程增强（配置且可用时）。
  // 1) 本地混合检索（含 _lex 强命中信号），先跑，保证零依赖可用。
  //    topK 放大到 10：合并时优先排本地，多取几条保证强命中不被远程 topK=3 截断。
  let localHits = [];
  try {
    localHits = await localProvider.search(query, 10);
  } catch (e) {
    console.warn(`[kb] 本地检索失败：${e.message}`);
  }

  // 2) 远程源（feishu/ima）作为补充；失败/未配置则不参与，不影响本地结果。
  let remoteHits = [];
  if (SOURCE !== 'local' && provider && provider !== localProvider) {
    try {
      remoteHits = await provider.search(query, topK);
    } catch (e) {
      console.warn(`[kb] 远程(${SOURCE})检索失败，已回落本地：${e.message}`);
    }
  }

  // 3) 合并去重：以 title 去重，给每条打来源优先级。
  //    本地命中优先保留（其 _lex / 真实 score 排序信号更可靠），远程相同 title 不覆盖本地。
  const seen = new Set();
  const merged = [];
  for (const h of [...localHits, ...remoteHits]) {
    const key = (h.title || '').trim();
    if (seen.has(key)) continue;
    seen.add(key);
    const src = (h.source || 'local').toLowerCase();
    merged.push({ ...h, priority: PRIORITY[src] ?? 1 });
  }
  return merged
    .sort((a, b) => (a.priority - b.priority) || ((b.score ?? 0) - (a.score ?? 0)))
    .slice(0, Math.max(topK, 5));
}

export function getKBSource() {
  // 融合模式下，本地基座始终在线；远程源作为增强层（可能未配置/失败）。
  return {
    source: SOURCE,
    local: true, // 本地混合检索基座始终可用
    configured: SOURCE === 'local' ? true : provider.configured !== false,
    name: SOURCE === 'local' ? 'local' : `${provider.name}+local`
  };
}

/**
 * 列出当前配置的外部知识库列表。
 * 飞书：调用 /wiki/v2/space/list 返回所有 space（space_id + space_name）。
 * IMA：返回当前配置的 kbId 对应的主知识库信息（name 由 IMA OpenAPI 返回）。
 * @returns {Promise<Array<{id:string, name:string, provider:'feishu'|'ima'}>>}
 */
export async function listKnowledgeBases() {
  const results = [];
  // 飞书
  try {
    const fp = new FeishuProvider();
    if (fp.configured) {
      // 复用 provider 自带的 listSpaces()（基于 space/get 逐个解析名称，避免空间 list 接口 404）
      const spaces = await fp.listSpaces();
      for (const s of spaces) {
        results.push({ id: s.space_id, name: s.name || s.space_id, provider: 'feishu' });
      }
    }
  } catch (e) {
    console.warn(`[kb:listKnowledgeBases] 飞书列表失败: ${e.message}`);
  }
  // IMA
  try {
    const ip = new ImaProvider();
    if (ip.configured) {
      // 用 search_knowledge_base 空查询列出真实可访问的知识库（含正确 kb_id），
      // 不再回退到配置里可能无效的占位 ID。
      const bases = await ip.listBases('', 20);
      for (const b of bases) results.push(b);
      if (!bases.length) console.warn('[kb:listKnowledgeBases] IMA 未返回任何知识库（凭证/权限问题）');
    }
  } catch (e) {
    console.warn(`[kb:listKnowledgeBases] IMA 列表失败: ${e.message}`);
  }
  return results;
}

export { KBProvider };
export default provider;
