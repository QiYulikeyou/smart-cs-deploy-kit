// 本地知识库适配器：复用现有 embed.js 向量检索，作为零配置 fallback。
// 当未配置 IMA / 飞书凭证时，对话层默认走这里，保证开箱即用。

import { searchKnowledge } from '../embed.js';
import { KBProvider } from './provider.js';

export class LocalProvider extends KBProvider {
  get name() {
    return 'local';
  }

  async search(query, topK = 3) {
    try {
      const rows = await searchKnowledge(query, topK);
      return rows.map((r) =>
        KBProvider.hit(r.question || r.title || '(无标题)', r.solution || '', 'local', {
          id: r.id,
          category: r.category,
          score: r.score,
          _lex: r._lex,
          _sem: r._sem,
          raw: r
        })
      );
    } catch (e) {
      console.warn(`[kb:local] search failed: ${e.message}`);
      return [];
    }
  }
}

export default LocalProvider;
