// 统一知识库检索接口约定。
// 所有外部/本地数据源都实现相同的方法与返回结构，对话层无需关心来源。
//
// KBHit 统一结构：
//   { title, snippet, source:'ima'|'feishu'|'local', url?, score?, raw? }
//   - score: 相似度（local 用余弦 [0,1]；外部库命中即视为高相关，固定 0.9）
//   - 对话层按 KB_THRESHOLD 过滤 score，低于阈值不直接直答，改走 LLM 综合生成
//
// 判定「命中」：hits.length > 0 且 hits[0].snippet 非空。

export const MIN_SNIPPET_LEN = 20;
// 命中直答阈值：混合检索下 score 由词法(bigram)主导、语义辅助，好匹配约 0.3~0.5，
// 故阈值校准为 0.3（纯向量时代为 0.6）。score >= 该值才作为知识直答返回，否则喂 LLM 综合生成。
export const KB_THRESHOLD = Number(process.env.KB_THRESHOLD) || 0.3;

/**
 * @typedef {Object} KBHit
 * @property {string} title
 * @property {string} snippet
 * @property {'ima'|'feishu'|'local'} source
 * @property {number} [score] 相似度 0~1
 * @property {string} [url]
 * @property {any} [raw]
 */

/**
 * 知识库数据源抽象。子类需实现 search()。
 */
export class KBProvider {
  /** @returns {string} 数据源标识 */
  get name() {
    return 'base';
  }

  /**
   * 检索知识库。
   * @param {string} query 用户问题
   * @param {number} [topK=3]
   * @returns {Promise<KBHit[]>}
   */
  // eslint-disable-next-line no-unused-vars
  async search(query, topK = 3) {
    return [];
  }

  /**
   * 统一把原始命中整理成 KBHit；子类可覆写以适配各自的字段。
   * @protected
   */
  static hit(title, snippet, source, extra = {}) {
    return { title: title || '', snippet: snippet || '', source, ...extra };
  }
}

export default KBProvider;
