// 飞书知识库适配器。
// 用自建应用 app_id/app_secret 换取 tenant_access_token，再调用云文档搜索接口。
//
// 必填环境变量：
//   FEISHU_APP_ID
//   FEISHU_APP_SECRET
//   FEISHU_SPACE_IDS   （知识库空间 ID，逗号分隔；限定检索范围）
//
// 检索流程：
//   1) auth/v3/tenant_access_token/internal → token（缓存，过期前复用）
//   2) search/v2/doc_wiki/search（带 wiki_filter.space_ids）→ title_highlighted + summary_highlighted + url
//   3) 若摘要过短 → 按返回 token 调 wiki/document 接口补全正文

import { KBProvider, MIN_SNIPPET_LEN } from './provider.js';
import { getRuntimeConfig } from '../runtimeConfig.js';

const FS_BASE = 'https://open.feishu.cn/open-apis';

export class FeishuProvider extends KBProvider {
  constructor() {
    super();
    // 优先读运行时配置（前端「应用配置」写入的 .runtime-config.json），兜底环境变量。
    // 修复：之前只读 process.env，导致前端填好的飞书凭证不生效。
    const rc = getRuntimeConfig();
    this.appId = process.env.FEISHU_APP_ID || rc.feishu_app_id || '';
    this.appSecret = process.env.FEISHU_APP_SECRET || rc.feishu_app_secret || '';
    this.spaceIds = (process.env.FEISHU_SPACE_IDS || rc.feishu_space_ids || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    this.configured = Boolean(this.appId && this.appSecret && this.spaceIds.length);
    this._token = '';
    this._tokenExpire = 0; // 秒级时间戳
  }

  get name() {
    return 'feishu';
  }

  async _getToken() {
    const now = Math.floor(Date.now() / 1000);
    if (this._token && now < this._tokenExpire - 60) return this._token;
    const r = await fetch(`${FS_BASE}/auth/v3/tenant_access_token/internal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app_id: this.appId, app_secret: this.appSecret })
    });
    if (!r.ok) throw new Error(`Feishu auth HTTP ${r.status}`);
    const j = await r.json();
    if (j.code !== 0) throw new Error(`Feishu auth err ${j.code}: ${j.msg}`);
    this._token = j.tenant_access_token;
    this._tokenExpire = now + (j.expire || 7200);
    return this._token;
  }

  async _post(apiPath, body, token) {
    const r = await fetch(`${FS_BASE}${apiPath}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(body)
    });
    if (!r.ok) {
      // 飞书错误响应通常仍是 JSON（含 code/msg），尽量带出细节便于排查，而非只说 HTTP 状态码。
      let detail = '';
      try {
        const errj = await r.json();
        detail = ` (code=${errj.code}, msg=${errj.msg})`;
      } catch {
        detail = ` (${await r.text().catch(() => '')})`.slice(0, 200);
      }
      throw new Error(`Feishu HTTP ${r.status}${detail}`);
    }
    const j = await r.json();
    if (j.code !== 0) throw new Error(`Feishu ${apiPath} err ${j.code}: ${j.msg}`);
    return j.data || {};
  }

  // GET 请求封装（飞书部分接口如 docx 文档正文是 GET 方法，用 POST 会 404）
  async _get(apiPath, token) {
    const r = await fetch(`${FS_BASE}${apiPath}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!r.ok) {
      let detail = '';
      try {
        const errj = await r.json();
        detail = ` (code=${errj.code}, msg=${errj.msg})`;
      } catch {
        detail = ` (${await r.text().catch(() => '')})`.slice(0, 200);
      }
      throw new Error(`Feishu HTTP ${r.status}${detail}`);
    }
    const j = await r.json();
    if (j.code !== 0) throw new Error(`Feishu ${apiPath} err ${j.code}: ${j.msg}`);
    return j.data || {};
  }

  // 列出所有可用知识库（space），返回 [{space_id, name}]
  // 飞书 Wiki API: POST /wiki/v2/space/list（单数 space）
  async listSpaces() {
    if (!this.configured) return [];
    try {
      const token = await this._getToken();
      // 尝试从配置中已知的 spaceIds 获取名称映射
      const results = [];
      for (const spaceId of this.spaceIds) {
        try {
          const r = await this._post('/wiki/v2/space/get', { space_id: spaceId }, token);
          results.push({ space_id: spaceId, name: r.name || `飞书知识库-${spaceId}` });
        } catch {
          results.push({ space_id: spaceId, name: `飞书知识库-${spaceId}` });
        }
      }
      return results;
    } catch (e) {
      console.warn(`[kb:feishu] listSpaces failed: ${e.message}`);
      // 兜底：返回配置的 spaceIds
      return this.spaceIds.map((id) => ({ space_id: id, name: `飞书知识库-${id}` }));
    }
  }

  async search(query, topK = 3) {
    if (!this.configured) return [];
    try {
      const token = await this._getToken();
      // 同一搜索接口同时支持 doc_filter（普通云文档）与 wiki_filter（知识库）。
      // 用户知识库可能同时含两类内容（本项目中即普通云文档），故两者并行检索后合并去重，
      // 避免「只配了 wiki_filter 导致云文档完全搜不到」的断层（实测：仅 wiki_filter 对云文档返回 0 结果）。
      const pageSize = Math.min(Math.max(topK, 1), 20);
      const [docRes, wikiRes] = await Promise.all([
        this._post('/search/v2/doc_wiki/search', { query, doc_filter: {}, page_size: pageSize }, token).catch(() => ({})),
        this.spaceIds.length
          ? this._post('/search/v2/doc_wiki/search', { query, wiki_filter: { space_ids: this.spaceIds }, page_size: pageSize }, token).catch(() => ({}))
          : Promise.resolve({})
      ]);
      const units = [...(docRes.res_units || []), ...(wikiRes.res_units || [])];
      // 去重（按 url 或 title）
      const seen = new Set();
      const dedup = [];
      for (const u of units) {
        const key = (u.result_meta && u.result_meta.url) || (u.title_highlighted || '');
        if (seen.has(key)) continue;
        seen.add(key);
        dedup.push(u);
      }
      const hits = [];
      for (const [idx, u] of dedup.slice(0, topK).entries()) {
        let title = '';
        let snippet = '';
        let url;
        // res_units 结构在云文档与 wiki 下基本一致：title_highlighted / summary_highlighted / result_meta.{url,token}
        if (u.title_highlighted) title = u.title_highlighted.replace(/<[^>]+>/g, '');
        if (u.summary_highlighted) snippet = u.summary_highlighted.replace(/<[^>]+>/g, '');
        const meta = u.result_meta || {};
        url = meta.url;
        // 摘要过短 → 尝试取正文（docx raw_content 是 GET 方法，token 即文档 token）
        // 拿到正文后 LLM 提炼 FAQ / 向量检索才有足够上下文（飞书 search 默认只回标题级 snippet）
        // 只对前 8 条取正文：避免每条都打 docx 接口拖慢同步/提炼（前 8 条已覆盖提炼与入库所需）
        if (idx < 8 && snippet.length < MIN_SNIPPET_LEN && meta.token) {
          try {
            const doc = await this._get(`/docx/v1/documents/${meta.token}/raw_content`, token);
            const full = doc?.content || '';
            if (full) snippet = full.slice(0, 2000);
          } catch {
            /* 取正文失败不影响主流程，退化用短 snippet */
          }
        }
        hits.push(
          KBProvider.hit(title || '(无标题)', snippet, 'feishu', {
            url,
            score: 0.9, // 外部库命中即视为高相关（已做相关性排序）
            raw: u
          })
        );
      }
      return hits;
    } catch (e) {
      // 权限类错误（飞书 99991672 = 应用未开通 search:docs:read）是可操作的，单独识别并给开通指引，
      // 避免运维只看到模糊的 "search failed"。其他错误继续原样提示。
      if (/99991672/.test(e.message)) {
        const url = `https://open.feishu.cn/app/${this.appId}/auth`;
        console.error(
          `[kb:feishu] ⚠ 检索失败：应用尚未开通「search:docs:read」权限。\n` +
            `           请在飞书开放平台为自建应用(${this.appId})添加该「应用身份权限」并发布版本：\n` +
            `           ${url}  →  权限管理 → 搜索 → 勾选 search:docs:read → 创建版本并发布\n` +
            `           （仅「可用范围」授权不够，必须是应用身份权限且发布生效）`
        );
      } else {
        console.warn(`[kb:feishu] search failed: ${e.message}`);
      }
      return [];
    }
  }
}

export default FeishuProvider;
