// IMA 知识库适配器。
// 直接 HTTP 调用 IMA OpenAPI（https://ima.qq.com/openapi/wiki/v1），
// 不依赖 ima_api.cjs 子进程，适合后端常驻高频检索。
//
// 凭证优先级：环境变量 → 配置文件 ~/.config/ima/{client_id,api_key}
// 必填环境变量：
//   IMA_OPENAPI_CLIENTID / IMA_OPENAPI_APIKEY （或配置文件）
//   IMA_KB_ID                                （目标知识库 ID，search_knowledge 必填）
//
// 检索流程：
//   1) search_knowledge → title + highlight_content（命中片段，可直接作答）
//   2) 若片段为空 → get_media_info 取 URL/笔记，再拉原文首段补全

import fs from 'node:fs';
import path from 'node:path';
import { KBProvider, MIN_SNIPPET_LEN } from './provider.js';
import { getRuntimeConfig } from '../runtimeConfig.js';

const IMA_BASE = 'https://ima.qq.com/openapi/wiki/v1';

function loadCredentials() {
  const rc = getRuntimeConfig();
  let clientId = process.env.IMA_OPENAPI_CLIENTID || rc.ima_client_id || '';
  let apiKey = process.env.IMA_OPENAPI_APIKEY || rc.ima_api_key || '';
  if (!clientId || !apiKey) {
    try {
      const dir = path.join(process.env.HOME || process.env.USERPROFILE || '', '.config', 'ima');
      if (!clientId) clientId = fs.readFileSync(path.join(dir, 'client_id'), 'utf8').trim();
      if (!apiKey) apiKey = fs.readFileSync(path.join(dir, 'api_key'), 'utf8').trim();
    } catch {
      /* ignore */
    }
  }
  return { clientId, apiKey };
}

export class ImaProvider extends KBProvider {
  constructor() {
    super();
    // 优先读运行时配置（前端「应用配置」写入的 .runtime-config.json），兜底环境变量/本地文件。
    const rc = getRuntimeConfig();
    this.kbId = process.env.IMA_KB_ID || rc.ima_kb_id || '';
    const { clientId, apiKey } = loadCredentials();
    this.clientId = clientId;
    this.apiKey = apiKey;
    this.configured = Boolean(this.clientId && this.apiKey && this.kbId);
  }

  get name() {
    return 'ima';
  }

  /**
   * 列出当前凭证可访问的全部知识库（IMA 无「列全部」接口，用 search_knowledge_base 空查询实现）。
   * @returns {Promise<Array<{id:string,name:string,provider:'ima'}>>}
   */
  async listBases(query = '', limit = 20) {
    if (!this.configured) return [];
    try {
      const data = await this._post('/search_knowledge_base', { query, cursor: '', limit });
      const list = data.info_list || [];
      return list
        .filter((k) => k.kb_id)
        .map((k) => ({ id: k.kb_id, name: k.kb_name || k.kb_id, provider: 'ima' }));
    } catch {
      return [];
    }
  }

  async _post(apiPath, body) {
    const headers = {
      'Content-Type': 'application/json',
      'ima-openapi-clientid': this.clientId,
      'ima-openapi-apikey': this.apiKey
    };
    const r = await fetch(`${IMA_BASE}${apiPath}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error(`IMA HTTP ${r.status}`);
    const j = await r.json();
    if (j.code !== 0) throw new Error(`IMA ${apiPath} err ${j.code}: ${j.msg}`);
    return j.data || {};
  }

  async search(query, topK = 3, kbId = null) {
    if (!this.configured) return [];
    try {
      const targetKbId = kbId || this.kbId;
      if (!targetKbId) throw new Error('IMA 知识库 ID 未配置');
      const data = await this._post('/search_knowledge', {
        query,
        cursor: '',
        knowledge_base_id: targetKbId
      });
      const list = data.info_list || [];
      const hits = [];
      for (const item of list.slice(0, topK)) {
        let snippet = item.highlight_content || '';
        let url;
        // 片段过短 → 尝试取原文首段补全
        if (snippet.length < MIN_SNIPPET_LEN && item.media_id) {
          try {
            const media = await this._post('/get_media_info', { media_id: item.media_id });
            if (media.url_info && media.url_info.url) {
              url = media.url_info.url;
              snippet = snippet || `[原文] ${url}`;
            }
          } catch {
            /* 取原文失败不影响主流程 */
          }
        }
        hits.push(
          KBProvider.hit(item.title || '(无标题)', snippet, 'ima', {
            url,
            score: 0.9, // 外部库命中即视为高相关（已做相关性排序）
            raw: item
          })
        );
      }
      return hits;
    } catch (e) {
      console.warn(`[kb:ima] search failed: ${e.message}`);
      return [];
    }
  }
}

export default ImaProvider;
