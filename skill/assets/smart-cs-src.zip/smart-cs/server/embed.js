import db from './db.js';
import { embedText } from './llm.js';

// 文本向量化：委托给 llm.js（真实 embedding 或离线回退）。统一异步，检索逻辑无需改动。
export async function embed(text = '') {
  return embedText(text);
}

// 文档向量文本构造策略（单一事实来源）。
// 设计：检索是「用户提问 ↔ 知识标准问」的对称匹配，因此文档向量以 question（最可区分的
// 用户意图表达）为主，叠加 category / product_module 轻量领域信号；刻意剔除 solution —— 因为
// 多条知识的 solution 常常是高度雷同的模板话术，混入会让向量被共性后缀主导、彼此挤在 0.7 附近
// 失去区分度（历史已知问题）。solution 仅作为命中后的「答案文本」返回，不参与向量匹配。
// 这样每条约化文档向量由其独特的问法主导，检索排序区分度显著提升。
export function buildDocText(it = {}) {
  const parts = [];
  const q = (it.question || it.title || '').toString().trim();
  if (q) parts.push(q);
  const cat = (it.category || '').toString().trim();
  if (cat) parts.push('类别：' + cat);
  const mod = (it.product_module || it.module || '').toString().trim();
  if (mod) parts.push('模块：' + mod);
  if (parts.length) return parts.join('\n');
  // 兜底：完全没有问法/类别时，退回 solution 前 200 字，保证不产生空向量
  const sol = (it.solution || it.content || '').toString().trim();
  return sol ? sol.slice(0, 200) : '空知识条目';
}

// 知识条目向量化（写入 / 重算时统一调用，保证与检索侧一致）
export async function embedKnowledge(it = {}) {
  return embedText(buildDocText(it));
}

export function cosine(a, b) {
  if (!a || !b || a.length !== b.length) return 0; // 维度不一致视为不相关
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return dot; // 真实 embedding 通常已归一化；离线向量此处也已归一化
}

export function parseEmbedding(str) {
  try {
    const v = JSON.parse(str);
    return Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

// 中文词法相似度：字符 bigram 的 Dice 系数。
// 动机：nomic-embed-text 等英文向 embedding 模型对中文语义区分度很差（实测「退款」与
// 「路由器」的余弦相似度反而高于与「申请退款」），纯向量检索会答非所问。中文 FAQ 靠共享
// 字词（退款/发票/路由器/密码）即可精准区分，因此用字符 bigram 重叠度作为主信号，语义向量
// 仅作辅助，混合排序后召回准确率与区分度都显著提升。
function bigrams(s) {
  const t = (s || '').replace(/\s+/g, '');
  const set = new Set();
  for (let i = 0; i < t.length - 1; i++) set.add(t.slice(i, i + 2));
  return set;
}
// 轻量同义词扩展：中文 FAQ 常因用词不同（快递/物流、退款/退货）而漏匹配，追加别名词面
// 让双方 bigram 能交叉命中。仅覆盖高频客服同义词，零依赖、可维护。
const SYNONYMS = {
  快递: '物流', 退款: '退货 退钱', 退货: '退款', 密码: '登录 验证', 登录: '密码',
  发票: '开票', 开票: '发票', 路由器: '网络', 网速: '网络 宽带', 网络: '路由器',
  投诉: '反馈 建议', 会员: '权益', 权益: '会员', 优惠券: '折扣 代金券', 保修: '维修 质保',
  破损: '损坏 坏', 损坏: '破损', 质量: '瑕疵 毛病', 瑕疵: '质量', 发货: '寄出 出库',
  支付: '付款 扣款', 扣款: '支付', 账号: '账户', 账户: '账号'
};
function expandSyn(text) {
  let out = text || '';
  for (const [k, v] of Object.entries(SYNONYMS)) {
    if (out.includes(k)) out += ' ' + v;
  }
  return out;
}
function lexicalScore(query, doc) {
  const A = bigrams(expandSyn(query));
  const B = bigrams(expandSyn(doc));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const g of A) if (B.has(g)) inter++;
  return (2 * inter) / (A.size + B.size); // Dice ∈ [0,1]
}

// 知识库混合检索：词法(bigram)为主 + 语义向量为辅，返回 Top-K
export async function searchKnowledge(query, topK = 5) {
  // 语义向量为「辅助信号」：ollama 慢/限流/宕机时绝不应拖垮整条检索链路。
  // 故 embed 失败则降级为纯词法（sem=0），保证检索永远可用、低延迟。
  let qv = null;
  try {
    qv = await embed(query);
  } catch (e) {
    console.warn(`[embed] 语义向量获取失败，降级纯词法：${e.message}`);
  }
  const rows = db
    .prepare("SELECT id, question, solution, category, embedding, hit_count FROM knowledge_item WHERE status = 'published'")
    .all();
  const scored = rows
    .map((r) => {
      const vec = parseEmbedding(r.embedding);
      const sem = qv && vec && vec.length === qv.length ? Math.max(0, cosine(qv, vec)) : 0;
      // 词法仅用 question + category（短文本、区分度高）；把冗长 solution 排除，避免 Dice 分母
      // 被答案长度稀释导致好匹配分数被压低。nomic 对中文语义不可靠，故词法权重 0.9、语义 0.1。
      const lex = lexicalScore(query, [r.question, r.category].filter(Boolean).join('\n'));
      const score = 0.9 * lex + 0.1 * sem;
      return { ...r, score, _lex: lex, _sem: sem };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);

  // 命中计数（仅首条）+ 刷新最近命中时间，供质量评分的「陈旧惩罚」使用
  if (scored[0]) {
    db.prepare("UPDATE knowledge_item SET hit_count = hit_count + 1, last_hit_at = datetime('now') WHERE id = ?").run(scored[0].id);
  }
  return scored;
}
