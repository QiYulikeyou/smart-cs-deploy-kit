import initSqlJs from 'sql.js';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// 数据持久化路径：优先用环境变量（PM2/Docker 设到 releases 之外），否则落到项目根 data/
// 关键：用 import.meta.url 解析（ESM 无 __dirname），避免依赖 process.cwd()——
// 历史上因启动目录不同导致读写 D:/workbuddy/data 与 D:/workbuddy/smart-cs/data 两个库，
// 出现「34条/0条预警」来回跳的错乱。
const DB_PATH = process.env.DB_PATH || fileURLToPath(new URL('../data/app.sqljs.db', import.meta.url));
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

// ---- sql.js 初始化（纯 WASM，零原生编译，跨 Node 版本无 ABI 烦恼）----
let SQL = null;
let _db = null;

// 兼容 better-sqlite3 的语句 facade：prepare().get/.all/.run
// sql.js 只有 db.prepare() 出 statement，再用 getAsObject()/step()/run()
function makeStmt(db, sql) {
  return {
    get(...params) {
      const safe = params.map((p) => (p === undefined ? null : p));
      const stmt = db.prepare(sql);
      const row = stmt.get(safe); // 第一行值数组，无结果返回 undefined 或 []
      if (!row || (Array.isArray(row) && row.length === 0)) return undefined;
      return stmt.getAsObject(safe);
    },
    all(...params) {
      const safe = params.map((p) => (p === undefined ? null : p));
      const stmt = db.prepare(sql);
      // sql.js 需先 bind 参数再 step；否则占位符未绑定（LIMIT/OFFSET 等会 datatype mismatch）
      if (safe.length) stmt.bind(safe);
      const out = [];
      while (stmt.step()) {
        out.push(stmt.getAsObject());
      }
      return out;
    },
    run(...params) {
      // sql.js 不允许 undefined 绑定，统一转 null（SQLite NULL）
      const safe = params.map((p) => (p === undefined ? null : p));
      const stmt = db.prepare(sql);
      stmt.run(safe);
      let lastInsertRowid = 0;
      try {
        const rows = _db.exec('SELECT last_insert_rowid() AS id');
        if (rows.length && rows[0].values.length) lastInsertRowid = rows[0].values[0][0];
      } catch {}
      const changes = db.getRowsModified();
      flush();
      return { lastInsertRowid, changes };
    }
  };
}

// sql.js 对每条语句自动原子提交；此处 transaction 仅作为兼容包装，
// 直接执行回调（每条 run 内部已原子落盘）。保持与 better-sqlite3 同签名。
function transaction(fn) {
  return (...args) => {
    const out = fn(...args);
    flush();
    return out;
  };
}

// 把内存库落盘（sql.js 是内存库，必须手动持久化）
function flush() {
  if (!_db) return;
  const data = _db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// 同步初始化（模块加载时完成，整个应用启动前 await ready）
async function init() {
  SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const buf = fs.readFileSync(DB_PATH);
    _db = new SQL.Database(new Uint8Array(buf));
  } else {
    _db = new SQL.Database();
  }

  _db.run(`
  CREATE TABLE IF NOT EXISTS knowledge_item (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    question         TEXT,
    solution         TEXT,
    category         TEXT,
    product_module   TEXT,
    urgency          INTEGER,
    source_ticket_id INTEGER,
    embedding        TEXT,
    hit_count        INTEGER DEFAULT 0,
    quality_score    REAL DEFAULT 0.5,
    feedback_pos     INTEGER DEFAULT 0,
    feedback_neg     INTEGER DEFAULT 0,
    last_hit_at      TEXT,
    source_type      TEXT DEFAULT 'manual',
    extracted_from   INTEGER,
    created_at       TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS ticket (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source          TEXT,
    content         TEXT,
    category        TEXT,
    urgency         INTEGER,
    customer_level  TEXT,
    assignee        INTEGER,
    status          TEXT DEFAULT 'pending',
    confidence      REAL,
    created_at      TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS feedback (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER,
    is_correct      INTEGER DEFAULT 0,
    agent_id        INTEGER,
    comment         TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS site_tokens (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id      TEXT UNIQUE NOT NULL,
    site_name    TEXT,
    site_url     TEXT,
    adapter      TEXT,            -- 电商适配器类型：amazon / tumi / generic / null（不接入）
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS script_template (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    knowledge_id  INTEGER,
    scene         TEXT,
    turns         TEXT,
    trigger_cond  TEXT,
    status        TEXT DEFAULT 'draft',
    reviewer      INTEGER,
    created_at    TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (knowledge_id) REFERENCES knowledge_item(id)
  );

  CREATE TABLE IF NOT EXISTS agent_profile (
    agent_id         INTEGER PRIMARY KEY,
    skill_tags       TEXT,
    avg_satisfaction REAL,
    load_current     INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS qa_record (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER,
    ticket_id       INTEGER,
    sensitive_hits  TEXT,
    emotion_trend   TEXT,
    risk_level      TEXT,
    needs_review    INTEGER DEFAULT 0,
    reviewer        INTEGER,
    created_at      TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversation_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   TEXT,
    user_id      INTEGER,
    user_role    TEXT,
    is_agent     INTEGER DEFAULT 0,
    user_text    TEXT,
    bot_reply    TEXT,
    source       TEXT,
    kb_source    TEXT,
    risk_level   TEXT,
    cited_json   TEXT,
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT UNIQUE NOT NULL,
    password_hash  TEXT NOT NULL,
    role           TEXT NOT NULL DEFAULT 'agent',
    display_name   TEXT,
    created_at     TEXT DEFAULT (datetime('now'))
  );
  `);

  // 兼容旧库：script_template 可能缺少 knowledge_id 列
  try {
    _db.run('ALTER TABLE script_template ADD COLUMN knowledge_id INTEGER');
  } catch {}
  try {
    _db.run('CREATE INDEX IF NOT EXISTS idx_script_knowledge ON script_template(knowledge_id)');
  } catch {}
  // 兼容旧库：conversation_log 可能在旧版 schema 下已建表（无 user_id/user_role/is_agent）。
  // ALTER ADD COLUMN 对不存在的列补上；已存在的列会抛错，忽略即可。
  for (const col of ['user_id INTEGER', 'user_role TEXT', 'is_agent INTEGER DEFAULT 0']) {
    const name = col.split(' ')[0];
    try {
      _db.run(`ALTER TABLE conversation_log ADD COLUMN ${col}`);
    } catch {
      /* 列已存在 */
    }
  }
  // 新增 feedback 和 site_tokens 表（兼容旧库）
  try {
    _db.run(`ALTER TABLE qa_record ADD COLUMN note TEXT`);
  } catch {}
  try {
    _db.run(`
      CREATE TABLE IF NOT EXISTS feedback (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id INTEGER,
        is_correct      INTEGER DEFAULT 0,
        agent_id        INTEGER,
        comment         TEXT,
        created_at      TEXT DEFAULT (datetime('now'))
      )
    `);
  } catch {}
  try {
    _db.run(`
      CREATE TABLE IF NOT EXISTS site_tokens (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        site_id      TEXT UNIQUE NOT NULL,
        site_name    TEXT,
        site_url     TEXT,
        adapter      TEXT,
        created_at   TEXT DEFAULT (datetime('now'))
      )
    `);
  } catch {}
  // 兼容旧库：site_tokens 可能已存在且无 adapter 列
  try {
    _db.run(`ALTER TABLE site_tokens ADD COLUMN adapter TEXT`);
  } catch {}
  // 兼容旧库：knowledge_item 可能缺少质量评分相关列（quality_score / 反馈统计 / 来源标记）
  for (const col of [
    'quality_score REAL DEFAULT 0.5',
    'feedback_pos INTEGER DEFAULT 0',
    'feedback_neg INTEGER DEFAULT 0',
    'last_hit_at TEXT',
    'source_type TEXT DEFAULT \'manual\'',
    'extracted_from INTEGER',
    "status TEXT DEFAULT 'published'"
  ]) {
    try {
      _db.run(`ALTER TABLE knowledge_item ADD COLUMN ${col}`);
    } catch {
      /* 列已存在 */
    }
  }
  // 兼容旧库：users 表新增 agent_id 字段（绑定用户到客服组）
  try {
    _db.run('ALTER TABLE users ADD COLUMN agent_id INTEGER');
  } catch {}
  // 新增：知识条目关联具体知识库名（飞书 space / IMA KB）
  try {
    _db.run(`ALTER TABLE knowledge_item ADD COLUMN knowledge_base_name TEXT DEFAULT NULL`);
  } catch { /* 列已存在 */ }
  // 数据归一（幂等）：历史飞书 / IMA 同步条目此前 source_type 默认 manual，纠正为统一来源标记；
  // 存量 manual 即历史上的「历史FAQ」手工条目，纠正为 faq，使「来源」徽章与统一模板一致。
  try {
    _db.run(`UPDATE knowledge_item SET source_type='feishu' WHERE category='飞书同步' AND (source_type IS NULL OR source_type='manual')`);
    _db.run(`UPDATE knowledge_item SET source_type='ima' WHERE category='IMA同步' AND (source_type IS NULL OR source_type='manual')`);
    _db.run(`UPDATE knowledge_item SET source_type='faq' WHERE source_type='manual'`);
  } catch {}
  // 回填 knowledge_base_name：历史同步条目补默认名
  try {
    _db.run(`UPDATE knowledge_item SET knowledge_base_name='飞书知识库' WHERE source_type='feishu' AND knowledge_base_name IS NULL`);
    _db.run(`UPDATE knowledge_item SET knowledge_base_name='IMA知识库' WHERE source_type='ima' AND knowledge_base_name IS NULL`);
  } catch {}
  flush();
}

// facade：对外暴露与 better-sqlite3 相同的接口
const db = {
  get ready() {
    return !!_db;
  },
  prepare(sql) {
    return makeStmt(_db, sql);
  },
  transaction,
  exec(sql) {
    _db.run(sql);
    flush();
  },
  // 供外部在初始化完成后触发一次落盘
  flush
};

// 立即初始化（模块顶层 await 不可用，故导出 init 由 index.js 调用；同时为兼容现有 import 同步用法，这里直接 init 并缓存 Promise）
const readyPromise = init();

export default db;
export { DB_PATH, readyPromise, init };
