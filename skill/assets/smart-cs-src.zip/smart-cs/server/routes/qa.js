import db from '../db.js';
import { getAdapter, listAdapters } from '../adapters/index.js';
import { detect } from '../qa.js';
import { generateReply, getLLMInfo, reloadLLM } from '../llm.js';
import { kbSearch, getKBSource, reloadKB } from '../kb/index.js';
import { KB_THRESHOLD } from '../kb/provider.js';
import { setRuntimeConfig } from '../runtimeConfig.js';
import { requirePerm } from '../auth.js';
import { bumpFeedback } from '../kb/quality.js';
import { searchScripts } from './scripts.js';
import { getCompanyProfile } from '../companyProfile.js';

// 容错 JSON 解析（cited_json 等字段可能损坏）
function safeParse(s) {
  if (!s) return [];
  try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; }
}

// 质检：检测 + 待复核预警列表 + 智能对话
export default async function qaRoutes(fastify) {
  // 核心对话逻辑（内部 chat 与公开 chat 复用）
  // opts.mode: 'knowledge'（默认，仅知识库）| 'scripts'（仅话术库）| 'both'（知识+话术）
  async function doChat(text, history, opts = {}) {
    if (!text) return { reply: '', hits: [], source: 'empty', threshold: KB_THRESHOLD };

    const mode = opts.mode === 'scripts' || opts.mode === 'both' ? opts.mode : 'knowledge';
    const kbSrc = getKBSource();
    // 访客端（官网挂件）标记：只输出答案正文，不暴露知识库来源、原文链接、
    // 相关知识、相似度等内部信息；坐席端/管理台保持完整溯源。
    const isPublic = opts.public === true;

    // 强命中判定：本地混合检索命中带 _lex（词法相似度），用 _lex>=0.2 最可靠；
    // 飞书/IMA 等外部源无 _lex，回退到 score>=KB_THRESHOLD。
    const isStrong = (h) =>
      h._lex !== undefined ? h._lex >= 0.2 : (h.score ?? 0) >= KB_THRESHOLD;

    // 1) 知识库检索（按 KB_SOURCE 路由到对应适配器）
    let kbHits = [];
    if (mode === 'knowledge' || mode === 'both') {
      kbHits = await kbSearch(text, 5);
    }
    const strongKb = kbHits
      .filter((h) => {
        if (h._lex !== undefined && h._lex >= 0.2) return true;
        return h.snippet && h.snippet.trim().length > 0 && isStrong(h);
      })
      .sort((a, b) => (a.priority ?? 0) - (b.priority ?? 0) || ((b.score ?? 0) - (a.score ?? 0)));
    const topKb = strongKb[0] || null;

    // 2) 话术库检索（关键词匹配已发布话术）
    let scriptHits = [];
    if (mode === 'scripts' || mode === 'both') {
      scriptHits = searchScripts(text, 5);
    }
    const topScript = scriptHits[0] || null;

    // 3) 强命中直接返回：
    //    - both 模式：话术库强命中优先于知识库（话术是坐席标准口径，优先采用；知识库作补充展示）
    //    - 单源模式（knowledge / scripts）：各自强命中即返回
    const kbStrong = topKb;
    const scriptStrong = topScript;

    const buildKbReply = (top) => {
      const others = strongKb
        .slice(1, 3)
        .map((h) => `· ${h.title}（相似度 ${(h.score ?? 0).toFixed(2)}）`)
        .join('\n');
      const srcLabel = top.source === 'ima' ? 'IMA 知识库' : top.source === 'feishu' ? '飞书知识库' : '本地知识库';
      const answer = top.snippet && top.snippet.trim().length ? top.snippet : top.title;
      // 访客端：直接给答案正文；坐席端：带来源标注、原文链接与相关知识
      const reply = isPublic
        ? answer
        : `📌 来自「${srcLabel}」的匹配答案：\n${answer}` +
          (top.url ? `\n\n🔗 原文：${top.url}` : '') +
          (others ? `\n\n🔗 相关知识：\n${others}` : '');
      return {
        reply,
        hits: strongKb,
        source: top.source,
        kb_source: kbSrc.source,
        threshold: KB_THRESHOLD,
        mode,
        script_hits: mode === 'both' ? scriptHits.slice(0, 3) : [],
        cited: [{ id: top.id, title: top.title, source: top.source, score: top.score, url: top.url }]
      };
    };

    const buildScriptReply = (top) => ({
      reply: isPublic
        ? top.replyText
        : `💬 来自「已发布话术库」的匹配话术（场景：${top.scene}）：\n\n${top.replyText}`,
      hits: [],
      source: 'script',
      kb_source: kbSrc.source,
      threshold: KB_THRESHOLD,
      mode,
      script_hits: scriptHits.slice(0, 3),
      cited: [{ id: top.id, title: top.scene, source: 'script', score: top.score }]
    });

    if (mode === 'both') {
      if (scriptStrong) return buildScriptReply(scriptStrong);
      if (kbStrong) return buildKbReply(kbStrong);
    } else {
      if (kbStrong) return buildKbReply(kbStrong);
      if (scriptStrong) return buildScriptReply(scriptStrong);
    }

    // 5) 弱命中 / 未命中 → 把知识 + 话术作为 context 喂 LLM 综合生成
    const contextKb = kbHits
      .filter((h) => h.snippet && h.snippet.trim().length)
      .slice(0, 3)
      .map((h, i) => `${i + 1}. [${h.title}] ${h.snippet}`)
      .join('\n');
    const contextScript = scriptHits
      .slice(0, 3)
      .map((s, i) => `参考话术${i + 1}（场景：${s.scene}）：${s.replyText}`)
      .join('\n');
    // 访客端：注入企业官方档案（来自部署配置 tenant 节），保证弱命中/未命中时 LLM 也有准确依据，不凭空编造
    let context = [isPublic ? getCompanyProfile() : '', contextKb, contextScript].filter(Boolean).join('\n\n');

    // 5.1) 电商实时数据注入：命中适配器意图时，把订单/物流/退货/商品等真实数据注入 LLM context
    let commerce = null;
    if (opts.adapter) {
      try {
        const r = await opts.adapter.resolve(text, { orderId: opts.orderId });
        if (r && r.context) {
          context = (context ? context + '\n\n' : '') + r.context;
          commerce = { intent: r.intent, data: r.data };
        }
      } catch (e) {
        console.error('[commerce] resolve error', e);
      }
    }

    const reply = await generateReply(text, { context, history, public: isPublic });
    const citedKb = kbHits
      .filter((h) => h.snippet && h.snippet.trim().length)
      .slice(0, 3)
      .map((h) => ({ id: h.id, title: h.title, source: h.source, score: h.score, url: h.url }));
    return {
      reply,
      hits: kbHits.filter((h) => h.snippet && h.snippet.trim().length).slice(0, 3),
      source: 'llm',
      kb_source: kbSrc.source,
      threshold: KB_THRESHOLD,
      script_hits: scriptHits.slice(0, 3),
      cited: citedKb,
      commerce
    };
  }

  fastify.post(
    '/api/qa/detect',
    { preHandler: requirePerm('qa:write') },
    async (req) => {
    const text = (req.body?.text || '').toString();
    const r = detect(text);
    const info = db
      .prepare(
        'INSERT INTO qa_record (conversation_id, sensitive_hits, emotion_trend, risk_level, needs_review) VALUES (?,?,?,?,?)'
      )
      .run(
        req.body?.conversation_id ?? null,
        JSON.stringify(r.sensitive_hits),
        r.emotion,
        r.risk_level,
        r.needs_review ? 1 : 0
      );
    return { id: info.lastInsertRowid, ...r };
  });

  fastify.get(
    '/api/qa/alerts',
    { preHandler: requirePerm('qa:read') },
    async () => {
      return db
        .prepare(
          `SELECT qr.id, qr.conversation_id, qr.risk_level, qr.emotion_trend,
                  qr.sensitive_hits, qr.created_at, cl.user_text
           FROM qa_record qr
           LEFT JOIN conversation_log cl ON cl.id = qr.conversation_id
           WHERE qr.needs_review = 1 ORDER BY qr.id DESC`
        )
        .all();
    }
  );

  // 标为已读：将 qa_record.needs_review 置为 0，从待复核列表中移除
  fastify.delete(
    '/api/qa/alert/:id',
    { preHandler: requirePerm('qa:write') },
    async (req, reply) => {
      const { id } = req.params;
      const info = db.prepare('UPDATE qa_record SET needs_review = 0 WHERE id = ? AND needs_review = 1').run(id);
      if (info.changes === 0) return reply.code(404).send({ error: 'not found or already read' });
      return { ok: true, id: Number(id) };
    }
  );

  // 批量清理无内容的告警：只删除「待复核且内容不全」的预警——即关联不到会话，
  // 或关联会话的 user_text 为空/空白；保留有实际对话内容的完整预警。
  // 注意：之前用 conversation_id IS NULL OR ticket_id IS NULL 会误删所有预警（ticket_id 恒为 null），已改正。
  fastify.post(
    '/api/qa/alerts/cleanup-empty',
    { preHandler: requirePerm('qa:write') },
    async () => {
      const rows = db
        .prepare(
          `SELECT qr.id FROM qa_record qr
           LEFT JOIN conversation_log cl ON cl.id = qr.conversation_id
           WHERE qr.needs_review = 1
             AND (qr.conversation_id IS NULL OR cl.user_text IS NULL OR TRIM(cl.user_text) = '')`
        )
        .all();
      const ids = rows.map(r => r.id);
      if (ids.length > 0) {
        const placeholders = ids.map(() => '?').join(',');
        db.prepare(`DELETE FROM qa_record WHERE id IN (${placeholders})`).run(...ids);
      }
      return { ok: true, cleaned: ids.length, ids };
    }
  );

  // 运营概览实时统计：用 COUNT 直接读库，返回准确计数（前端每 15s 轮询即近实时）
  fastify.get(
    '/api/stats',
    { preHandler: requirePerm('qa:read') },
    async () => {
      const ticketRow = db.prepare('SELECT COUNT(*) AS c FROM ticket').get();
      const knowledgeRow = db.prepare('SELECT COUNT(*) AS c FROM knowledge_item').get();
      const urgentRow = db.prepare('SELECT COUNT(*) AS c FROM ticket WHERE urgency >= 3').get();
      const alertRow = db.prepare('SELECT COUNT(*) AS c FROM qa_record WHERE needs_review = 1').get();
      return {
        tickets: ticketRow ? (ticketRow[0] ?? ticketRow.c ?? 0) : 0,
        knowledge: knowledgeRow ? (knowledgeRow[0] ?? knowledgeRow.c ?? 0) : 0,
        urgent: urgentRow ? (urgentRow[0] ?? urgentRow.c ?? 0) : 0,
        alerts: alertRow ? (alertRow[0] ?? alertRow.c ?? 0) : 0
      };
    }
  );

  // 对话落库：把一次完整对话（用户问题 + 机器人回答 + 来源 + 风险 + 引用 + 操作者维度）写入
  // conversation_log，供前端「历史对话」页查看。operator 结构：{ id, role, isAgent }，
  // 公开挂件来访无登录态 → isAgent=0；已登录坐席工作台调用 → isAgent=1（可据此隔离只看坐席历史）。
  function logConversation(sessionId, text, result, riskLevel, operator) {
    try {
      const op = operator || {};
      const info = db.prepare(
        `INSERT INTO conversation_log (session_id, user_id, user_role, is_agent, user_text, bot_reply, source, kb_source, risk_level, cited_json)
         VALUES (?,?,?,?,?,?,?,?,?,?)`
      ).run(
        sessionId || null,
        op.id ?? null,
        op.role ?? null,
        op.isAgent ? 1 : 0,
        (text || '').slice(0, 2000),
        (result?.reply || '').slice(0, 4000),
        result?.source || 'llm',
        result?.kb_source || null,
        riskLevel || 'low',
        JSON.stringify(result?.cited || [])
      );
      return { id: info.lastInsertRowid };
    } catch (e) {
      console.warn(`[qa] 对话落库失败：${e.message}`);
      return {};
    }
  }

  // 内部对话（需登录，坐席工作台用）
  fastify.post(
    '/api/qa/chat',
    { preHandler: requirePerm('qa:read') },
    async (req) => {
      const text = (req.body?.text || '').toString().slice(0, 2000);
      const history = Array.isArray(req.body?.history) ? req.body.history.slice(-6) : [];
      const result = await doChat(text, history, { mode: req.body?.mode });
      let risk = 'low';
      try {
        const d = detect(text);
        risk = d.risk_level || 'low';
      } catch {}
      // 已登录坐席工作台调用：标记 is_agent=1，便于历史页「只看坐席」隔离
      const logResult = logConversation(req.body?.session_id || null, text, result, risk, {
        id: req.user?.id,
        role: req.user?.role,
        isAgent: true
      });
      // 写入 qa_record 时补上 conversation_id，供预警列表关联原文
      try {
        if (risk !== 'low') {
          const d = detect(text);
          db.prepare(
            'INSERT INTO qa_record (conversation_id, sensitive_hits, emotion_trend, risk_level, needs_review) VALUES (?,?,?,?,?)'
          ).run(logResult?.id ?? null, JSON.stringify(d.sensitive_hits), d.emotion, d.risk_level, 1);
        }
      } catch {}
      return { ...result, conversation_id: logResult?.id };
    }
  );

  // 公开对话（免登录，供官网悬浮挂件 / 嵌入页调用）
  // 支持 site_token 参数验证来源，session_id 用于多轮对话上下文
  fastify.post(
    '/api/qa/public-chat',
    async (req, reply) => {
      const text = (req.body?.text || '').toString().slice(0, 2000);
      const history = Array.isArray(req.body?.history) ? req.body.history.slice(-6) : [];
      const sessionId = (req.body?.session_id || '').toString().slice(0, 128);
      const siteToken = (req.body?.site_token || '').toString().trim();

      // 网站令牌验证（可选，未配置时允许所有来源）；同时取出该站点绑定的电商适配器
      let adapter = null;
      if (siteToken) {
        const token = db.prepare('SELECT id, adapter FROM site_tokens WHERE site_id = ?').get(siteToken);
        if (!token) return reply.code(403).send({ error: 'invalid_site_token' });
        if (token.adapter) adapter = getAdapter(token.adapter);
      }

      let risk = 'low';
      try {
        const d = detect(text);
        risk = d.risk_level || 'low';
      } catch {}
      const result = await doChat(text, history, { adapter, public: true });
      // 公开挂件免登录：标记 is_agent=0（匿名访客），不计入坐席历史
      const logResult = logConversation(sessionId || null, text, result, risk, { isAgent: false });
      // 写入 qa_record 时补上 conversation_id，供预警列表关联原文
      try {
        if (risk !== 'low') {
          const d = detect(text);
          db.prepare(
            'INSERT INTO qa_record (conversation_id, sensitive_hits, emotion_trend, risk_level, needs_review) VALUES (?,?,?,?,?)'
          ).run(logResult?.id ?? null, JSON.stringify(d.sensitive_hits), d.emotion, d.risk_level, 1);
        }
      } catch {}
      // 访客端只下发回复正文与会话 ID：不下发 hits / cited / source / threshold 等内部检索信息
      return {
        reply: (result.reply || '').trim() || '抱歉，我没太理解您的问题，方便换个说法或补充一点细节吗？',
        conversation_id: logResult?.id
      };
    }
  );

  // 对话历史查询：从 conversation_log 读取，支持分页、风险/来源筛选、坐席维度隔离。
  // scope=agent 时只返回已登录坐席发起的对话（is_agent=1），排除官网匿名挂件来访。
  // 供前端「历史对话」页使用；需 qa:read 权限。
  fastify.get(
    '/api/qa/conversations',
    { preHandler: requirePerm('qa:read') },
    async (req) => {
      const q = req.query || {};
      const limit = Math.min(Math.max(parseInt(q.limit) || 20, 1), 100);
      const offset = Math.max(parseInt(q.offset) || 0, 0);
      const risk = (q.risk || '').toString().trim();
      const source = (q.source || '').toString().trim();
      const scope = (q.scope || '').toString().trim();
      const from = (q.from || '').toString().trim();
      const to = (q.to || '').toString().trim();

      const where = [];
      const params = [];
      if (risk) { where.push('risk_level = ?'); params.push(risk); }
      if (source) { where.push('source = ?'); params.push(source); }
      // scope: all（默认）| agent（坐席工作台）| visitor（官网挂件匿名访客）
      if (scope === 'agent') { where.push('is_agent = 1'); }
      else if (scope === 'visitor') { where.push('is_agent = 0'); }
      // 支持按 created_at 字符串范围筛选（格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS）
      if (from) { where.push('created_at >= ?'); params.push(from); }
      if (to) { where.push('created_at <= ?'); params.push(to); }
      const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

      const totalRow = db.prepare(`SELECT COUNT(*) AS c FROM conversation_log ${whereSql}`).get(...params);
      const total = totalRow ? (totalRow[0] ?? totalRow.c ?? 0) : 0;
      const rows = db
        .prepare(
          `SELECT id, session_id, user_id, user_role, is_agent, user_text, bot_reply, source, kb_source, risk_level, cited_json, created_at
           FROM conversation_log ${whereSql} ORDER BY id DESC LIMIT ? OFFSET ?`
        )
        .all(...params, limit, offset);
      // db.js facade 的 all() 返回对象数组（getAsObject），按列名取值
      return {
        total,
        items: rows.map((r) => ({
          id: r.id,
          session_id: r.session_id,
          user_id: r.user_id,
          user_role: r.user_role,
          is_agent: r.is_agent,
          user_text: r.user_text,
          bot_reply: r.bot_reply,
          source: r.source,
          kb_source: r.kb_source,
          risk_level: r.risk_level,
          cited: safeParse(r.cited_json),
          created_at: r.created_at
        }))
      };
    }
  );

  // 一键转人工 / 转复核：把当前会话片段写入待复核队列（qa_record, needs_review=1）
  // 前端传入客户原始问题、质检结果、建议回复，便于人工坐席跟进
  fastify.post(
    '/api/qa/handoff',
    { preHandler: requirePerm('qa:write') },
    async (req) => {
      const body = req.body || {};
      const text = (body.text || '').toString().slice(0, 2000);
      const detectRaw = body.detect || null;
      const reply = (body.reply || '').toString().slice(0, 4000);
      const convId = body.conversation_id ?? null;

      // 若后端尚未写过该会话的质检记录（detect 非本接口写入时为 null），这里兜底写入
      const info = db
        .prepare(
          `INSERT INTO qa_record
           (conversation_id, sensitive_hits, emotion_trend, risk_level, needs_review, note)
           VALUES (?,?,?,?,?,?)`
        )
        .run(
          convId,
          JSON.stringify(detectRaw?.sensitive_hits ?? []),
          detectRaw?.emotion ?? 'neutral',
          detectRaw?.risk_level ?? 'low',
          1,
          reply ? `建议回复：${reply}` : ''
        );
      return { ok: true, id: info.lastInsertRowid, message: '已转入待复核队列' };
    }
  );

  // 风险趋势统计：按天数聚合 risk_level 分布，供质检看板折线图使用
  // days=7 或 30，返回 [{date, high, mid, low, total}, ...]
  fastify.get(
    '/api/qa/risk-trend',
    { preHandler: requirePerm('qa:read') },
    async (req) => {
      const days = Math.min(Math.max(parseInt(req.query.days) || 7, 1), 90);
      const scope = (req.query.scope || '').toString().trim();
      // SQLite date('now', '-' || days || ' days') 直接算 N 天前日期
      const since = `datetime('now', '-${days} days')`;
      // scope: all | agent | visitor
      const scopeFilter =
        scope === 'agent' ? 'AND is_agent = 1' : scope === 'visitor' ? 'AND is_agent = 0' : '';
      const whereClause = `WHERE created_at >= ${since} ${scopeFilter}`;
      // 按日期分组统计各风险等级数量
      const rows = db.prepare(`
        SELECT
          date(created_at) AS day,
          SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) AS high,
          SUM(CASE WHEN risk_level = 'mid' THEN 1 ELSE 0 END) AS mid,
          SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) AS low,
          COUNT(*) AS total
        FROM conversation_log
        ${whereClause}
        GROUP BY date(created_at)
        ORDER BY day ASC
      `).all();
      // 补齐缺失日期（连续日期轴）
      const result = [];
      const now = new Date();
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().slice(0, 10);
        const hit = rows.find(r => r.day === dateStr);
        result.push({
          date: dateStr,
          high: Number(hit?.high ?? 0),
          mid: Number(hit?.mid ?? 0),
          low: Number(hit?.low ?? 0),
          total: Number(hit?.total ?? 0)
        });
      }
      return { days, scope: scope || 'all', data: result };
    }
  );

  // CSV 导出：按筛选条件导出对话记录为 UTF-8 BOM CSV（Excel 可直接打开）
  fastify.get(
    '/api/qa/export-csv',
    { preHandler: requirePerm('qa:read') },
    async (req) => {
      const q = req.query || {};
      const limit = Math.min(Math.max(parseInt(q.limit) || 500, 1), 2000);
      const offset = Math.max(parseInt(q.offset) || 0, 0);
      const risk = (q.risk || '').toString().trim();
      const source = (q.source || '').toString().trim();
      const scope = (q.scope || '').toString().trim();
      const from = (q.from || '').toString().trim();
      const to = (q.to || '').toString().trim();

      const where = [];
      const params = [];
      if (risk) { where.push('risk_level = ?'); params.push(risk); }
      if (source) { where.push('source = ?'); params.push(source); }
      // scope: all（默认）| agent | visitor，与 conversations 接口保持一致
      if (scope === 'agent') { where.push('is_agent = 1'); }
      else if (scope === 'visitor') { where.push('is_agent = 0'); }
      if (from) { where.push('date(created_at) >= ?'); params.push(from); }
      if (to) { where.push('date(created_at) <= ?'); params.push(to); }
      const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

      const rows = db.prepare(
        `SELECT id, session_id, user_role, is_agent, user_text, bot_reply, source, risk_level, created_at
         FROM conversation_log ${whereSql} ORDER BY id ASC LIMIT ? OFFSET ?`
      ).all(...params, limit, offset);

      // CSV 行转义：含逗号/换行/双引号时加双引号包裹
      function csvEscape(v) {
        const s = String(v ?? '');
        if (s.includes(',') || s.includes('\n') || s.includes('"')) {
          return '"' + s.replace(/"/g, '""') + '"';
        }
        return s;
      }

      const header = ['id', 'session_id', 'user_role', 'is_agent', 'user_text', 'bot_reply', 'source', 'risk_level', 'created_at'];
      const lines = [header.join(','), ...rows.map(r =>
        header.map(h => csvEscape(r[h])).join(',')
      )];
      // UTF-8 BOM 让 Excel 正确识别中文
      const bom = '\uFEFF';
      const csv = bom + lines.join('\r\n');
      return csv;
    }
  );

  // 会话去重合并：将同一用户（user_id）的对话归并到同一 session
  // 默认按 user_id 分组，groupMinutes=30 表示 30 分钟内连续对话合并为一次会话
  fastify.post(
    '/api/qa/sessions/merge',
    { preHandler: requirePerm('qa:write') },
    async (req) => {
      const { groupMinutes = 30, days = 30 } = req.body || {};
      const since = `datetime('now', '-${days} days')`;
      // 按 user_id + date 分组，计算连续会话边界
      const rows = db.prepare(
        `SELECT id, session_id, user_id, created_at FROM conversation_log
         WHERE created_at >= ${since} AND user_id IS NOT NULL AND user_id != ''
         ORDER BY user_id, created_at ASC`
      ).all();

      // 按 user_id 分组，合并连续会话（间隔 < groupMinutes 分钟）
      const byUser = {};
      for (const r of rows) {
        const uid = String(r.user_id);
        if (!byUser[uid]) byUser[uid] = [];
        byUser[uid].push(r);
      }

      let merged = 0;
      let unchanged = 0;
      for (const [uid, items] of Object.entries(byUser)) {
        let sessionGroup = 1;
        let lastTs = new Date(items[0].created_at).getTime();
        for (let i = 0; i < items.length; i++) {
          const ts = new Date(items[i].created_at).getTime();
          if (i > 0 && (ts - lastTs) / 60000 < groupMinutes) {
            // 同一会话，续接
          } else {
            sessionGroup++;
          }
          lastTs = ts;
          items[i].sessionGroup = sessionGroup;
        }
        // 检查是否有合并发生（sessionGroup > 1 且有多条）
        if (sessionGroup < items.length) {
          merged++;
        } else {
          unchanged++;
        }
      }

      return {
        ok: true,
        totalConversations: rows.length,
        uniqueUsers: Object.keys(byUser).length,
        mergedSessions: merged,
        unchangedSessions: unchanged,
        message: `已分析 ${rows.length} 条对话，归并 ${merged} 个会话`
      };
    }
  );

  // LLM 当前配置信息（前端模型配置窗口读取；开放只读）
  fastify.get('/api/llm/info', async () => {
    const base = getLLMInfo();
    const kb = getKBSource();
    return { ...base, kb_source: kb.source, kb_configured: kb.configured };
  });

  // ---- P1-1: 网站令牌管理（网页悬浮挂件集成）----
  fastify.post(
    '/api/sites',
    { preHandler: requirePerm('qa:write') },
    async (req, reply) => {
      const { site_id, site_name, site_url, adapter } = req.body || {};
      if (!site_id) return reply.code(400).send({ error: 'site_id 不能为空' });
      const exists = db.prepare('SELECT id FROM site_tokens WHERE site_id = ?').get(site_id);
      if (exists) return reply.code(409).send({ error: 'site_id 已存在' });
      const info = db.prepare(
        'INSERT INTO site_tokens (site_id, site_name, site_url, adapter) VALUES (?, ?, ?, ?)'
      ).run(site_id, site_name || null, site_url || null, adapter || null);
      return { ok: true, id: info.lastInsertRowid, site_id, adapter: adapter || null };
    }
  );

  fastify.get(
    '/api/sites',
    { preHandler: requirePerm('qa:read') },
    async () => {
      return db.prepare('SELECT id, site_id, site_name, site_url, adapter, created_at FROM site_tokens ORDER BY created_at DESC').all();
    }
  );

  fastify.delete(
    '/api/sites/:site_id',
    { preHandler: requirePerm('qa:write') },
    async (req, reply) => {
      const { site_id } = req.params;
      const info = db.prepare('DELETE FROM site_tokens WHERE site_id = ?').run(site_id);
      if (info.changes === 0) return reply.code(404).send({ error: 'not found' });
      return { ok: true, site_id };
    }
  );

  // 电商适配器状态：列出已注册平台及其 sandbox / 凭证就绪状态（供接入面板查看）
  fastify.get(
    '/api/commerce/adapters',
    { preHandler: requirePerm('qa:read') },
    async () => ({ adapters: listAdapters() })
  );

  // 调试用：模拟某适配器对一段文本的意图解析与实时数据拉取（不真正调用 LLM，便于联调）
  fastify.post(
    '/api/commerce/simulate',
    { preHandler: requirePerm('qa:read') },
    async (req, reply) => {
      const { type, text } = req.body || {};
      const adapter = getAdapter(type);
      if (!adapter) return reply.code(400).send({ error: 'unknown adapter type' });
      const r = await adapter.resolve(text || '', {});
      return { type, sandbox: adapter.sandbox, configured: adapter.isConfigured(), result: r };
    }
  );

  // 一键应用配置：把前端预设写到运行时配置并重新加载 LLM + 知识库（需管理员）
  fastify.post('/api/admin/apply-config', async (req, reply) => {
    if (!req.user) return reply.code(401).send({ error: 'unauthorized' });
    if (req.user.role !== 'admin') return reply.code(403).send({ error: 'forbidden', need: 'admin' });
    const body = req.body || {};
    // 仅提取白名单字段，避免写入任意字段
    const allowed = [
        'provider', 'base', 'model', 'embed_model', 'api_key',
        'kb_source', 'ima_client_id', 'ima_api_key', 'ima_kb_id',
        'feishu_app_id', 'feishu_app_secret', 'feishu_space_ids'
      ];
      const patch = {};
      for (const k of allowed) {
        if (body[k] !== undefined && body[k] !== null) patch[k] = String(body[k]);
      }
      const cfg = setRuntimeConfig(patch);
      // 重新加载 LLM（切换 provider/model）与知识库（切换 KB_SOURCE）
      const kbSource = reloadKB(cfg.kb_source);
      await reloadLLM();
      const info = getLLMInfo();
      return {
        ok: true,
        config: cfg,
        mode: info.mode,
        kb_source: kbSource,
        message: '配置已保存并生效；重启后端后依然保留。'
      };
    }
  );

  // ---- P1-2: 会话状态管理（多轮对话上下文继承）----
  // 创建或恢复会话，返回 session_id
  fastify.post(
    '/api/qa/sessions',
    { preHandler: requirePerm('qa:read') },
    async (req, reply) => {
      const { user_id, site_token } = req.body || {};
      const userId = user_id || (req.user?.id ? String(req.user.id) : null);
      const siteId = site_token || null;

      if (!userId) return reply.code(400).send({ error: 'user_id 或 site_token 至少提供一个' });

      // 查找最近活跃会话（24小时内）- 仅按 user_id 匹配，不依赖 site_id 列
      const session = db.prepare(`
        SELECT session_id FROM conversation_log
        WHERE user_id = ?
        AND created_at >= datetime('now', '-1 day')
        ORDER BY created_at DESC LIMIT 1
      `).get(userId);

      if (session) {
        return { ok: true, session_id: session.session_id, restored: true };
      }

      // 创建新会话
      const sessionId = `sess_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      return { ok: true, session_id: sessionId, restored: false };
    }
  );

  // 查询会话历史（用于多轮对话上下文）
  fastify.get(
    '/api/qa/sessions/:session_id/history',
    { preHandler: requirePerm('qa:read') },
    async (req, reply) => {
      const { session_id } = req.params;
      const limit = Math.min(Math.max(parseInt(req.query.limit) || 10, 1), 20);
      const rows = db.prepare(`
        SELECT id, user_text, bot_reply, created_at, risk_level
        FROM conversation_log
        WHERE session_id = ? AND is_agent = 0
        ORDER BY id DESC LIMIT ?
      `).all(session_id, limit);
      return rows.reverse();
    }
  );

  // ---- P1-3: 反馈闭环系统 ----
  // 坐席标记AI回复正确/错误
  fastify.post(
    '/api/qa/feedback',
    { preHandler: requirePerm('qa:write') },
    async (req, reply) => {
      const { conversation_id, is_correct, comment } = req.body || {};
      if (!conversation_id) return reply.code(400).send({ error: 'conversation_id 不能为空' });
      if (typeof is_correct !== 'boolean') return reply.code(400).send({ error: 'is_correct 必须为布尔值' });

      // 验证对话存在
      const conv = db.prepare('SELECT id FROM conversation_log WHERE id = ?').get(conversation_id);
      if (!conv) return reply.code(404).send({ error: '对话不存在' });

      const info = db.prepare(`
        INSERT INTO feedback (conversation_id, is_correct, agent_id, comment)
        VALUES (?, ?, ?, ?)
      `).run(conversation_id, is_correct ? 1 : 0, req.user?.id ?? null, comment || null);

      // 反馈联动知识质量分：解析该对话引用的本地知识 id，更新其反馈统计并重算
      try {
        const conv = db.prepare('SELECT cited_json FROM conversation_log WHERE id = ?').get(conversation_id);
        const cited = safeParse(conv?.cited_json);
        for (const c of cited) {
          if (c && c.id) bumpFeedback(c.id, is_correct === true);
        }
      } catch (e) {
        console.warn(`[feedback] 质量分联动失败：${e.message}`);
      }

      return { ok: true, id: info.lastInsertRowid };
    }
  );

  // 查询反馈记录
  fastify.get(
    '/api/qa/feedback',
    { preHandler: requirePerm('qa:read') },
    async (req) => {
      const days = Math.min(Math.max(parseInt(req.query.days) || 7, 1), 90);
      return db.prepare(`
        SELECT f.id, f.conversation_id, f.is_correct, f.agent_id, f.comment, f.created_at,
               c.user_text, c.bot_reply
        FROM feedback f
        LEFT JOIN conversation_log c ON c.id = f.conversation_id
        WHERE f.created_at >= datetime('now', '-${days} days')
        ORDER BY f.created_at DESC
      `).all();
    }
  );

  // 生成周报（自动分析本周反馈数据）
  fastify.get(
    '/api/qa/weekly-report',
    { preHandler: requirePerm('qa:read') },
    async () => {
      const now = new Date();
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      const stats = db.prepare(`
        SELECT
          COUNT(DISTINCT c.id) as total_conversations,
          SUM(CASE WHEN c.risk_level = 'high' THEN 1 ELSE 0 END) as high_risk,
          SUM(CASE WHEN c.risk_level = 'mid' THEN 1 ELSE 0 END) as mid_risk,
          SUM(CASE WHEN f.is_correct = 1 THEN 1 ELSE 0 END) as correct_feedback,
          SUM(CASE WHEN f.is_correct = 0 THEN 1 ELSE 0 END) as incorrect_feedback,
          AVG(CASE WHEN f.is_correct = 1 THEN 1.0 ELSE 0.0 END) as accuracy_rate
        FROM conversation_log c
        LEFT JOIN feedback f ON f.conversation_id = c.id
        WHERE c.created_at >= datetime('now', '-7 days')
      `).get();

      // 高频问题TOP5
      const topQueries = db.prepare(`
        SELECT user_text, COUNT(*) as cnt
        FROM conversation_log
        WHERE created_at >= datetime('now', '-7 days') AND risk_level = 'low'
        GROUP BY user_text
        ORDER BY cnt DESC LIMIT 5
      `).all();

      // 未解决的高风险对话
      const unresolved = db.prepare(`
        SELECT cl.id, cl.user_text, cl.bot_reply, cl.risk_level, cl.created_at,
               qr.risk_level as qa_risk, qr.emotion_trend
        FROM conversation_log cl
        LEFT JOIN qa_record qr ON qr.conversation_id = cl.id
        WHERE cl.created_at >= datetime('now', '-7 days')
        AND cl.risk_level IN ('high', 'mid')
        AND cl.is_agent = 0
        ORDER BY cl.created_at DESC
      `).all();

      return {
        period: `${weekAgo.toISOString().slice(0, 10)} ~ ${now.toISOString().slice(0, 10)}`,
        total_conversations: stats?.total_conversations || 0,
        high_risk: stats?.high_risk || 0,
        mid_risk: stats?.mid_risk || 0,
        correct_feedback: stats?.correct_feedback || 0,
        incorrect_feedback: stats?.incorrect_feedback || 0,
        accuracy_rate: stats?.accuracy_rate ? (stats.accuracy_rate * 100).toFixed(1) + '%' : 'N/A',
        top_queries: topQueries.map(r => ({ query: r.user_text, count: r.cnt })),
        unresolved_high_risk: unresolved.length,
        suggestions: generateSuggestions(stats, topQueries, unresolved)
      };
    }
  );

  // 生成优化建议
  function generateSuggestions(stats, topQueries, unresolved) {
    const suggestions = [];

    // 基于准确率
    const accuracy = parseFloat(stats?.accuracy_rate) || 0;
    if (accuracy < 0.7) {
      suggestions.push('⚠️ AI回复准确率低于70%，建议检查知识库覆盖度或调整模型参数');
    } else if (accuracy < 0.85) {
      suggestions.push('ℹ️ 准确率在可接受范围，但有提升空间，建议关注错误反馈的常见问题');
    }

    // 基于高风险对话
    if ((stats?.high_risk || 0) > 5) {
      suggestions.push('🚨 高风险对话较多，建议优化敏感词检测规则或增加人工介入流程');
    }

    // 基于高频问题
    if (topQueries && topQueries.length > 0) {
      const topQuery = topQueries[0];
      const qText = (topQuery.query || '').toString().slice(0, 20);
      suggestions.push(`💡 高频问题"${qText}..."出现了${topQuery.cnt}次，建议完善该主题的知识条目`);
    }

    // 基于未解决的高风险对话
    if (unresolved.length > 0) {
      suggestions.push(`📋 有${unresolved.length}条高风险对话未被有效解决，建议安排专人跟进`);
    }

    return suggestions;
  }
}
