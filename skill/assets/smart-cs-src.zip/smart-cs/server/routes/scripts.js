import db from '../db.js';
import { generateText } from '../llm.js';
import { requirePerm } from '../auth.js';

// 场景化话术库：基于已沉淀的知识条目（FAQ），用 LLM 生成多轮场景话术模板，
// 经人工审核后发布，作为坐席可直接复用的标准话术。
// 存储于 script_template 表（scene / turns / trigger_cond / status / reviewer）。

function parseJSON(obj) {
  if (obj && typeof obj === 'object') return obj;
  let s = String(obj || '').trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const arr = s.match(/\[[\s\S]*\]/);
  if (arr) s = arr[0];
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function safeParseTurns(s) {
  if (!s) return [];
  try {
    const j = JSON.parse(s);
    return Array.isArray(j) ? j : [];
  } catch {
    return [];
  }
}

function rowToScript(r) {
  return { ...r, turns: safeParseTurns(r.turns) };
}

// 话术检索：对「已发布」话术按 场景 / 触发条件 / agent 话术 做中文 bigram 关键词匹配。
// 返回带 score 与 replyText（agent 话术拼接）的结果，供对话自动回复与检索面板使用。
export function searchScripts(query, topK = 5) {
  const q = (query || '').trim().toLowerCase();
  if (!q) return [];
  // 查询词元：英文/数字按非中文字符切分；中文按 2 字滑动窗口生成 bigram
  const tokens = new Set();
  q.split(/[^a-z0-9]+/i)
    .filter((w) => /[a-z0-9]/i.test(w))
    .forEach((w) => tokens.add(w.toLowerCase()));
  for (let i = 0; i + 1 < q.length; i++) {
    const bg = q.slice(i, i + 2);
    if (/[一-龥]/.test(bg)) tokens.add(bg);
  }
  if (tokens.size === 0) return [];

  const rows = db
    .prepare("SELECT id, scene, trigger_cond, turns, status FROM script_template WHERE status = 'published'")
    .all();
  const scored = [];
  for (const r of rows) {
    const turnsArr = safeParseTurns(r.turns);
    const agentText = turnsArr
      .filter((t) => t && t.role === 'agent')
      .map((t) => t.content || '')
      .join(' ');
    const hay = [r.scene, r.trigger_cond, agentText].join(' ').toLowerCase();
    let score = 0;
    for (const tk of tokens) {
      if (hay.includes(tk)) score += tk.length >= 2 ? 2 : 1;
    }
    if (score > 0) {
      scored.push({
        id: r.id,
        scene: r.scene,
        trigger_cond: r.trigger_cond,
        score,
        replyText:
          agentText ||
          turnsArr.map((t) => (t.role === 'agent' ? '客服：' : '客户：') + (t.content || '')).join('\n'),
        turns: turnsArr
      });
    }
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topK);
}

export default async function scriptsRoutes(fastify) {
  // 列表（可按状态 / 场景筛选）
  fastify.get(
    '/api/scripts',
    { preHandler: requirePerm('script:read') },
    async (req) => {
      const status = (req.query.status || '').toString();
      const scene = (req.query.scene || '').toString();
      const where = [];
      const params = [];
      if (status) {
        where.push('status = ?');
        params.push(status);
      }
      if (scene) {
        where.push('scene LIKE ?');
        params.push('%' + scene + '%');
      }
      const sql =
        'SELECT id, scene, turns, trigger_cond, status, reviewer, created_at FROM script_template' +
        (where.length ? ' WHERE ' + where.join(' AND ') : '') +
        ' ORDER BY id DESC LIMIT 200';
      const rows = db.prepare(sql).all(...params);
      return { rows: rows.map(rowToScript), total: rows.length };
    }
  );

  // 从知识条目生成多轮场景话术（草稿态）
  fastify.post(
    '/api/scripts/generate',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const kid = Number(req.body?.knowledge_id);
      if (!kid) return reply.code(400).send({ error: 'knowledge_id 必填' });
      const item = db
        .prepare('SELECT id, question, solution, category FROM knowledge_item WHERE id = ?')
        .get(kid);
      if (!item) return reply.code(404).send({ error: '知识条目不存在' });

      const system =
        '你是资深客服培训师。根据给定知识条目，生成场景话术。\n\n' +
        '【严格规则】\n' +
        '1. scene 字段：必须根据对话内容概括场景（如"退款申请引导"、"物流查询回复"），绝对禁止使用 category 分类名（如"售前咨询"、"飞书同步"、"IMA同步"等）\n' +
        '2. 标题要具体：体现客户咨询的具体问题或场景，不超过10字\n' +
        '3. turns 字段：多轮对话 JSON 数组，格式 {"role":"customer"|"agent","content":"..."}，共 3-5 轮\n' +
        '4. agent 话术需专业、合规、有共情\n\n' +
        '输出格式（严格 JSON，不要多余文字）：{"scene":"具体场景标题","turns":[...]}'
      const prompt =
        `知识条目：\n问题：${item.question}\n标准解决方案：${item.solution || '（无）'}\n` +
        `分类：${item.category || '其他'}\n请生成场景话术。`;

      const raw = await generateText(prompt, { system, temperature: 0.7 });
      const parsed = parseJSON(raw);
      let turns;
      let scene;
      let note = '';
      if (parsed && typeof parsed === 'object' && Array.isArray(parsed.turns) && parsed.turns.length) {
        turns = parsed.turns;
        scene = (parsed.scene || '').toString().trim();
      } else {
        // 模型未返回标准 JSON：用知识条目原文兜底
        turns = [
          { role: 'customer', content: item.question || '客户咨询' },
          { role: 'agent', content: item.solution || '（请补充标准话术）' }
        ];
        scene = '';
        note = '模型未返回标准 JSON，已用条目原文兜底';
      }
      // 兜底：LLM 没给出场景标题时，从问题提取关键词
      if (!scene) {
        const q = item.question || '';
        scene = q.replace(/[？?！!]*$/, '').slice(0, 12) || (item.category || '其他');
      }

      const info = db
        .prepare(
          'INSERT INTO script_template (knowledge_id, scene, turns, trigger_cond, status, reviewer) VALUES (?,?,?,?,?,?)'
        )
        .run(kid, scene, JSON.stringify(turns), item.category || '', 'draft', null);
      return { ok: true, id: info.lastInsertRowid, turns, scene, note };
    }
  );

  // 发布（审核通过）
  fastify.post(
    '/api/scripts/:id/publish',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const r = db.prepare('SELECT id FROM script_template WHERE id = ?').get(id);
      if (!r) return reply.code(404).send({ error: 'not found' });
      const reviewer = req.user?.id ?? null;
      db.prepare("UPDATE script_template SET status='published', reviewer=? WHERE id=?").run(reviewer, id);
      return { ok: true, id };
    }
  );

  // 撤下（回到草稿）
  fastify.post(
    '/api/scripts/:id/unpublish',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const r = db.prepare('SELECT id FROM script_template WHERE id = ?').get(id);
      if (!r) return reply.code(404).send({ error: 'not found' });
      db.prepare("UPDATE script_template SET status='draft' WHERE id=?").run(id);
      return { ok: true, id };
    }
  );

  // 编辑（场景 / 触发条件 / 话术内容）
  fastify.put(
    '/api/scripts/:id',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const r = db.prepare('SELECT id FROM script_template WHERE id = ?').get(id);
      if (!r) return reply.code(404).send({ error: 'not found' });
      const b = req.body || {};
      const cur = db.prepare('SELECT scene, trigger_cond, turns FROM script_template WHERE id = ?').get(id);
      const scene = (b.scene ?? cur.scene).toString().trim();
      const trigger_cond = ((b.trigger_cond ?? cur.trigger_cond) || '').toString().trim();
      let turns = b.turns;
      if (typeof turns === 'string') {
        try {
          JSON.parse(turns);
        } catch {
          return reply.code(400).send({ error: 'turns 不是合法 JSON' });
        }
      } else if (Array.isArray(turns)) {
        turns = JSON.stringify(turns);
      } else {
        turns = cur.turns;
      }
      db.prepare('UPDATE script_template SET scene=?, trigger_cond=?, turns=? WHERE id=?').run(
        scene,
        trigger_cond,
        turns,
        id
      );
      return { ok: true, id };
    }
  );

  // 删除
  fastify.delete(
    '/api/scripts/:id',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const r = db.prepare('SELECT id FROM script_template WHERE id = ?').get(id);
      if (!r) return reply.code(404).send({ error: 'not found' });
      db.prepare('DELETE FROM script_template WHERE id = ?').run(id);
      return { ok: true, id };
    }
  );

  // 批量重生成场景标题（根据话术内容提炼）
  fastify.post(
    '/api/scripts/regenerate-scenes',
    { preHandler: requirePerm('script:write') },
    async (req, reply) => {
      const ids = req.body?.ids || [];
      const all = ids.length
        ? db.prepare('SELECT id, scene, turns FROM script_template WHERE id IN (' + ids.map(() => '?').join(',') + ')').all(...ids)
        : db.prepare('SELECT id, scene, turns FROM script_template').all();

      const system =
        '你是一个标题生成器。根据客服对话话术内容，生成一个简洁的场景标题（8字以内），' +
        '要求：概括话术核心主题，能让人一看就知道这是什么场景的话术，不要用"飞书同步"这类分类名。' +
        '只输出标题文字，不要其他内容。';
      const results = [];
      for (const s of all) {
        const turns = safeParseTurns(s.turns);
        const dialogue = turns.map(t => `[${t.role}] ${t.content}`).join('\n');
        try {
          const raw = await generateText(dialogue, { system, temperature: 0.1 });
          const title = (raw || '').trim().replace(/[""「」''''【】\[\]()（）]/g, '').slice(0, 10);
          db.prepare('UPDATE script_template SET scene=? WHERE id=?').run(title, s.id);
          results.push({ id: s.id, old: s.scene, new: title });
        } catch (e) {
          results.push({ id: s.id, old: s.scene, error: e.message });
        }
      }
      return { ok: true, updated: results.length, results };
    }
  );
}
