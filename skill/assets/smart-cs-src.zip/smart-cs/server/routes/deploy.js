/**
 * 部署配置路由
 *
 * 管理端（需登录）：
 *   GET    /api/deploy/config          读取完整部署配置
 *   PUT    /api/deploy/config          整体保存
 *   PUT    /api/deploy/section/:name   分节保存（tenant|widget|llm|knowledge）
 *   POST   /api/deploy/apply-template  套用内置模板
 *   GET    /api/deploy/templates       模板清单
 *   POST   /api/deploy/reset           恢复空白模板
 *   GET    /api/deploy/export          导出当前配置为 JSON 下载
 *
 * 访客端（免登录，挂件启动拉配置用）：
 *   GET    /api/deploy/widget-config   只下发挂件需要的字段，绝不下发密钥
 */

import { requirePerm } from '../auth.js';
import {
  getDeployConfig,
  setDeployConfig,
  setDeploySection,
  resetDeployConfig,
  applyTemplate,
  listTemplates,
  CONFIG_PATH
} from '../deployConfig.js';
import { getRuntimeConfig } from '../runtimeConfig.js';
import { reloadLLM } from '../llm.js';
import { reloadKB } from '../kb/index.js';

/** 挂件可见字段白名单：任何密钥类字段都不允许出现在这里 */
function publicWidgetView(cfg) {
  const w = cfg.widget || {};
  return {
    title: w.title || '在线客服',
    greeting: w.greeting || '您好，请问有什么可以帮您？',
    placeholder: w.placeholder || '输入您的问题，回车发送',
    powered: w.powered || '',
    accentFrom: w.accentFrom || '#06b6d4',
    accentTo: w.accentTo || '#3b82f6',
    siteToken: w.siteToken || '',
    presetQuestions: Array.isArray(w.presetQuestions) ? w.presetQuestions.slice(0, 8) : []
  };
}

export default async function deployRoutes(fastify) {
  const adminOnly = { preHandler: requirePerm('admin') };

  fastify.get('/api/deploy/widget-config', async () => {
    // 站点维度留位：后续多站点时按 site 取不同外观；当前单租户直接返回全局配置
    return publicWidgetView(getDeployConfig());
  });

  fastify.get('/api/deploy/config', adminOnly, async () => {
    const cfg = getDeployConfig();
    return {
      config: cfg,
      effective: getRuntimeConfig(),
      templates: listTemplates(),
      path: CONFIG_PATH
    };
  });

  fastify.put('/api/deploy/config', adminOnly, async (req, reply) => {
    try {
      const cfg = setDeployConfig(req.body?.config || req.body || {});
      return { ok: true, config: cfg };
    } catch (e) {
      return reply.code(400).send({ error: e.message });
    }
  });

  fastify.put('/api/deploy/section/:name', adminOnly, async (req, reply) => {
    try {
      const cfg = setDeploySection(req.params.name, req.body || {});
      return { ok: true, config: cfg };
    } catch (e) {
      return reply.code(400).send({ error: e.message });
    }
  });

  fastify.get('/api/deploy/templates', adminOnly, async () => {
    return { templates: listTemplates() };
  });

  fastify.post('/api/deploy/apply-template', adminOnly, async (req, reply) => {
    try {
      const cfg = applyTemplate((req.body?.name || '').toString());
      return { ok: true, config: cfg, hint: '已套用模板；模型与知识库需点「应用生效」重载引擎' };
    } catch (e) {
      return reply.code(400).send({ error: e.message });
    }
  });

  fastify.post('/api/deploy/reset', adminOnly, async () => {
    return { ok: true, config: resetDeployConfig() };
  });

  /**
   * 应用生效：把 deploy 配置重新灌入 LLM 与知识库引擎并重载，
   * 对应后台「应用并生效」按钮 —— 改了模型/知识库不重启也能切换。
   */
  fastify.post('/api/deploy/apply', {
    preHandler: requirePerm('admin'),
    // 防御：允许空 body 调用（前端 api() 带 json content-type 但可能无 body）
    preValidation: (req, _reply, done) => { if (!req.body) req.body = {}; done(); }
  }, async () => {
    const before = getRuntimeConfig();
    let llm = null;
    let kb = null;
    try {
      llm = await reloadLLM();
    } catch (e) {
      llm = { error: e.message };
    }
    try {
      kb = reloadKB(before.kb_source);
    } catch (e) {
      kb = { error: e.message };
    }
    return { ok: true, effective: getRuntimeConfig(), llm, kb };
  });

  fastify.get('/api/deploy/export', adminOnly, async (req, reply) => {
    const brand = getDeployConfig().tenant.brand || 'smart-cs';
    reply.header('Content-Type', 'application/json; charset=utf-8');
    reply.header('Content-Disposition', `attachment; filename="deploy-${brand}.json"`);
    return JSON.stringify(getDeployConfig(), null, 2);
  });
}
