import db from '../db.js';
import { extractTicket } from '../llm.js';
import { embed, buildDocText } from '../embed.js';
import { requirePerm } from '../auth.js';
import { normalizeKnowledgeFields, insertKnowledgeRow } from '../kb/ingest.js';

// 工单：导入（同步生成知识条目） + 列表
export default async function ticketsRoutes(fastify) {
  fastify.post(
    '/api/tickets/import',
    { preHandler: requirePerm('ticket:write') },
    async (req, reply) => {
    const body = req.body;
    const list = Array.isArray(body) ? body : body?.tickets;
    if (!Array.isArray(list)) {
      return reply.code(400).send({ error: '期望 JSON 数组或 { tickets: [...] }' });
    }

    const insT = db.prepare(
      'INSERT INTO ticket (source, content, category, urgency, customer_level, confidence) VALUES (?,?,?,?,?,?)'
    );

    // 事务外先完成异步抽取 + 向量化（生产环境此处调 LLM / embedding），事务内保持同步写入
    const extracted = await Promise.all(list.map((it) => extractTicket(it.content)));
    const vectors = await Promise.all(
      extracted.map((ex, i) => embed(buildDocText({ question: ex.question, category: ex.category, solution: ex.solution || list[i].content })))
    );

    let n = 0;
    let skipped = 0;
    const tx = db.transaction((items) => {
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const ex = extracted[i];
        // 全量回流去重：相同 content 的工单已导入过则跳过，避免重复抽知识污染知识库
        const dup = db.prepare("SELECT id FROM ticket WHERE content = ? AND source = 'import' LIMIT 1").get(it.content);
        if (dup) { skipped++; continue; }
        const info = insT.run(
          it.source || 'import',
          it.content,
          ex.category,
          ex.urgency,
          it.customer_level || 'normal',
          ex.confidence
        );
        // 统一模板入库：来源标记 ticket，关联工单 id，向量复用已算好的
        insertKnowledgeRow(
          normalizeKnowledgeFields({
            question: ex.question,
            solution: ex.solution,
            category: ex.category,
            urgency: ex.urgency,
            source_type: 'ticket',
            source_ticket_id: info.lastInsertRowid,
            embedding: JSON.stringify(vectors[i]),
            status: 'draft'
          })
        );
        n++;
      }
    });
    tx(list);

    return { imported: n, skipped };
  });

  fastify.get(
    '/api/tickets',
    { preHandler: requirePerm('ticket:read') },
    async () => {
      return db
        .prepare('SELECT id, category, urgency, customer_level, status, created_at FROM ticket ORDER BY id DESC LIMIT 100')
        .all();
    }
  );
}
