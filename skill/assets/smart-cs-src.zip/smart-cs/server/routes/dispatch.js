import db from '../db.js';
import { requirePerm } from '../auth.js';

// 工单智能派发：将进线工单分类后，结合客服技能画像（技能匹配 + 当前负载 + 紧急度）
// 综合打分路由到最合适的客服组；无匹配技能或打分过低则转人工评审。
// 客服技能画像存储于 agent_profile 表（agent_id / skill_tags / avg_satisfaction / load_current）。

// 客服技能画像种子（首次启动注入；幂等）
const SEED_AGENTS = [
  { agent_id: 1, name: '退款物流组', skill_tags: ['售后-退款', '售后-物流', '退换货'], avg_satisfaction: 4.7 },
  { agent_id: 2, name: '售前会员组', skill_tags: ['售前咨询', '会员', '优惠活动'], avg_satisfaction: 4.5 },
  { agent_id: 3, name: '投诉处理组', skill_tags: ['投诉处理', '售后处理', '用户反馈'], avg_satisfaction: 4.3 },
  { agent_id: 4, name: '技术支持组', skill_tags: ['网络设置', '商品定制', '账号'], avg_satisfaction: 4.6 }
];
const CAP = 5; // 单客服组并发容量上限（用于容量打分）

function ensureSeed() {
  const row = db.prepare('SELECT COUNT(*) AS c FROM agent_profile').get();
  const n = row ? row[0] ?? row.c ?? 0 : 0;
  if (n > 0) return;
  const ins = db.prepare(
    'INSERT OR IGNORE INTO agent_profile (agent_id, skill_tags, avg_satisfaction, load_current) VALUES (?,?,?,0)'
  );
  for (const a of SEED_AGENTS) ins.run(a.agent_id, JSON.stringify(a.skill_tags), a.avg_satisfaction);
}

// 关键词零样本分类（LLM 接入后可替换为模型分类）
const CAT_RULES = [
  { cat: '售后-退款', kw: ['退款', '退货', '退款到账', '退款被拒'] },
  { cat: '售后-物流', kw: ['物流', '快递', '发货', '签收', '丢件', '改地址', '发货时间'] },
  { cat: '退换货', kw: ['换货', '退换', '少件', '破损', '错发'] },
  { cat: '投诉处理', kw: ['投诉', '差评', '曝光', '愤怒', '骗', '垃圾', '失望'] },
  { cat: '售前咨询', kw: ['怎么', '如何', '什么', '支持', '能不能', '是否', '咨询'] },
  { cat: '会员', kw: ['会员', '积分', '等级', '权益'] },
  { cat: '优惠活动', kw: ['优惠券', '优惠', '活动', '满减', '折扣'] },
  { cat: '网络设置', kw: ['路由器', 'wifi', '网速', '联网', '光猫'] },
  { cat: '账号', kw: ['密码', '登录', '账号', '封禁', '手机号'] },
  { cat: '发票', kw: ['发票', '开票', '收据'] },
  { cat: '支付', kw: ['支付', '付款', '扣款', '余额', '货到付款'] }
];
function classify(text) {
  for (const r of CAT_RULES) {
    if (r.kw.some((k) => text.includes(k))) return r.cat;
  }
  return '其他';
}

function safeSkills(s) {
  if (!s) return [];
  try {
    const j = JSON.parse(s);
    return Array.isArray(j) ? j : [];
  } catch {
    return [];
  }
}

export default async function dispatchRoutes(fastify) {
  ensureSeed();

  // 智能派单：分类 → 技能匹配 + 容量打分 → 推荐 / 转人工
  fastify.post(
    '/api/dispatch/route',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const b = req.body || {};
      const content = (b.content || '').toString().trim();
      if (!content) return reply.code(400).send({ error: 'content 必填' });
      const category = (b.category || classify(content)).toString().trim() || '其他';
      const urgency = [1, 2, 3].includes(Number(b.urgency)) ? Number(b.urgency) : 1;

      const agents = db
        .prepare('SELECT agent_id, skill_tags, avg_satisfaction, load_current FROM agent_profile')
        .all()
        .map((a) => ({ ...a, skills: safeSkills(a.skill_tags) }));

      const scored = agents
        .map((a) => {
          let skillMatch = 0;
          if (a.skills.includes(category)) skillMatch = 1;
          else if (
            category !== '其他' &&
            a.skills.some((s) => s.split('-')[0] === category.split('-')[0])
          )
            skillMatch = 0.5;
          const capacity = Math.max(0, 1 - (a.load_current || 0) / CAP);
          const score = +(0.55 * skillMatch + 0.3 * capacity + 0.15 * (urgency / 3)).toFixed(3);
          return {
            agent_id: a.agent_id,
            skill_tags: a.skills,
            avg_satisfaction: a.avg_satisfaction,
            load_current: a.load_current,
            skillMatch,
            score
          };
        })
        .sort((x, y) => y.score - x.score);

      const best = scored[0];
      const needsHuman = !best || best.skillMatch === 0 || best.score < 0.4;
      const recommended = best && !needsHuman
        ? { agent_id: best.agent_id, skill_tags: best.skill_tags, score: best.score }
        : null;

      return {
        ok: true,
        category,
        urgency,
        recommended,
        needsHuman,
        reason: needsHuman
          ? best && best.skillMatch === 0
            ? '无匹配技能客服，转人工评审'
            : '综合打分过低，转人工评审'
          : `推荐 ${best.agent_id} 号客服组（技能匹配 ${Math.round(best.skillMatch * 100)}%，当前负载 ${best.load_current}/${CAP}）`,
        candidates: scored.slice(0, 5)
      };
    }
  );

  // 确认派发：根据工单内容创建/更新工单并分配给指定客服组
  fastify.post(
    '/api/dispatch/assign',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const b = req.body || {};
      const agent_id = Number(b.agent_id);
      const content = (b.content || '').toString().trim();
      const category = (b.category || '').toString().trim();
      const urgency = [1, 2, 3].includes(Number(b.urgency)) ? Number(b.urgency) : 1;
      const ticket_id = Number(b.ticket_id);
      if (!agent_id || !content) return reply.code(400).send({ error: 'agent_id 和 content 必填' });
      // 检查客服组
      const agent = db.prepare('SELECT agent_id, load_current FROM agent_profile WHERE agent_id = ?').get(agent_id);
      if (!agent) return reply.code(404).send({ error: '客服组不存在' });
      // 若已有 ticket_id 则更新，否则新建
      if (ticket_id) {
        const ticket = db.prepare('SELECT id FROM ticket WHERE id = ?').get(ticket_id);
        if (!ticket) return reply.code(404).send({ error: '工单不存在' });
        db.prepare('UPDATE ticket SET assignee = ?, category = ?, urgency = ? WHERE id = ?').run(agent_id, category || null, urgency, ticket_id);
      } else {
        const info = db.prepare(
          'INSERT INTO ticket (source, content, category, urgency, assignee, status) VALUES (?,?,?,?,?,?)'
        ).run('dispatch', content, category || null, urgency, agent_id, 'pending');
        return { ok: true, ticket_id: info.lastInsertRowid, agent_id, new_load: agent.load_current + 1 };
      }
      // 更新负载
      db.prepare('UPDATE agent_profile SET load_current = load_current + 1 WHERE agent_id = ?').run(agent_id);
      return { ok: true, ticket_id: ticket_id || 'new', agent_id, new_load: agent.load_current + 1 };
    }
  );

  // 释放工单（回收负载）
  fastify.post(
    '/api/dispatch/release',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const b = req.body || {};
      const ticket_id = Number(b.ticket_id);
      if (!ticket_id) return reply.code(400).send({ error: 'ticket_id 必填' });
      const ticket = db.prepare('SELECT assignee FROM ticket WHERE id = ?').get(ticket_id);
      if (!ticket) return reply.code(404).send({ error: '工单不存在' });
      if (!ticket.assignee) return reply.code(400).send({ error: '该工单未被分配' });
      const aid = ticket.assignee;
      db.prepare('UPDATE ticket SET assignee = NULL WHERE id = ?').run(ticket_id);
      db.prepare('UPDATE agent_profile SET load_current = MAX(0, load_current - 1) WHERE agent_id = ?').run(aid);
      return { ok: true, ticket_id, released_agent: aid };
    }
  );

  // 客服画像列表（含绑定的用户）
  fastify.get(
    '/api/dispatch/agents',
    { preHandler: requirePerm('dispatch:read') },
    async () => {
      const rows = db
        .prepare('SELECT agent_id, skill_tags, avg_satisfaction, load_current FROM agent_profile ORDER BY agent_id')
        .all();
      return rows.map((a) => {
        const agents = safeSkills(a.skill_tags);
        // 查询绑定到该客服组的用户
        const users = db.prepare('SELECT id, username, display_name, role FROM users WHERE agent_id = ?').all(a.agent_id);
        return { ...a, skill_tags: agents, users };
      });
    }
  );

  // 新增客服画像
  fastify.post(
    '/api/dispatch/agents',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const b = req.body || {};
      const agent_id = Number(b.agent_id);
      if (!agent_id) return reply.code(400).send({ error: 'agent_id 必填' });
      const skill_tags = Array.isArray(b.skill_tags)
        ? b.skill_tags
        : (b.skill_tags ? String(b.skill_tags).split(',').map((s) => s.trim()).filter(Boolean) : []);
      const avg = Number(b.avg_satisfaction) || 4.5;
      db.prepare(
        'INSERT OR REPLACE INTO agent_profile (agent_id, skill_tags, avg_satisfaction, load_current) VALUES (?,?,?,0)'
      ).run(agent_id, JSON.stringify(skill_tags), avg);
      return { ok: true, agent_id };
    }
  );

  // 更新客服画像（技能 / 满意度 / 负载）
  fastify.put(
    '/api/dispatch/agents/:id',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const r = db.prepare('SELECT agent_id FROM agent_profile WHERE agent_id = ?').get(id);
      if (!r) return reply.code(404).send({ error: 'not found' });
      const b = req.body || {};
      const cur = db
        .prepare('SELECT skill_tags, avg_satisfaction, load_current FROM agent_profile WHERE agent_id = ?')
        .get(id);
      const skill_tags = b.skill_tags
        ? Array.isArray(b.skill_tags)
          ? b.skill_tags
          : String(b.skill_tags).split(',').map((s) => s.trim()).filter(Boolean)
        : safeSkills(cur.skill_tags);
      const avg = b.avg_satisfaction != null ? Number(b.avg_satisfaction) : cur.avg_satisfaction;
      const load = b.load_current != null ? Number(b.load_current) : cur.load_current;
      db.prepare(
        'UPDATE agent_profile SET skill_tags=?, avg_satisfaction=?, load_current=? WHERE agent_id=?'
      ).run(JSON.stringify(skill_tags), avg, load, id);
      return { ok: true, id };
    }
  );

  // 删除客服画像
  fastify.delete(
    '/api/dispatch/agents/:id',
    { preHandler: requirePerm('dispatch:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      db.prepare('DELETE FROM agent_profile WHERE agent_id = ?').run(id);
      return { ok: true, id };
    }
  );
}

export { CAP };
