import db from '../db.js';
import {
  hashPassword,
  verifyPassword,
  signToken,
  requirePerm,
  hasPerm,
  ROLES,
  publicUser
} from '../auth.js';

// 鉴权相关接口：登录 / 当前用户 / 用户管理 / 改密码
export default async function authRoutes(fastify) {
  // 登录（公开）
  fastify.post('/api/auth/login', async (req, reply) => {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return reply.code(400).send({ error: '缺少用户名或密码' });
    }
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!u || !verifyPassword(password, u.password_hash)) {
      return reply.code(401).send({ error: '用户名或密码错误' });
    }
    const token = signToken({ uid: u.id, username: u.username, role: u.role });
    return { token, user: publicUser(u) };
  });

  // 当前登录用户（需登录）
  fastify.get('/api/auth/me', async (req) => {
    return { user: req.user };
  });

  // 用户列表（仅管理员）
  fastify.get(
    '/api/auth/users',
    { preHandler: requirePerm('user:manage') },
    async () => {
      return db
        .prepare('SELECT id, username, role, display_name, created_at FROM users ORDER BY id')
        .all();
    }
  );

  // 创建用户（仅管理员）
  fastify.post(
    '/api/auth/users',
    { preHandler: requirePerm('user:manage') },
    async (req, reply) => {
      const { username, password, role, display_name } = req.body || {};
      if (!username || !password) {
        return reply.code(400).send({ error: '缺少用户名或密码' });
      }
      if (!ROLES[role]) {
        return reply.code(400).send({ error: '无效角色', valid: Object.keys(ROLES) });
      }
      const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
      if (exists) return reply.code(409).send({ error: '用户名已存在' });
      db.prepare(
        'INSERT INTO users (username, password_hash, role, display_name) VALUES (?,?,?,?)'
      ).run(username, hashPassword(password), role, display_name || username);
      return { ok: true };
    }
  );

  // 修改密码：管理员可改任意用户（免原密码），普通用户改自己需校验原密码
  fastify.post('/api/auth/change-password', async (req, reply) => {
    const { old_password, new_password, target_username } = req.body || {};
    if (!new_password) return reply.code(400).send({ error: '缺少新密码' });

    let target;
    if (target_username && target_username !== req.user.username) {
      if (!hasPerm(req.user.role, 'user:manage')) {
        return reply.code(403).send({ error: 'forbidden' });
      }
      target = db.prepare('SELECT * FROM users WHERE username = ?').get(target_username);
    } else {
      target = db.prepare('SELECT * FROM users WHERE username = ?').get(req.user.username);
    }
    if (!target) return reply.code(404).send({ error: '用户不存在' });

    // 非管理员改自己：必须校验原密码
    if (!hasPerm(req.user.role, 'user:manage') && !verifyPassword(old_password || '', target.password_hash)) {
      return reply.code(401).send({ error: '原密码错误' });
    }
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
      hashPassword(new_password),
      target.id
    );
    return { ok: true };
  });
}
