import db from '../db.js';
import { searchKnowledge, buildDocText } from '../embed.js';
import { embedText } from '../llm.js';
import { requirePerm } from '../auth.js';
import { syncExternalKnowledge, extractFAQFromExternal, ingestDocsAsFAQ, syncByKbName } from '../kb/sync.js';
import { getKBSource, listKnowledgeBases } from '../kb/index.js';
import { recomputeAll, autoExtract, getExtractCandidates } from '../kb/quality.js';
import { createKnowledgeItem } from '../kb/ingest.js';

// 知识库：检索 + 增删改 + 重算向量
export default async function knowledgeRoutes(fastify) {
  // 语义检索（保留原接口）
  fastify.get(
    '/api/knowledge/search',
    { preHandler: requirePerm('knowledge:read') },
    async (req) => {
      const q = (req.query.q || '').toString();
      return { query: q, results: await searchKnowledge(q, 5) };
    }
  );

  // 列表（分页 + 来源筛选）
  //   source=feishu,ima  → 只返回这些来源（逗号 OR）
  //   exclude=ticket,feishu,ima → 排除这些来源（用于「历史FAQ」展示内部沉淀知识）
  fastify.get(
    '/api/knowledge',
    { preHandler: requirePerm('knowledge:read') },
    async (req) => {
      // limit/offset 已校验为整数，直接拼 SQL（sql.js 对参数化 LIMIT 有 datatype mismatch 坑）
      const limit = Math.min(Math.floor(Number(req.query.limit) || 50), 200);
      const offset = Math.max(Math.floor(Number(req.query.offset) || 0), 0);
      const source = (req.query.source || '').toString().trim();
      const exclude = (req.query.exclude || '').toString().trim();
      const status = (req.query.status || '').toString().trim();
      const clauses = [];
      const params = [];
      if (source) {
        const arr = source.split(',').map((s) => s.trim()).filter(Boolean);
        if (arr.length) {
          clauses.push(`source_type IN (${arr.map(() => '?').join(',')})`);
          params.push(...arr);
        }
      }
      if (exclude) {
        const arr = exclude.split(',').map((s) => s.trim()).filter(Boolean);
        if (arr.length) {
          clauses.push(`source_type NOT IN (${arr.map(() => '?').join(',')})`);
          params.push(...arr);
        }
      }
      if (status) {
        clauses.push('status = ?');
        params.push(status);
      }
      const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';
      const rows = db
        .prepare(
          `SELECT id, question, solution, category, product_module, urgency, hit_count, quality_score, feedback_pos, feedback_neg, source_type, knowledge_base_name, status, last_hit_at, created_at FROM knowledge_item ${where} ORDER BY id DESC LIMIT ${limit} OFFSET ${offset}`
        )
        .all(...params);
      const totalRow = db.prepare(`SELECT COUNT(*) AS c FROM knowledge_item ${where}`).get(...params);
      const total = totalRow ? (totalRow[0] ?? totalRow.c ?? 0) : 0;
      return { total, rows };
    }
  );

  // 新增（统一模板：来源标记 faq，自动计算 embedding 与初始质量分）
  fastify.post(
    '/api/knowledge',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const b = req.body || {};
      const question = (b.question || '').toString().trim();
      if (!question) return reply.code(400).send({ error: 'question 不能为空' });
      try {
        const r = await createKnowledgeItem({
          question,
          solution: b.solution || '',
          category: b.category || '其他',
          product_module: b.product_module || '',
          urgency: b.urgency,
          source_type: 'faq'
        });
        return { id: r.id, ok: true };
      } catch (e) {
        return reply.code(400).send({ error: e.message });
      }
    }
  );

  // 编辑（重算 embedding）
  fastify.put(
    '/api/knowledge/:id',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const b = req.body || {};
      const row = db.prepare('SELECT id FROM knowledge_item WHERE id = ?').get(id);
      if (!row) return reply.code(404).send({ error: 'not found' });
      const cur = db.prepare('SELECT question, solution, category, product_module, urgency FROM knowledge_item WHERE id = ?').get(id);
      const question = (b.question ?? cur.question).toString().trim();
      const solution = (b.solution ?? cur.solution).toString();
      const category = (b.category ?? cur.category).toString().trim() || '其他';
      const product_module = ((b.product_module ?? cur.product_module) || '').toString().trim();
      const urgency = [1, 2, 3].includes(Number(b.urgency ?? cur.urgency)) ? Number(b.urgency ?? cur.urgency) : 1;
      const embedding = JSON.stringify(await embedText(buildDocText({ question, category, product_module, solution })));
      db.prepare(
        'UPDATE knowledge_item SET question=?, solution=?, category=?, product_module=?, urgency=?, embedding=? WHERE id=?'
      ).run(question, solution, category, product_module, urgency, embedding, id);
      return { id, ok: true };
    }
  );

  // 删除
  fastify.delete(
    '/api/knowledge/:id',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const row = db.prepare('SELECT id FROM knowledge_item WHERE id = ?').get(id);
      if (!row) return reply.code(404).send({ error: 'not found' });
      db.prepare('DELETE FROM knowledge_item WHERE id = ?').run(id);
      return { id, ok: true };
    }
  );

  // 发布：草稿 → 已发布（下游检索 / 话术生成 / 质检只认 published）
  fastify.post(
    '/api/knowledge/:id/publish',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const row = db.prepare('SELECT id FROM knowledge_item WHERE id = ?').get(id);
      if (!row) return reply.code(404).send({ error: 'not found' });
      db.prepare("UPDATE knowledge_item SET status='published' WHERE id=?").run(id);
      return { id, ok: true, status: 'published' };
    }
  );

  // 撤下：已发布 → 草稿（退出下游调用）
  fastify.post(
    '/api/knowledge/:id/unpublish',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const id = Number(req.params.id);
      const row = db.prepare('SELECT id FROM knowledge_item WHERE id = ?').get(id);
      if (!row) return reply.code(404).send({ error: 'not found' });
      db.prepare("UPDATE knowledge_item SET status='draft' WHERE id=?").run(id);
      return { id, ok: true, status: 'draft' };
    }
  );

  // 全量重算 embedding（切换 embedding 模型后调用）
  fastify.post(
    '/api/knowledge/reembed',
    { preHandler: requirePerm('knowledge:write') },
    async () => {
      const rows = db.prepare('SELECT id, question, solution FROM knowledge_item').all();
      let ok = 0;
      for (const r of rows) {
        const emb = JSON.stringify(await embedText(buildDocText(r)));
        db.prepare('UPDATE knowledge_item SET embedding = ? WHERE id = ?').run(emb, r.id);
        ok++;
      }
      return { ok, total: rows.length };
    }
  );

  // 知识库清洗：删除外部同步（飞书 / IMA）但无命中的低价值条目（兼容旧 category 标记）
  fastify.post(
    '/api/knowledge/cleanup',
    { preHandler: requirePerm('knowledge:write') },
    async () => {
      const rows = db
        .prepare(
          `SELECT id FROM knowledge_item
           WHERE hit_count = 0 AND (source_type IN ('feishu','ima') OR category IN ('飞书同步','IMA同步'))`
        )
        .all();
      if (rows.length === 0) return { ok: true, deleted: 0, message: '无需清洗' };
      for (const r of rows) {
        db.prepare('DELETE FROM knowledge_item WHERE id = ?').run(r.id);
      }
      return { ok: true, deleted: rows.length, message: `已删除 ${rows.length} 条外部同步噪音条目` };
    }
  );

  // 对话自动提炼为知识：把坐标准确的对话提炼成知识条目（知识库"活的体系"的对话侧回流）
  fastify.post(
    '/api/knowledge/auto-extract',
    { preHandler: requirePerm('knowledge:write') },
    async (req) => {
      const limit = Math.min(Math.max(parseInt(req.body?.limit) || 50, 1), 200);
      try {
        const r = await autoExtract({ limit });
        return { ok: true, ...r };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    }
  );

  // 待提炼对话队列：被标记正确、尚未提炼成知识的对话
  fastify.get(
    '/api/knowledge/extract-candidates',
    { preHandler: requirePerm('knowledge:read') },
    async (req) => {
      const limit = Math.min(Math.max(parseInt(req.query.limit) || 50, 1), 200);
      return { candidates: getExtractCandidates(limit) };
    }
  );

  // 重算全部知识质量分（命中贡献 + 反馈贡献 + 陈旧惩罚）
  fastify.post(
    '/api/knowledge/recalc-quality',
    { preHandler: requirePerm('knowledge:write') },
    async () => {
      const total = recomputeAll();
      return { ok: true, total };
    }
  );

  // 待复审队列：质量分低于阈值（低价值 / 可能过时）的知识条目
  fastify.get(
    '/api/knowledge/review-queue',
    { preHandler: requirePerm('knowledge:read') },
    async (req) => {
      const threshold = Math.min(Math.max(parseFloat(req.query.threshold) || 0.35, 0.1), 0.9);
      return db
        .prepare(
          `SELECT id, question, solution, category, hit_count, quality_score, feedback_pos, feedback_neg, source_type, knowledge_base_name, last_hit_at, created_at
           FROM knowledge_item WHERE quality_score < ? ORDER BY quality_score ASC LIMIT 50`
        )
        .all(threshold);
    }
  );

  // 按库名同步（清理旧条目 + FAQ 提炼重新入库）
  // 入参：{ source: 'feishu'|'ima', kb_name: string }
  fastify.post(
    '/api/knowledge/sync-kb',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const source = (req.body?.source || '').toString().trim();
      const kbName = (req.body?.kb_name || '').toString().trim();
      if (!['feishu', 'ima'].includes(source)) return reply.code(400).send({ error: 'source 仅支持 feishu/ima' });
      if (!kbName) return reply.code(400).send({ error: 'kb_name 不能为空' });
      try {
        const r = await syncByKbName(source, kbName);
        return { ok: true, ...r };
      } catch (e) {
        return reply.code(400).send({ ok: false, error: e.message });
      }
    }
  );

  // 从外部知识库（飞书 / IMA）同步到本地 RAG（需管理员）
  // 支持可选的 knowledge_base_id 参数：飞书传 space_id，IMA 传 kb_id
  fastify.post(
    '/api/knowledge/sync',
    { preHandler: requirePerm('knowledge:write') },
    async (req) => {
      const src = (req.body?.source || getKBSource().source);
      const keyword = (req.body?.keyword || '常见问题').toString();
      const spaceId = req.body?.space_id || null;
      const kbId = req.body?.kb_id || null;
      const kbName = (req.body?.kb_name || '').toString().trim();
      try {
        const r = await syncExternalKnowledge(src, keyword, spaceId, kbId, kbName);
        return { ok: true, ...r };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    }
  );

  // 列出可用的外部知识库（飞书 space + IMA KB）
  fastify.get(
    '/api/knowledge/kb-list',
    { preHandler: requirePerm('knowledge:read') },
    async () => {
      try {
        const list = await listKnowledgeBases();
        return { ok: true, knowledge_bases: list };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    }
  );

  // 从外部知识库自动提炼 FAQ（LLM）
  // 入参：source(=feishu/ima), keyword, space_id(可选), kb_id(可选), limit(默认10)
  // 返回：{ ok, count, items: [{question, solution, source, knowledge_base_name, original_title}] }
  fastify.post(
    '/api/knowledge/extract-faq',
    { preHandler: requirePerm('knowledge:write') },
    async (req) => {
      const src = (req.body?.source || getKBSource().source);
      const keyword = (req.body?.keyword || '常见问题').toString();
      const spaceId = req.body?.space_id || null;
      const kbId = req.body?.kb_id || null;
      const kbName = (req.body?.kb_name || '').toString().trim();
      const limit = Math.min(Math.max(parseInt(req.body?.limit) || 10, 1), 50);
      try {
        const r = await extractFAQFromExternal(src, keyword, spaceId, kbId, limit, kbName);
        return { ok: true, ...r };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    }
  );

  // 从本地文件夹摄取文档为知识条目（需管理员）
  // 入参：{ files: [{name, content}], baseName?, publish? }
  //   - files: 前端 webkitdirectory 读取的文本类文件（.md/.txt/.csv/.json 等）
  //   - baseName: 文件夹名，作为 knowledge_base_name / category 默认值（便于归库）
  //   - publish: true 则直接 published（进下游检索）；缺省 false → draft（需人工审核发布）
  // 每个文件 → 用 LLM 从正文提炼出多条 FAQ 入库；LLM 不可用/过短时退化为整篇 1 条。
  fastify.post(
    '/api/knowledge/ingest-files',
    { preHandler: requirePerm('knowledge:write') },
    async (req, reply) => {
      const files = Array.isArray(req.body?.files) ? req.body.files : [];
      if (!files.length) return reply.code(400).send({ error: 'files 不能为空' });
      const baseName = (req.body?.baseName || '本地文件').toString().trim() || '本地文件';
      const publish = req.body?.publish === true;
      // 把每个文件规整为 doc（顶层文件夹作库名，文件名去扩展名作标题）
      const docs = [];
      for (const f of files) {
        const name = (f?.name || '').toString().trim();
        const content = (f?.content || '').toString();
        if (!name) continue;
        const parts = name.split('/');
        const folder = parts.length > 1 ? parts[0] : '';
        const kbName = folder || baseName;
        const fileBase = parts[parts.length - 1];
        const title = fileBase.replace(/\.[^.]+$/, '') || fileBase;
        const solution = content.length > 8000 ? content.slice(0, 8000) : content;
        docs.push({ title, content: solution, knowledge_base_name: kbName });
      }
      try {
        const r = await ingestDocsAsFAQ(docs, { sourceType: 'file', kbName: baseName, publish, limitPerDoc: 8 });
        return { ok: true, inserted: r.added, docs: r.docs, skipped: r.skipped, failed: r.failed };
      } catch (e) {
        return reply.code(400).send({ error: e.message });
      }
    }
  );
}
