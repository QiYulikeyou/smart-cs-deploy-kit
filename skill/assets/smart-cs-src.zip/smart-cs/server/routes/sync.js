import { requirePerm } from '../auth.js';
import { getKBSource } from '../kb/index.js';
import { runNow, getSyncStatus, startScheduler, stopScheduler } from '../scheduler.js';
import { setRuntimeConfig, getRuntimeConfig } from '../runtimeConfig.js';

export default async function syncRoutes(fastify) {
  // 查询同步状态（无需权限）
  fastify.get('/api/sync/status', async () => getSyncStatus());

  // 手动触发同步（需 knowledge:write 权限）
  fastify.post(
    '/api/sync/run',
    { preHandler: requirePerm('knowledge:write') },
    async (req) => {
      const keyword = (req.body?.keyword || '常见问题').toString();
      return runNow(keyword);
    }
  );

  // 更新同步配置（需 admin 权限）
  fastify.post(
    '/api/admin/sync-config',
    { preHandler: requirePerm('knowledge:write') },
    async (req) => {
      const cfg = req.body || {};
      const current = getRuntimeConfig();
      const merged = {
        ...current,
        feishu_sync: {
          cron: cfg.cron || current.feishu_sync?.cron || '0 3 * * *',
          keyword: cfg.keyword || current.feishu_sync?.keyword || '常见问题'
        }
      };
      setRuntimeConfig(merged);
      // 重启调度器以应用新 cron
      stopScheduler();
      startScheduler();
      return { ok: true, sync: merged.feishu_sync };
    }
  );
}
