import db from './db.js';
import { embed } from './embed.js';
import { hashPassword, ROLES } from './auth.js';
import { initLLM } from './llm.js';
import { readyPromise as dbReady } from './db.js';

// 样例数据：灌入几条工单 + 对应知识条目，便于立即体验检索与质检。
// 每条知识用「标准问法」作 question（利于向量检索），solution 给可直接发送的话术。
const samples = [
  { content: '我的订单三天了还没发货，急用，请尽快处理！', category: '售后-物流', urgency: 3, level: 'vip',
    q: '订单很久没发货怎么办', sol: '非常抱歉给您带来不便。请稍等，我帮您查询物流状态。若超 48 小时未揽收，可为您加急催办或协商补发，请问方便提供订单号吗？' },
  { content: '收到的商品有划痕，想申请退款怎么操作？', category: '售后-退款', urgency: 2, level: 'normal',
    q: '收到的商品有瑕疵怎么退款', sol: '很抱歉收到有划痕的商品。请您在「我的订单」中发起退款，上传划痕照片，我们会在 1-3 个工作日内审核并原路退回。需要我现在帮您发起吗？' },
  { content: '这款路由器怎么连接宽带？', category: '售前咨询', urgency: 1, level: 'normal',
    q: '路由器怎么设置联网', sol: '将网线一头接光猫、一头接路由器 WAN 口，通电后手机连路由器 Wi-Fi，浏览器打开 192.168.1.1 按向导填入宽带账号即可。如需要，我可发您图文步骤。' },
  { content: '你们的服务太差了，我要投诉！', category: '投诉处理', urgency: 3, level: 'normal',
    q: '我要投诉客服态度', sol: '非常抱歉让您不满，我理解您的心情。我已记录您的投诉，将优先升级给主管处理，并在 24 小时内给您明确答复。方便留个联系方式吗？' }
];

async function main() {
  await dbReady; // 等 sql.js 加载 + 建表完成
  // 先锁定 embedding 模式（offline/ollama/api），保证全库向量一致
  await initLLM();

  const insT = db.prepare(
    'INSERT INTO ticket (source, content, category, urgency, customer_level, confidence) VALUES (?,?,?,?,?,?)'
  );
  const insK = db.prepare(
    'INSERT INTO knowledge_item (question, solution, category, urgency, source_ticket_id, embedding) VALUES (?,?,?,?,?,?)'
  );

  // 幂等：先清空再灌入，重跑不会出现重复数据（sql.js 多语句 exec 不可靠，逐条执行）
  db.prepare('DELETE FROM knowledge_item').run();
  db.prepare('DELETE FROM ticket').run();

  const vecs = await Promise.all(samples.map((s) => embed(s.q + ' ' + s.sol)));

  const tx = db.transaction(() => {
    for (let i = 0; i < samples.length; i++) {
      const s = samples[i];
      const info = insT.run('seed', s.content, s.category, s.urgency, s.level, 0.6);
      insK.run(
        s.q,
        s.sol,
        s.category,
        s.urgency,
        info.lastInsertRowid,
        JSON.stringify(vecs[i])
      );
    }
  });
  tx();

  // 默认管理员账号（仅首次创建，重跑不覆盖已有账号）
  db.prepare(
    'INSERT OR IGNORE INTO users (username, password_hash, role, display_name) VALUES (?,?,?,?)'
  ).run('admin', hashPassword('admin123'), 'admin', '管理员');

  console.log(`seed done: ${samples.length} tickets + knowledge items; roles=${Object.keys(ROLES).join('/')}`);
}

main().catch((e) => {
  console.error('seed failed:', e);
  process.exit(1);
});
