/**
 * v2 部署配置 + 历史对话三态筛选 端到端冒烟测试
 * 用法：node server/scripts-smoke.js
 */
import { spawn } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const PORT = 3299;
const BASE = `http://127.0.0.1:${PORT}`;

// 防污染：起服前备份 deploy/config.json，结束后必还原（避免 apply-template 把真实密钥清空）
const CONFIG_PATH = path.join(ROOT, 'server', 'deploy', 'config.json');
const BACKUP = CONFIG_PATH + '.smoke-bak';
if (fs.existsSync(CONFIG_PATH)) fs.copyFileSync(CONFIG_PATH, BACKUP);

const results = [];
function check(name, ok, detail = '') {
  results.push({ name, ok, detail });
  console.log(`${ok ? '✅' : '❌'} ${name}${detail ? ' → ' + detail : ''}`);
}

async function waitUp(tries = 40) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(`${BASE}/api/health`);
      if (r.ok) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

const srv = spawn(process.execPath, ['server/index.js'], {
  cwd: ROOT,
  env: { ...process.env, PORT: String(PORT) },
  stdio: ['ignore', 'pipe', 'pipe']
});
srv.stdout.on('data', () => {});
srv.stderr.on('data', () => {});

try {
  if (!(await waitUp())) throw new Error('后端未能在 20s 内启动');
  console.log(`\n后端已就绪 ${BASE}\n`);

  // ---- 1. 登录 ----
  const lr = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin123' })
  });
  const lj = await lr.json();
  const token = lj.token;
  check('管理员登录', !!token, token ? `token ${token.length} 字符` : JSON.stringify(lj));
  if (!token) throw new Error('无 token，终止测试');
  const H = { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' };

  // ---- 2. 挂件配置（免登录，且必须无密钥）----
  const wr = await fetch(`${BASE}/api/deploy/widget-config`);
  const wj = await wr.json();
  check('挂件配置免登录可读', wr.ok && !!wj.title, wj.title);
  const leak = /api_key|app_secret|ima_api/i.test(JSON.stringify(wj));
  check('挂件配置无密钥泄漏', !leak, leak ? '检测到敏感字段' : '仅有外观字段');
  check('预置问题已下发', Array.isArray(wj.presetQuestions) && wj.presetQuestions.length > 0, `${wj.presetQuestions?.length || 0} 条`);

  // ---- 3. 部署配置读取 ----
  const cr = await fetch(`${BASE}/api/deploy/config`, { headers: H });
  const cj = await cr.json();
  check('部署配置可读', cr.ok && !!cj.config, `brand=${cj.config?.tenant?.brand}`);
  check('模板清单返回', Array.isArray(cj.templates) && cj.templates.length >= 2, cj.templates?.join(', '));
  check('引擎参数与 deploy 对齐', !!cj.effective?.kb_source, `kb=${cj.effective?.kb_source} model=${cj.effective?.model}`);

  // ---- 4. 改挂件标题 → 回读校验 → 改回 ----
  const origTitle = cj.config.widget.title;
  await fetch(`${BASE}/api/deploy/section/widget`, {
    method: 'PUT',
    headers: H,
    body: JSON.stringify({ title: '冒烟测试标题' })
  });
  const w2 = await (await fetch(`${BASE}/api/deploy/widget-config`)).json();
  check('改挂件标题即时生效', w2.title === '冒烟测试标题', w2.title);
  await fetch(`${BASE}/api/deploy/section/widget`, {
    method: 'PUT',
    headers: H,
    body: JSON.stringify({ title: origTitle })
  });
  const w3 = await (await fetch(`${BASE}/api/deploy/widget-config`)).json();
  check('标题已还原', w3.title === origTitle, w3.title);

  // ---- 5. 企业档案随配置变化 ----
  await fetch(`${BASE}/api/deploy/section/tenant`, {
    method: 'PUT',
    headers: H,
    body: JSON.stringify({ brand: '冒烟品牌', business: ['测试业务'], phone: '10086' })
  });
  const t2 = await (await fetch(`${BASE}/api/deploy/config`, { headers: H })).json();
  check('企业档案已持久化', t2.config.tenant.brand === '冒烟品牌', `brand=${t2.config.tenant.brand}`);

  // ---- 6. 历史对话三态筛选 ----
  for (const scope of ['all', 'agent', 'visitor']) {
    const r = await fetch(`${BASE}/api/qa/conversations?limit=5&scope=${scope}`, { headers: H });
    const j = await r.json();
    const allAgent = (j.items || []).every((x) => x.is_agent === 1 || x.is_agent === true);
    const allVisitor = (j.items || []).every((x) => x.is_agent === 0 || x.is_agent === false);
    const ok = scope === 'agent' ? allAgent : scope === 'visitor' ? allVisitor : true;
    check(
      `历史对话 scope=${scope}`,
      ok,
      `共 ${j.total} 条，本页 ${(j.items || []).length} 条`
    );
  }

  // ---- 7. CSV 导出遵循三态（BOM 须按字节判断，fetch().text() 会剥 BOM）----
  const csvResp = await fetch(`${BASE}/api/qa/export-csv?limit=200&scope=visitor`, { headers: H });
  const csvBuf = Buffer.from(await csvResp.arrayBuffer());
  const hasBom = csvBuf.subarray(0, 3).toString('hex') === 'efbbbf';
  const csv = csvBuf.toString('utf8');
  const lines = csv.split('\r\n').filter(Boolean);
  const bodyLines = lines.slice(1);
  check('CSV 导出可用（scope=visitor）', csvResp.ok && hasBom && lines.length >= 2, `BOM=${hasBom} 表头+${bodyLines.length} 行`);

  // ---- 8. 应用生效 ----
  const ar = await fetch(`${BASE}/api/deploy/apply`, { method: 'POST', headers: H, body: '{}' });
  const aj = await ar.json();
  const effectiveOk = !!(aj.effective && aj.effective.kb_source && aj.effective.model);
  check('应用生效重载引擎', ar.ok && aj.ok && effectiveOk, `kb=${aj.effective?.kb_source} model=${aj.effective?.model}`);

  // ---- 9. 模板套用 ----
  const tr = await fetch(`${BASE}/api/deploy/apply-template`, {
    method: 'POST',
    headers: H,
    body: JSON.stringify({ name: 'blank' })
  });
  const tj = await tr.json();
  check('套用 blank 模板', tr.ok && tj.config?.tenant?.brand === '', '仅接入ASR…… 已清空');

  // 恢复到示例企业
  await fetch(`${BASE}/api/deploy/apply-template`, {
    method: 'POST',
    headers: H,
    body: JSON.stringify({ name: 'ecloud' })
  });
  const back = await (await fetch(`${BASE}/api/deploy/config`, { headers: H })).json();
  check('恢复到 ecloud 模板', back.config.tenant.brand === '示例科技', `brand=${back.config.tenant.brand}`);
} catch (e) {
  check('测试执行', false, e.message);
} finally {
  srv.kill();
  // 还原生产配置，杜绝测试污染
  if (fs.existsSync(BACKUP)) {
    fs.copyFileSync(BACKUP, CONFIG_PATH);
    fs.unlinkSync(BACKUP);
  }
  const pass = results.filter((r) => r.ok).length;
  console.log(`\n===== ${pass}/${results.length} 项通过 =====`);
  process.exit(pass === results.length ? 0 : 1);
}
