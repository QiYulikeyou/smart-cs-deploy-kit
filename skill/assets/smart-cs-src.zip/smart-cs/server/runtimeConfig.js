// 运行时配置存储（v2：改由部署配置层提供真源）
// ---------------------------------------------------------------------------
// 历史实现把 provider/base/model/kb_source 等写死在 DEFAULTS 里，复制到新客户
// 必须改代码。现在真源统一为 server/deploy/config.json（见 deployConfig.js），
// 本模块仅做两件事：
//   1. 把 deploy 配置的 llm / knowledge 两节摊平成旧的 key 结构，
//      保证 llm.js / kb/* / scheduler.js 等既有调用点零改动；
//   2. 承接后台「应用生效」这类运行时改配，写回 deploy/config.json。
//
// 旧版遗留的 server/.runtime-config.json 会在首次读取时自动迁移到 deploy 配置。

import { getDeployConfig, setDeploySection } from './deployConfig.js';

/** deploy 配置 → 旧 key 结构的映射 */
function flatten(cfg) {
  return {
    provider: cfg.llm.provider,
    base: cfg.llm.base,
    model: cfg.llm.model,
    embed_model: cfg.llm.embed_model,
    api_key: cfg.llm.api_key,
    kb_source: cfg.knowledge.kb_source,
    ima_client_id: cfg.knowledge.ima_client_id,
    ima_api_key: cfg.knowledge.ima_api_key,
    ima_kb_id: cfg.knowledge.ima_kb_id,
    feishu_app_id: cfg.knowledge.feishu_app_id,
    feishu_app_secret: cfg.knowledge.feishu_app_secret,
    feishu_space_ids: cfg.knowledge.feishu_space_ids,
    feishu_sync: cfg.knowledge.feishu_sync
  };
}

/** 旧 key → deploy 的归属节 */
const KEY_SECTION = {
  provider: 'llm',
  base: 'llm',
  model: 'llm',
  embed_model: 'llm',
  api_key: 'llm',
  kb_source: 'knowledge',
  ima_client_id: 'knowledge',
  ima_api_key: 'knowledge',
  ima_kb_id: 'knowledge',
  feishu_app_id: 'knowledge',
  feishu_app_secret: 'knowledge',
  feishu_space_ids: 'knowledge',
  feishu_sync: 'knowledge'
};

export function getRuntimeConfig() {
  return flatten(getDeployConfig());
}

export function setRuntimeConfig(patch) {
  const llm = {};
  const knowledge = {};
  for (const [k, v] of Object.entries(patch || {})) {
    const sec = KEY_SECTION[k];
    if (sec === 'llm') llm[k] = v;
    else if (sec === 'knowledge') knowledge[k] = v;
  }
  if (Object.keys(llm).length) setDeploySection('llm', llm);
  if (Object.keys(knowledge).length) setDeploySection('knowledge', knowledge);
  return getRuntimeConfig();
}

export function resetRuntimeConfig() {
  setDeploySection('llm', {
    provider: 'offline',
    base: '',
    model: '',
    embed_model: '',
    api_key: ''
  });
  setDeploySection('knowledge', {
    kb_source: 'local',
    ima_client_id: '',
    ima_api_key: '',
    ima_kb_id: '',
    feishu_app_id: '',
    feishu_app_secret: '',
    feishu_space_ids: ''
  });
  return getRuntimeConfig();
}
