import crypto from 'node:crypto';

// 鉴权核心：密码哈希 + 自签名 token + RBAC。
// 零第三方原生依赖（仅用 Node 内置 crypto），避免 better-sqlite3 那样的版本坑。

const SECRET = process.env.AUTH_SECRET || 'dev-secret-change-me';
if (SECRET === 'dev-secret-change-me') {
  console.warn('[auth] 警告：使用默认 AUTH_SECRET，生产环境请设置环境变量 AUTH_SECRET');
}

// token 有效期（秒），默认 7 天
const TOKEN_TTL = Number(process.env.AUTH_TOKEN_TTL) || 7 * 24 * 3600;

// 角色 -> 权限集合（最小化权限原则）
export const ROLES = {
  admin: [
    'admin',
    'knowledge:read', 'knowledge:write',
    'ticket:read', 'ticket:write',
    'qa:read', 'qa:write',
    'script:read', 'script:write',
    'dispatch:read', 'dispatch:write',
    'user:manage'
  ],
  manager: [
    'knowledge:read', 'knowledge:write',
    'ticket:read', 'ticket:write',
    'qa:read', 'qa:write',
    'script:read', 'script:write',
    'dispatch:read', 'dispatch:write'
  ],
  agent: [
    'knowledge:read',
    'ticket:read', 'ticket:write',
    'qa:read', 'qa:write'
  ]
};

export const ROLE_LABELS = { admin: '管理员', manager: '客服主管', agent: '客服' };

export function getPermissions(role) {
  return ROLES[role] || [];
}

export function hasPerm(role, perm) {
  return getPermissions(role).includes(perm);
}

// ---- 密码哈希（scrypt + 随机盐）----
export function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(pw, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const h = crypto.scryptSync(pw, salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(h, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function b64url(str) {
  return Buffer.from(str, 'utf8').toString('base64url');
}
function b64urlDecode(str) {
  return Buffer.from(str, 'base64url').toString('utf8');
}

// ---- 自签名 token（HMAC-HS256，结构类 JWT 但零依赖）----
export function signToken(payload) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const body = { ...payload, exp: Math.floor(Date.now() / 1000) + TOKEN_TTL };
  const h = b64url(JSON.stringify(header));
  const p = b64url(JSON.stringify(body));
  const sig = crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}

export function verifyToken(token) {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, p, sig] = parts;
  const expected = crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  let payload;
  try {
    payload = JSON.parse(b64urlDecode(p));
  } catch {
    return null;
  }
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

export function publicUser(row) {
  return { id: row.id, username: row.username, role: row.role, display_name: row.display_name };
}

// Fastify 路由守卫：要求具备某权限，否则 403（未登录则 401 由全局 hook 拦截）
export function requirePerm(perm) {
  return async (req, reply) => {
    if (!req.user) return reply.code(401).send({ error: 'unauthorized' });
    if (!hasPerm(req.user.role, perm)) {
      return reply.code(403).send({ error: 'forbidden', need: perm });
    }
  };
}
