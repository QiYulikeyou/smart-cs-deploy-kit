// 企业官方档案（访客端 LLM 的固定背景知识）
// ---------------------------------------------------------------------------
// v2：内容不再写在本文件里，改由「部署配置」deploy/config.json 的 tenant 节生成。
//     复制到新客户时只需替换配置（或后台「企业档案」表单填写），无需改代码。
//
// 用途：访客端（官网挂件）对话时，即便知识库弱命中或未命中，LLM 也有权威的
//       企业信息作为依据，避免凭空编造公司介绍、业务、联系方式等。
//       仅对访客端（public）注入；坐席端不注入，以免干扰坐席自己的判断。
//
// 维护：官网信息更新后，在后台「部署配置 → 企业档案」里改即可，即时生效。
//       历史版本（示例科技 2026-08-28）已沉淀为模板 deploy/templates/ecloud.json。
//
// 注意：必须导出函数而非常量 —— 函数形式才能在后台改完配置后即时生效，无需重启进程。
// ---------------------------------------------------------------------------

import { buildCompanyProfile, getTenant } from './deployConfig.js';

/** 每次对话实时生成，配置改动立即生效 */
export function getCompanyProfile() {
  return buildCompanyProfile();
}

/** 档案更新日期，便于排查「AI 说的信息是否已过期」 */
export function getCompanyProfileUpdated() {
  return getTenant().updated || '';
}
