/**
 * 部署配置层 —— smart-cs v2 「一份配置复制一套客户」
 * ---------------------------------------------------------------------------
 * 目标：把散落在 companyProfile.js / runtimeConfig.js / widget.js 里的硬编码
 *       （企业档案、品牌话术、预置问题、模型引擎、知识库接入）收敛到单一文件：
 *
 *           server/deploy/config.json
 *
 * 复制到新客户时，只需替换这一个文件（或用后台「导入配置」粘贴 JSON），
 * 无需改动任何代码。
 *
 * 分层关系：
 *   环境变量 > deploy/config.json > 内置空白默认
 *   （deploy/config.json 同时作为 runtimeConfig 的默认值来源，见 runtimeConfig.js）
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const DEPLOY_DIR = path.join(__dirname, 'deploy');
export const TEMPLATE_DIR = path.join(DEPLOY_DIR, 'templates');
export const CONFIG_PATH = path.join(DEPLOY_DIR, 'config.json');

/** 空白模板：新客户从这里起步，所有可填字段一目了然 */
export function blankConfig() {
  return {
    version: 2,
    tenant: {
      name: '',
      brand: '',
      english: '',
      website: '',
      phone: '',
      email: '',
      founded: '',
      positioning: '',
      business: [],
      advantages: [],
      scopeNote: '',
      updated: ''
    },
    widget: {
      title: '在线客服',
      greeting: '您好，很高兴为您服务 👋\n请问有什么可以帮您？',
      placeholder: '输入您的问题，回车发送',
      powered: 'AI 智能客服 · 7×24 在线',
      accentFrom: '#06b6d4',
      accentTo: '#3b82f6',
      siteToken: '',
      presetQuestions: []
    },
    llm: {
      provider: 'offline',
      base: '',
      model: '',
      embed_model: '',
      api_key: ''
    },
    knowledge: {
      kb_source: 'local',
      ima_client_id: '',
      ima_api_key: '',
      ima_kb_id: '',
      feishu_app_id: '',
      feishu_app_secret: '',
      feishu_space_ids: '',
      feishu_sync: { cron: '0 3 * * *', keyword: '常见问题' }
    }
  };
}

/** 字段白名单：写盘时过滤垃圾键，结构非法时自动用默认值兜底 */
function sanitize(raw) {
  const base = blankConfig();
  if (!raw || typeof raw !== 'object') return base;

  const pick = (src, dst) => {
    for (const k of Object.keys(dst)) {
      if (src[k] === undefined || src[k] === null) continue;
      if (Array.isArray(dst[k])) {
        if (Array.isArray(src[k])) dst[k] = src[k].map(String);
      } else if (dst[k] && typeof dst[k] === 'object') {
        if (src[k] && typeof src[k] === 'object') pick(src[k], dst[k]);
      } else {
        dst[k] = src[k];
      }
    }
  };

  const out = base;
  out.version = Number(raw.version) || base.version;
  if (raw.tenant) pick(raw.tenant, out.tenant);
  if (raw.widget) pick(raw.widget, out.widget);
  if (raw.llm) pick(raw.llm, out.llm);
  if (raw.knowledge) pick(raw.knowledge, out.knowledge);
  return out;
}

let cache = null;

export function getDeployConfig() {
  if (cache) return cache;
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      cache = sanitize(JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')));
    } else {
      cache = migrateLegacyRuntimeConfig() || blankConfig();
      persist(cache);
    }
  } catch (e) {
    console.warn(`[deploy] 配置读取失败，回退空白模板：${e.message}`);
    cache = blankConfig();
  }
  return cache;
}

/**
 * 兼容旧部署：server/.runtime-config.json → deploy/config.json
 * 只把模型与知识库两节迁过来，其余留空由管理员在后台补齐。
 */
function migrateLegacyRuntimeConfig() {
  const legacyPath = path.join(__dirname, '.runtime-config.json');
  if (!fs.existsSync(legacyPath)) return null;
  try {
    const old = JSON.parse(fs.readFileSync(legacyPath, 'utf8'));
    const next = blankConfig();
    for (const k of Object.keys(next.llm)) {
      if (old[k] !== undefined) next.llm[k] = old[k];
    }
    for (const k of Object.keys(next.knowledge)) {
      if (old[k] !== undefined && typeof old[k] !== 'object') next.knowledge[k] = old[k];
    }
    if (old.feishu_sync) next.knowledge.feishu_sync = old.feishu_sync;
    console.warn(`[deploy] 已从旧版 .runtime-config.json 迁移: ${legacyPath}`);
    return next;
  } catch {
    return null;
  }
}

function persist(cfg) {
  fs.mkdirSync(DEPLOY_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
}

export function setDeployConfig(patch) {
  const next = sanitize({ ...getDeployConfig(), ...(patch || {}) });
  cache = next;
  persist(next);
  return next;
}

/** 按节更新（后台管理页分表单提交时用），返回一个标记告诉调用方是否需要重建引擎 */
export function setDeploySection(section, patch) {
  const cur = getDeployConfig();
  if (!['tenant', 'widget', 'llm', 'knowledge'].includes(section)) {
    throw new Error(`unknown section: ${section}`);
  }
  const next = sanitize({
    ...cur,
    [section]: { ...cur[section], ...(patch || {}) }
  });
  cache = next;
  persist(next);
  return next;
}

export function resetDeployConfig() {
  cache = blankConfig();
  persist(cache);
  return cache;
}

/** 用模板整体替换（如切换到空白模板 / 示例企业） */
export function applyTemplate(name) {
  const tplPath = path.join(TEMPLATE_DIR, `${name}.json`);
  if (!fs.existsSync(tplPath)) throw new Error(`模板不存在: ${name}`);
  const cfg = sanitize(JSON.parse(fs.readFileSync(tplPath, 'utf8')));
  cache = cfg;
  persist(cfg);
  return cfg;
}

export function listTemplates() {
  if (!fs.existsSync(TEMPLATE_DIR)) return [];
  return fs
    .readdirSync(TEMPLATE_DIR)
    .filter((f) => f.endsWith('.json'))
    .map((f) => f.replace(/\.json$/, ''));
}

// ---------- 派生视图 ----------

export const getTenant = () => getDeployConfig().tenant;
export const getWidget = () => getDeployConfig().widget;
export const getLLM = () => getDeployConfig().llm;
export const getKnowledge = () => getDeployConfig().knowledge;

/**
 * 生成访客端注入的企业档案文本。
 * 无论字段是否填写都只输出已填部分，避免把空值塞进 prompt。
 */
export function buildCompanyProfile() {
  const t = getTenant();
  const lines = [];
  const hasBasic = t.name || t.brand || t.website || t.phone || t.email;

  if (!hasBasic && !(t.business || []).length) return '';

  lines.push(`=== 本企业官方档案${t.website ? `（来源：官网 ${t.website}）` : ''}${t.updated ? `，更新于 ${t.updated}` : ''}===`);
  lines.push('以下为权威信息，回答客户提问时须以此为准，不得与之冲突：');

  const basic = [];
  if (t.name) basic.push(`· 公司全称：${t.name}`);
  if (t.brand) basic.push(`· 品牌名：${t.brand}${t.english ? `（${t.english}）` : ''}`);
  if (t.founded) basic.push(`· 成立时间：${t.founded}`);
  if (t.positioning) basic.push(`· 企业定位：${t.positioning}`);
  if (t.website) basic.push(`· 官网：${t.website}`);
  if (basic.length) lines.push('', '【基本信息】', ...basic);

  if ((t.business || []).length) {
    lines.push('', '【业务范围】');
    t.business.forEach((b, i) => lines.push(`${i + 1}. ${b}`));
  }

  if ((t.advantages || []).length) {
    lines.push('', '【核心优势】');
    t.advantages.forEach((a, i) => lines.push(`${i + 1}. ${a}`));
  }

  const contact = [];
  if (t.phone) contact.push(`· 电话：${t.phone}`);
  if (t.email) contact.push(`· 邮箱：${t.email}`);
  if (contact.length) lines.push('', '【联系方式】', ...contact);

  const reach = [t.phone, t.email].filter(Boolean).join(' 或 ');
  if (t.scopeNote) lines.push('', '【服务范围边界】', t.scopeNote);
  else if (reach) {
    lines.push('', '【服务范围边界】', `客户询问的能力若不在上述业务范围内，不要直接承诺可以做，应说明公司当前专注领域，并引导其通过 ${reach} 联系顾问进一步确认。`);
  }

  return lines.join('\n');
}
