# 智能客服系统（中小企业快速落地版）

基于《智能客服系统开发文档 · 中小企业快速落地版》落地的最小可运行骨架。

**技术栈**：Fastify（后端） · SQLite（存储） · Vue 3 + Vite（管理后台） · PM2 单进程（部署） · releases/current 软链零停机发布。

> 与贵司官网完全一致的技术栈，同一套运维知识可直接复用。

---

## 环境要求

- **Node.js >= 22**（已验证 v22.22.2）。后端存储使用纯 JS 的 **sql.js**（WebAssembly，零原生编译），**跨 Node 版本无 ABI 烦恼，无需 node-gyp / 编译工具链**，clone 下来直接 `npm install && npm start` 即可。
- npm >= 9。
- 数据落地在 `data/app.sqljs.db`（sql.js 启动时从文件加载到内存，每次写操作落盘）。切换分支/重装如需清空数据，删该文件后重跑 `npm run seed` 即可。

---

## 目录结构

```
smart-cs/
├── package.json            # 后端依赖与脚本
├── ecosystem.config.js     # PM2 单进程配置（零停机）
├── docker-compose.yml      # 单机容器化
├── Dockerfile
├── release.sh              # 零停机发布脚本
├── server/                 # Fastify 后端
│   ├── index.js            # 引导：注册路由 + 全局鉴权 hook + 托管前端 dist
│   ├── auth.js             # 鉴权核心：scrypt 哈希 + HMAC token + RBAC 角色权限
│   ├── db.js               # sql.js（WASM SQLite，零原生编译）连接与建表（含 users 表）
│   ├── embed.js            # 离线占位 embedding + 余弦检索
│   ├── llm.js              # LLM 接入层（云端 API / 本地 Ollama，含离线回退）
│   ├── qa.js               # 质检：敏感词 + 情绪（规则，零成本）
│   ├── seed.js             # 灌入样例数据 + 默认 admin 账号
│   └── routes/             # tickets / knowledge / qa / scripts / dispatch / auth
├── web/                    # Vue 3 管理后台
│   └── src/App.vue         # 登录网关 + 知识检索 / 导入 / 质检 / 预警 / 用户管理 面板
├── data/                   # SQLite 文件（运行时生成）
└── releases/ + current     # 发布版本（release.sh 生成）
```

---

## 快速开始（本地开发）

```bash
# 1. 安装后端依赖
npm install

# 2. 灌入样例数据（可选，便于立即体验）
npm run seed

# 3. 启动后端（:3000）
npm start

# 4. 另开终端启动前端（:5173，已配置 /api 代理）
cd web && npm install && npm run dev
```

打开 http://localhost:5173 即可使用管理后台。

> 后端也可单独验证：直接访问 http://localhost:3000/api/health

---

## 登录与权限（RBAC）

骨架内置一套**零额外依赖**的登录 + 角色权限（密码用 Node 内置 `crypto.scrypt` 哈希，token 用 HMAC 自签名，**不引任何第三方原生模块**，避免 better-sqlite3 那种版本坑）。

**默认账号**（首次 `npm run seed` 创建，重跑不覆盖）：

| 用户名 | 密码 | 角色 |
|--------|------|------|
| `admin` | `admin123` | 管理员（全部权限 + 用户管理）|

**三种角色与权限**：

| 角色 | 知识库 | 工单 | 质检 | 话术/派单 | 用户管理 |
|------|--------|------|------|-----------|----------|
| 管理员 admin | 读写 | 读写 | 读写 | 读写 | ✅ |
| 客服主管 manager | 读写 | 读写 | 读写 | 读写 | ❌ |
| 客服 agent | 读 | 读写 | 读写 | ❌ | ❌ |

**行为规则**：
- 除 `/api/health` 与 `/api/auth/login` 外，所有 `/api/*` 必须携带 `Authorization: Bearer <token>`，否则 `401`。
- 越权操作返回 `403`（如客服访问用户管理）。
- 管理员可在后台「用户管理」面板创建/管理账号；也可用接口改密码（`/api/auth/change-password`，管理员可改任意用户，普通用户改自己需校验原密码）。
- token 默认 7 天有效（环境变量 `AUTH_TOKEN_TTL` 调秒数）。

**生产注意**：设置环境变量 `AUTH_SECRET`（否则启动会告警并使用弱默认密钥）。

```bash
# 生产示例
AUTH_SECRET=$(openssl rand -hex 32) npm start
```


---

## 生产发布（零停机）

```bash
# 构建前端 + 复制代码到 releases/<version> + current 软链切换 + pm2 reload
bash release.sh
# 或指定版本号：
bash release.sh v1.0.0
```

PM2 以 `current` 软链为工作目录运行单进程，**数据库落在 `data/` 持久化，发版不丢数据**。

---

## 部署配置（一份配置 = 一套客户）

v2 把**企业档案、品牌话术、预置问题、模型引擎、知识库接入**全部收敛到单一文件：

```
server/deploy/config.json
```

复制到新客户时，**只需替换这一个文件**（或在后台「部署配置」页粘贴 JSON），无需改动任何代码。挂件启动时会自动拉取 `/api/deploy/widget-config`，换客户连前端文案/配色都不用改。

**配置优先级**：`环境变量` > `deploy/config.json` > `内置空白默认`。

`config.json` 结构（四节）：

```jsonc
{
  "tenant":   { "name", "brand", "website", "phone", "email", "business[]", "advantages[]", "scopeNote" }, // 企业官方档案，注入访客端兜底话术
  "widget":   { "title", "greeting", "placeholder", "powered", "accentFrom", "accentTo", "siteToken", "presetQuestions[]" }, // 挂件外观与预置问题
  "llm":      { "provider", "base", "model", "embed_model", "api_key" },   // 模型引擎
  "knowledge":{ "kb_source", "ima_client_id", "ima_api_key", "ima_kb_id",  // 知识库接入
                "feishu_app_id", "feishu_app_secret", "feishu_space_ids", "feishu_sync" }
}
```

### 三种设置方式

1. **后台「部署配置」页（推荐）**：登录后台 → 左侧「⚙ 部署配置」→ 一个页面编辑企业档案 / 品牌外观 / 预置问题 / 模型引擎 / 知识库接入，点「保存」即时生效；改了模型或知识库后点「应用并生效」重载引擎（无需重启）。
2. **直接改文件**：编辑 `server/deploy/config.json` 后 `pm2 reload` 即可。
3. **套用模板**：后台「部署配置」页「套用模板」下拉选 `blank`（空白起步）或 `ecloud`（示例企业模板）；也可 `POST /api/deploy/apply-template`。

> 管理接口（读/写/套用/导出）均走 `requirePerm('admin')`，仅管理员可用；挂件配置接口 `/api/deploy/widget-config` 免登录但**只下发外观字段，绝不返回任何密钥**。

### 快速复制到新客户（标准流程）

```bash
# 1) 启动一份干净的 v2
git clone <repo> && cd smart-cs-v2 && npm install && npm run seed

# 2) 生成该客户的部署配置：复制空白模板，填入客户信息（不要碰密钥以外的结构）
cp server/deploy/templates/blank.json server/deploy/config.json
#    vim server/deploy/config.json   # 填 tenant / widget / llm / knowledge
#    或在后台「部署配置」页可视化填完点保存

# 3) 若老客户已有配置，直接导出再导入即可：
#    老客户后台「部署配置」→ 导出 JSON → 新客户后台「导入配置」粘贴 → 保存 → 应用生效

# 4) 构建前端 + 发布
cd web && npm install && npm run build
bash release.sh
```

> ⚠️ `server/deploy/config.json` **已加入 .gitignore**（含客户密钥与实例数据，禁止入库）。分发用 `templates/blank.json`（空白起步）或 `templates/ecloud.json`（示例企业模板，密钥留空）。切记不要把自己的 `config.json` 提交到仓库。

---

## 容器化部署

```bash
docker compose up -d --build
# 访问 http://<服务器IP>:3000
```

---

## 接入真实大模型（embedding / LLM 抽取）

检索的向量化（`embedText`）与工单抽取（`extractTicket`）均通过 **可插拔 provider** 实现，零改动检索/质检/路由逻辑。

**策略**：默认优先 `ollama`（本地、零费、数据不出本机）；也支持外接 **OpenAI 兼容 API**（通义/OpenAI/自建等）；若未配置或不可用，自动回退 `offline` 离线启发式（骨架永远能跑）。启动时探活锁定模式，并在 `/api/health` 的 `llm` 字段暴露当前模式。

### 配置（环境变量）

| 变量 | 说明 | 默认 |
|------|------|------|
| `LLM_PROVIDER` | `ollama` / `api` / `offline` | `ollama` |
| `OLLAMA_HOST` | Ollama 服务地址 | `http://localhost:11434` |
| `OLLAMA_EMBED_MODEL` | Ollama embedding 模型 | `nomic-embed-text` |
| `OLLAMA_LLM_MODEL` | Ollama 对话模型（抽取用） | `qwen2.5:7b` |
| `EMBED_API_BASE` | 外接 embedding 基址（OpenAI 兼容，含 `/v1`） | — |
| `EMBED_API_KEY` | 外接 embedding 密钥 | — |
| `EMBED_MODEL` | 外接 embedding 模型名 | `text-embedding-3-small` |
| `LLM_API_BASE` | 外接对话基址（缺省取 `EMBED_API_BASE`） | — |
| `LLM_API_KEY` | 外接对话密钥（缺省取 `EMBED_API_KEY`） | — |
| `LLM_MODEL` | 外接对话模型名 | `gpt-4o-mini` |

### 方式一：本地 Ollama（推荐，零费）

```bash
# 1) 拉取一个 embedding 模型（任选其一，需与 OLLAMA_EMBED_MODEL 对应）
ollama pull nomic-embed-text
# 2) 可选：拉取用于工单抽取的对话模型
ollama pull qwen2.5:7b
# 3) 启动（默认即 ollama，探活通过即用真实向量）
npm start
```

### 方式二：外接 OpenAI 兼容 API

```bash
LLM_PROVIDER=api \
EMBED_API_BASE=https://api.openai.com/v1 \
EMBED_API_KEY=sk-xxx \
EMBED_MODEL=text-embedding-3-small \
LLM_API_BASE=https://api.openai.com/v1 \
LLM_API_KEY=sk-xxx \
LLM_MODEL=gpt-4o-mini \
npm start
```

> 通义/自建等只要兼容 `/v1/embeddings` 与 `/v1/chat/completions` 即可，把 `EMBED_API_BASE`/`LLM_API_BASE` 指向对应地址。

### ⚠️ 重要：切换 provider / embedding 模型后必须重跑 seed

不同 provider、不同模型产出的向量**维度不同**（如 Ollama 某模型 768 维、OpenAI 1536 维、离线 256 维）。已入库的向量与新查询向量维度不一致会导致检索失效。因此**每次切换都请重新生成向量**：

```bash
npm run seed   # 按当前 provider 重新生成全部知识向量（幂等，先清再灌）
```

---

## 已实现的 MVP 接口

> 🔒 = 需登录（Bearer token）；⚙ = 需对应角色权限；白名单 `/api/health`、`/api/auth/login` 公开。

| 接口 | 方法 | 权限 | 说明 |
|------|------|------|------|
| `/api/health` | GET | 公开 | 健康检查 |
| `/api/auth/login` | POST | 公开 | 登录，返回 token + 用户信息 |
| `/api/auth/me` | GET | 🔒 | 当前登录用户 |
| `/api/auth/users` | GET/POST | 🔒⚙ `user:manage` | 用户列表 / 创建用户 |
| `/api/auth/change-password` | POST | 🔒 | 修改密码（管理员可改任意） |
| `/api/tickets/import` | POST | 🔒⚙ `ticket:write` | 导入工单（JSON 数组），同步生成知识条目 |
| `/api/tickets` | GET | 🔒⚙ `ticket:read` | 工单列表 |
| `/api/knowledge/search?q=` | GET | 🔒⚙ `knowledge:read` | 知识库语义检索 |
| `/api/qa/detect` | POST | 🔒⚙ `qa:write` | 质检检测（敏感词 + 情绪） |
| `/api/qa/alerts` | GET | 🔒⚙ `qa:read` | 待复核预警列表 |
| `/api/scripts/generate` | POST | 🔒⚙ `script:write` | 话术生成（二期 stub） |
| `/api/dispatch/route` | POST | 🔒⚙ `dispatch:write` | 智能派单（二期 stub） |
