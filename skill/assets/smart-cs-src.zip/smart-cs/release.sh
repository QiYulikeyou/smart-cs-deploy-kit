# 智能客服系统 · 零停机发布脚本
# 用法：
#   bash release.sh            # 自动按时间戳生成版本号 vYYYYMMDD-HHMMSS
#   bash release.sh v1.0.0     # 指定版本号
#
# 流程：构建前端 -> 复制代码到 releases/<version> -> current 软链切换 -> pm2 reload
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

VERSION="v$(date +%Y%m%d-%H%M%S)"
[ -n "$1" ] && VERSION="$1"

echo ">> [1/5] 构建前端 web/"
cd web
npm install
npm run build
cd "$ROOT"

echo ">> [2/5] 准备发布目录 releases/$VERSION"
mkdir -p "releases/$VERSION"
rm -rf "releases/$VERSION/server" "releases/$VERSION/web"
cp -r server "releases/$VERSION/server"
cp -r web/dist "releases/$VERSION/web/dist"
cp package.json "releases/$VERSION/package.json"
cp ecosystem.config.js "releases/$VERSION/ecosystem.config.js"

echo ">> [3/5] 切换 current -> $VERSION"
ln -sfn "releases/$VERSION" current

echo ">> [4/5] 重载 PM2（零停机）"
if pm2 describe smart-cs >/dev/null 2>&1; then
  pm2 reload ecosystem.config.js
else
  pm2 start ecosystem.config.js
fi

echo ">> [5/5] 完成。当前版本：$VERSION"
pm2 ls
